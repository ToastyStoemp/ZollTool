import{c as mt,a4 as Gt,a5 as It,a6 as Lt,d as Ht,u as jt,Q as vt,b as I,e as d,s as et,w as Bt,t as F,f as ut,F as ft,p as st,m as at,a7 as Pt,g as bt,x as B,z as Z,_ as Ot,y as Kt,n as dt,j as rt,i as lt,W as Ut,l as qt,o as H,a8 as Zt,O as Yt,B as Xt}from"./index-CA8T6zpN.js";import{s as Jt,a as te}from"./download-B19K81VP.js";import{i as ee,a as se}from"./artwork-C51bQx7I.js";import{R as ae,D as le}from"./receipt-DJX0cvFw.js";const Qt=mt("clipboard-list",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]);const oe=mt("coins",[["path",{d:"M13.744 17.736a6 6 0 1 1-7.48-7.48",key:"bq4yh3"}],["path",{d:"M15 6h1v4",key:"11y1tn"}],["path",{d:"m6.134 14.768.866-.5 2 3.464",key:"17snzx"}],["circle",{cx:"16",cy:"8",r:"6",key:"14bfc9"}]]);const ie=mt("file-input",[["path",{d:"M4 11V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1",key:"1q9hii"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M2 15h10",key:"jfw4w8"}],["path",{d:"m9 18 3-3-3-3",key:"112psh"}]]);const re=mt("file-output",[["path",{d:"M4.226 20.925A2 2 0 0 0 6 22h12a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.127",key:"wfxp4w"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"m5 11-3 3",key:"1dgrs4"}],["path",{d:"m5 17-3-3h10",key:"1mvvaf"}]]);const ne=mt("folder-archive",[["circle",{cx:"15",cy:"19",r:"2",key:"u2pros"}],["path",{d:"M20.9 19.8A2 2 0 0 0 22 18V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h5.1",key:"1jj40k"}],["path",{d:"M15 11v-1",key:"cntcp"}],["path",{d:"M15 17v-2",key:"1279jj"}]]);function Et(){return{event:"",eventDateStart:"",eventDateEnd:"",eventLocation:"",companyCode:"",lrp:"",documentNumber:1,venueName:"",venueStreet:"",venuePostcode:"",venueCity:"",venueCountry:"Switzerland",venueTIN:"CHE222251936",currency:"CHF"}}function xt(){return{companyName:"",fullName:"",street:"",postCodeCity:"",countryOfOrigin:"",phone:"",email:""}}function $t(){return{transportMode:"3",transportationType:"1",transportationCountry:"",transportationNumber:"",flightNumber:"",registrationPostcode:"",importerCountry:"CH"}}function wt(){return{groupMode:"auto",assignments:[]}}function Ct(e){var p;return(p=e.customs)!=null?p:{}}function de(e,p,n,h){var b,R,z,W,g,$,x;const f=Ct(e),w=new Map;for(const s of n)s.eventId===e.id&&w.set(`${s.productId}:${s.variantId}`,s.broughtQty);const M=new Map;for(const s of h)if(!(s.eventId!==e.id||s.revertedBy))for(const a of s.items){const c=`${a.pid}:${(b=a.vid)!=null?b:""}`,m=(R=M.get(c))!=null?R:{qty:0,value:0};m.qty+=a.qty,m.value+=(z=a.baseLineTotal)!=null?z:a.lineTotal,M.set(c,m)}const D=p.filter(s=>!s.deletedAt).map(s=>{var c,m;const a=(c=M.get(`${s.id}:`))!=null?c:{qty:0,value:0};return{id:s.id,title:s.title,sku:s.sku,type:s.type,forSale:s.forSale,unlisted:s.unlisted,price:s.price,priceNote:s.priceNote,weightG:s.weightG,tariffNo:s.tariffNo,tariffRate:s.tariffRate,vatRate:s.vatRate,packagingType:s.packagingType,originCountry:s.originCountry,permitOverride:s.permitOverride,year:s.year,material:s.material,amount:(m=w.get(`${s.id}:`))!=null?m:0,soldQty:a.qty,soldValue:a.value,variants:s.variants.map(u=>{var t,r,y,C;const v=(t=M.get(`${s.id}:${u.id}`))!=null?t:{qty:0,value:0};return{name:u.name,sku:u.sku,price:(r=u.price)!=null?r:null,weightG:(y=u.weightG)!=null?y:null,unlisted:u.unlisted,amount:(C=w.get(`${s.id}:${u.id}`))!=null?C:0,soldQty:v.qty,soldValue:v.value}})}}),A=(W=f.meta)!=null?W:{},o={...Et(),...A,event:e.name,eventDateStart:e.dateStart||A.eventDateStart||"",eventDateEnd:e.dateEnd||A.eventDateEnd||"",eventLocation:A.eventLocation||e.venue.city||"",venueStreet:e.venue.street||A.venueStreet||"",venuePostcode:e.venue.postcode||A.venuePostcode||"",venueCity:e.venue.city||A.venueCity||"",venueCountry:e.venue.country||A.venueCountry||"Switzerland",venueTIN:e.venue.tin||A.venueTIN||Et().venueTIN,currency:e.currency},V={...wt(),...(g=f.form1174)!=null?g:{}};return Array.isArray(V.assignments)||(V.assignments=[]),{meta:o,artist:{...xt(),...($=f.artist)!=null?$:{}},edec:{...$t(),...(x=f.edec)!=null?x:{}},form1174:V,products:D}}function Ft(e,p){if(!e)return"";const n=new Date(e+"T00:00:00"),h=n.getDate(),f=String(n.getMonth()+1).padStart(2,"0"),w=n.getFullYear();if(!p)return`${h}.${f}.${w}`;const D=new Date(p+"T00:00:00").getDate();return`${h}. – ${D}.${f}.${w}`}function L(e,p){return parseFloat(e).toFixed(p)}function E(e,p){if(e==null||isNaN(e))return 0;const n=Math.pow(10,p);return Math.floor(parseFloat(e)*n)/n}function P(e){return e==null||isNaN(e)||e===0?"0 kg":L(e,2).replace(".",",")+" kg"}function i(e){return String(e==null?"":e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function U(e){return String(e==null?"":e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}function X(e){if(!e)return"";const p=e.trim();if(/^[A-Z]{2}$/.test(p))return p;const n=Gt[p.toLowerCase()];return n||p.toUpperCase().slice(0,2)}function ce(e){if(!e)return{postCode:"",city:""};const p=e.match(/^(\S+)\s+(.+)$/);return p?{postCode:p[1],city:p[2]}:{postCode:"",city:e}}function ue(e){return e?e.replace(/^(\d{4})\.(\d{2})\.(\d{2})$/,"$1.$2$3"):""}function me(e){if(!e)return 0;const p=It.find(n=>n.code===e);return p?p.permit||0:e.startsWith("7117")?2:0}function pe(e){return e!=null&&parseFloat(e)<=2.7?2:1}function Tt(e,p){const n=X(e.artist.countryOfOrigin)||"XX",h=(e.meta.companyCode||"").toUpperCase()||"XX",f=new Date;let w=f.getFullYear(),M=f.getMonth()+1;if(e.meta.eventDateStart){const o=new Date(e.meta.eventDateStart+"T00:00:00");w=o.getFullYear(),M=o.getMonth()+1}const D=String(M).padStart(2,"0"),A=String(p).padStart(3,"0");return`${n}CH_${h}_${w}_${D}_${A}`}function K(e){return Array.isArray(e.variants)&&e.variants.length>0}function kt(e,p){const n=p.price!=null&&p.price!==""?p.price:e.price;return n!=null&&!isNaN(parseFloat(n))?parseFloat(n):null}function Nt(e,p){const n=p.weightG!=null&&p.weightG!==""?p.weightG:e.weightG;return parseFloat(n)||0}function q(e,p=!1){if(K(e)){let A=0,o=0,V=0,b=0,R=0,z=0;for(const m of e.variants){if(p&&m.unlisted)continue;const u=m.amount||0,v=Nt(e,m),t=kt(e,m);A+=u,o+=Math.round(u*v)/1e3,t!=null&&(V+=t*u),b+=m.soldQty||0,R+=m.soldValue||0,z+=(m.soldQty||0)*v/1e3}o=Math.round(o*1e3)/1e3;const W=p?e.variants.filter(m=>!m.unlisted):e.variants,g=W.map(m=>kt(e,m)).filter(m=>m!=null),$=W.map(m=>Nt(e,m)),x=g.length>0&&g.every(m=>m===g[0]),s=$.length>0&&$.every(m=>m===$[0]),a=x?g[0]:A>0&&V>0?V/A:null,c=s?$[0]:A>0?Math.round(o*1e3/A):e.weightG||0;return{totalWeightKg:o,totalValue:V>0?Math.round(V):null,effectiveUnitPrice:a,effectiveUnitWeightG:c,soldWeightKg:z,amount:A,soldQty:b,soldValue:R}}const n=e.amount||0,h=Math.round(n*(e.weightG||0))/1e3;let f=e.totalValueCHF!=null?Math.round(parseFloat(e.totalValueCHF)):null;f==null&&e.price!=null&&e.price!==""&&(f=Math.round(parseFloat(e.price)*n));const w=f!=null&&n>0?f/n:null,M=n>0?h*1e3/n:e.weightG||0,D=(e.soldQty||0)*(e.weightG||0)/1e3;return{totalWeightKg:h,totalValue:f,effectiveUnitPrice:w,effectiveUnitWeightG:M,soldWeightKg:D,amount:n,soldQty:e.soldQty||0,soldValue:e.soldValue||0}}function ht(e){if(K(e)){let w=0,M=0,D=0,A=!1;for(const o of e.variants){if(o.unlisted)continue;const V=(o.amount||0)-(o.soldQty||0);if(V<=0)continue;const b=Nt(e,o),R=kt(e,o);w+=V,M+=Math.round(V*b)/1e3,R!=null&&(D+=Math.round(R*V),A=!0)}return{retQty:w,retWkg:Math.round(M*1e3)/1e3,retVal:A?D:null}}const p=q(e),n=(p.amount||0)-(p.soldQty||0);if(n<=0)return{retQty:0,retWkg:0,retVal:null};const h=Math.round(n*(e.weightG||0))/1e3,f=p.effectiveUnitPrice!=null?Math.round(p.effectiveUnitPrice*n):null;return{retQty:n,retWkg:h,retVal:f}}function Y(e){return!e.unlisted&&(!!(e.tariffNo&&e.tariffNo.trim())||e.vatRate!=null&&e.vatRate!=="")}function Vt(e){var o;const p=e.form1174.assignments;for(;p.length<e.products.length;)p.push(0);p.length>e.products.length&&(p.length=e.products.length);function n(V){let b="—",R=-1;const z={tariffNo:"—",qty:0,weightKg:0,value:0,retQty:0,retWeightKg:0,retValue:0};return V.forEach(W=>{const g=q(W);z.qty+=g.amount||0,z.weightKg+=g.totalWeightKg,g.totalValue!=null&&(z.value+=g.totalValue);const $=Math.max(0,(g.amount||0)-(g.soldQty||0));z.retQty+=$,z.retWeightKg+=Math.round($*(W.weightG||0))/1e3,g.effectiveUnitPrice!=null&&(z.retValue+=Math.round(g.effectiveUnitPrice*$)),g.totalValue!=null&&g.totalValue>R&&W.tariffNo&&(R=g.totalValue,b=W.tariffNo)}),z.tariffNo=b,z}if(e.form1174.groupMode==="manual"){const V=e.products.filter((W,g)=>p[g]===1),b=e.products.filter((W,g)=>p[g]!==1),R=n(V),z=n(b);return{g1:R,g2:z,hasG2:z.qty>0,g1prods:V,g2prods:b}}const h={};e.products.forEach(V=>{const b=(V.tariffNo||"").trim()||"—",R=q(V);h[b]||(h[b]=0),R.totalValue!=null&&(h[b]+=R.totalValue)});const f=(o=Object.entries(h).sort((V,b)=>b[1]-V[1])[0])==null?void 0:o[0],w=e.products.filter(V=>((V.tariffNo||"").trim()||"—")===f),M=e.products.filter(V=>((V.tariffNo||"").trim()||"—")!==f),D=n(w),A=n(M);return{g1:D,g2:A,hasG2:A.qty>0,g1prods:w,g2prods:M}}function fe(e,p=new Date){const n=e.products.filter(s=>s.unlisted?!1:s.variants&&s.variants.length>0?s.variants.some(a=>!a.unlisted&&(a.soldQty||0)>0):(s.soldQty||0)>0);if(n.length===0)return null;const h=e.edec,f=e.artist,w=X(f.countryOfOrigin),M=ce(f.postCodeCity),D=s=>String(s).padStart(2,"0"),A=`${p.getUTCFullYear()}-${D(p.getUTCMonth()+1)}-${D(p.getUTCDate())} ${D(p.getUTCHours())}:${D(p.getUTCMinutes())}:${D(p.getUTCSeconds())}.000 UTC`,o=[];o.push('<?xml version="1.0" encoding="UTF-8"?>'),o.push(`<EdecWeb version="4.0" createdDate="${U(A)}">`),o.push("  <goodsDeclarationType>"),o.push("    <serviceType>1</serviceType>"),o.push("    <declarationType>1</declarationType>"),o.push("    <language>de</language>"),o.push(`    <dispatchCountry>${U(w)}</dispatchCountry>`);const V=h.transportMode||"3";o.push("    <transportMeans>"),o.push(`      <transportMode>${U(V)}</transportMode>`),V==="3"&&o.push(`      <transportationType>${U(h.transportationType||"1")}</transportationType>`),o.push(`      <transportationCountry>${U((h.transportationCountry||"").toUpperCase())}</transportationCountry>`),o.push(`      <transportationNumber>${U(h.transportationNumber||"")}</transportationNumber>`),o.push("    </transportMeans>"),o.push("    <transportInContainer>0</transportInContainer>"),o.push("    <previousDocument/>");const b=e.meta,R=X(b.venueCountry)||"CH";o.push("    <importer>"),o.push(`      <name>${U(b.venueName||"")}</name>`),o.push(`      <addressSupplement1>${U("c/o "+(b.event||""))}</addressSupplement1>`),o.push(`      <addressSupplement2>${U(b.venueStreet||"")}</addressSupplement2>`),o.push(`      <postalCode>${U(b.venuePostcode||"")}</postalCode>`),o.push(`      <city>${U(b.venueCity||"")}</city>`),o.push(`      <country>${U(R)}</country>`),o.push(`      <traderIdentificationNumber>${U(b.venueTIN||"")}</traderIdentificationNumber>`),o.push("    </importer>"),o.push("    <consignee>"),o.push(`      <name>${U(b.venueName||"")}</name>`),o.push(`      <addressSupplement1>${U("c/o "+(b.event||""))}</addressSupplement1>`),o.push(`      <addressSupplement2>${U(b.venueStreet||"")}</addressSupplement2>`),o.push(`      <postalCode>${U(b.venuePostcode||"")}</postalCode>`),o.push(`      <city>${U(b.venueCity||"")}</city>`),o.push(`      <country>${U(R)}</country>`),o.push(`      <traderIdentificationNumber>${U(b.venueTIN||"")}</traderIdentificationNumber>`),o.push("    </consignee>"),o.push("    <declarant>"),o.push("      <traderIdentificationNumber></traderIdentificationNumber>"),o.push(`      <name>${U(f.fullName||f.companyName||"")}</name>`),o.push(`      <street>${U(f.street||"")}</street>`),o.push(`      <postalCode>${U(M.postCode)}</postalCode>`),o.push(`      <city>${U(M.city)}</city>`),o.push(`      <country>${U(w)}</country>`),o.push("    </declarant>"),o.push("    <business>"),o.push("      <customsAccount>0</customsAccount>"),o.push("      <vatAccount>0</vatAccount>"),o.push("      <vatSuffix>0</vatSuffix>"),o.push("      <invoiceCurrencyType>1</invoiceCurrencyType>"),o.push("    </business>"),o.push("    <goodsItem>"),n.forEach((s,a)=>{const c=s.variants&&s.variants.length>0?s.variants.filter(N=>!N.unlisted):null,m=c?c.reduce((N,S)=>N+(S.soldQty||0),0):s.soldQty||0,u=c?c.reduce((N,S)=>N+(S.soldValue||0),0):s.soldValue||0,v=Math.max(.1,Math.round(m*(s.weightG||0)/100)/10),t=s.permitOverride!=null?s.permitOverride:me(s.tariffNo),r=pe(s.vatRate),y=ue(s.tariffNo),C=s.originCountry&&s.originCountry.trim()?s.originCountry.trim().toUpperCase():w;let k=0;u>0?k=Math.floor(u):s.price!=null&&s.price!==""?k=Math.floor(m*parseFloat(s.price)):s.totalValueCHF!=null&&s.amount&&(k=Math.floor(m/s.amount*parseFloat(s.totalValueCHF))),o.push("      <GoodsItemType>"),o.push(`        <traderItemID>${a}</traderItemID>`),o.push(`        <description>${U(m+" "+(s.title||""))}</description>`),o.push(`        <commodityCode>${U(y)}</commodityCode>`),o.push(`        <grossMass>${v}</grossMass>`),o.push(`        <netMass>${v}</netMass>`),o.push(`        <permitObligation>${t}</permitObligation>`),o.push(`        <nonCustomsLawObligation>${t}</nonCustomsLawObligation>`),o.push("        <statistic>"),o.push("          <customsClearanceType>1</customsClearanceType>"),o.push("          <commercialGood>1</commercialGood>"),o.push(`          <statisticalValue>${k}</statisticalValue>`),o.push("          <repair>0</repair>"),o.push("        </statistic>"),o.push("        <origin>"),o.push(`          <originCountry>${U(C)}</originCountry>`),o.push("          <preference>0</preference>"),o.push("        </origin>");const O=s.packagingType||"CT";O==="NE"?(o.push("        <packaging>"),o.push("          <PackagingType>"),o.push("            <packagingType>NE</packagingType>"),o.push("            <quantity>0</quantity>"),o.push("          </PackagingType>"),o.push("        </packaging>")):(o.push("        <packaging>"),o.push("          <PackagingType>"),o.push(`            <packagingType>${U(O)}</packagingType>`),o.push("            <quantity>1</quantity>"),o.push("            <packagingReferenceNumber>1</packagingReferenceNumber>"),o.push("          </PackagingType>"),o.push("        </packaging>")),o.push("        <valuation>"),o.push("          <netDuty>0</netDuty>"),o.push(`          <vatValue>${k}</vatValue>`),o.push(`          <vatCode>${r}</vatCode>`),o.push("        </valuation>"),o.push("      </GoodsItemType>")}),o.push("    </goodsItem>"),o.push("  </goodsDeclarationType>"),o.push("</EdecWeb>");const z=o.join(`
`),W=e.meta.event||"ZollTool",g=e.artist.companyName||e.artist.fullName||"",$=p.toISOString().slice(0,10),x=[W,g,"edec",$].filter(Boolean).join("_").replace(/[^a-zA-Z0-9_\-\.]/g,"_")+".xml";return{xml:z,filename:x}}function yt(e){const p=i(e.title||"");return ee(e.type)&&e.year?`${p} (${e.year})`:se(e.type)&&e.material?`${p} — ${i(e.material)}`:p}const he={1:"Auxiliary Document for the Customs Declaration - Import",2:"Auxiliary Document for the Customs Declaration - Sold Goods",3:"Return Goods List - Re-export Declaration"};function nt(e){return e.meta&&e.meta.currency?e.meta.currency:"CHF"}function ge(e,p,n="detailed"){const h=e.meta,f=e.artist,w=Tt(e,p),M=he,D=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 8pt; color: #000; padding: 12mm; }
  .doc-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6mm; }
  .doc-top-left .doc-title { font-size: 10pt; font-weight: bold; text-transform: uppercase; }
  .doc-top-left .doc-subtitle { font-size: 8pt; color: #444; margin-top: 2px; }
  .doc-top-right { text-align: right; }
  .doc-top-right .event-name { font-size: 11pt; font-weight: bold; }
  .doc-top-right .lrp { font-size: 8pt; margin-top: 3px; }
  .info-table { width: 100%; border-collapse: collapse; margin-bottom: 5mm; }
  .info-table td { padding: 2px 6px; font-size: 8pt; border: 1px solid #ccc; }
  .info-table td.lbl { font-weight: bold; background: #f4f4f4; width: 130px; font-size: 7.5pt; }
  .section-title { font-weight: bold; font-size: 9pt; margin: 4mm 0 2mm 0; border-bottom: 1.5px solid #000; padding-bottom: 1mm; }
  table.goods { width: 100%; border-collapse: collapse; font-size: 7pt; }
  table.goods th { background: #e8e8e8; border: 1px solid #aaa; padding: 3px 4px; text-align: left; font-size: 6.5pt; font-weight: bold; white-space: nowrap; }
  table.goods td { border: 1px solid #ccc; padding: 2px 4px; vertical-align: middle; }
  table.goods tr:nth-child(even) td { background: #fafafa; }
  table.goods tfoot td { background: #e8e8e8; font-weight: bold; border: 1px solid #aaa; padding: 3px 4px; }
  .r { text-align: right; } .c { text-align: center; }
  .mono { font-family: 'Courier New', monospace; font-size: 6.5pt; }
  .sold-head { border-left: 2px solid #666 !important; }
  td.sold-first { border-left: 2px solid #888; }
  .signature-section { margin-top: 8mm; }
  .signature-box { border: 1px solid #000; width: 80mm; height: 22mm; margin-top: 2mm; }
  @media print { body { padding: 0; } @page { size: A4 landscape; margin: 12mm; } }`,A=`<div class="doc-top">
  <div class="doc-top-left">
    <div class="doc-title">${i(M[p]||M[1])}</div>
    <div class="doc-subtitle">${i(Ft(h.eventDateStart,h.eventDateEnd))}${h.eventLocation?", "+i(h.eventLocation):""}</div>
  </div>
  <div class="doc-top-right">
    <div class="event-name">${i(h.event||"")}</div>
    <div class="lrp">LRP: ${i(w||"—")}</div>
  </div>
</div>
<table class="info-table">
  <tr><td class="lbl">Artist / Company Name</td><td>${i(f.companyName||"")}</td>
      <td class="lbl">Name &amp; Surname</td><td>${i(f.fullName||"")}</td></tr>
  <tr><td class="lbl">Street &amp; House Number</td><td>${i(f.street||"")}</td>
      <td class="lbl">Postcode &amp; City</td><td>${i(f.postCodeCity||"")}</td></tr>
  <tr><td class="lbl">Country of Origin</td><td>${i(f.countryOfOrigin||"")}</td>
      <td class="lbl">Phone / Mobile</td><td>${i(f.phone||"")}</td></tr>
  <tr><td class="lbl">Email</td><td colspan="3">${i(f.email||"")}</td></tr>
</table>`;let o="";if(p===1){let b=0,R=0,z=0,W=0;const g=[];if(n==="bytype"){const $={};e.products.filter(Y).forEach(s=>{const a=q(s),c=`${s.type||"Other"}\0${s.tariffNo||""}`;$[c]||($[c]={type:s.type||"Other",tariffNo:s.tariffNo||"",tariffRate:s.tariffRate,vatRate:s.vatRate,amount:0,wkg:0,val:0,hasVal:!1});const m=$[c];m.amount+=a.amount||0,m.wkg+=a.totalWeightKg,a.totalValue!=null&&(m.val+=a.totalValue,m.hasVal=!0),b+=a.amount||0,R+=a.totalWeightKg,a.totalValue!=null&&(z+=a.totalValue)}),Object.values($).forEach((s,a)=>{g.push(`<tr>
          <td class="c">${a+1}</td><td><strong>${i(s.type)}</strong></td>
          <td class="r">${i(s.tariffNo)}</td>
          <td class="r">${s.tariffRate!=null?s.tariffRate+"%":""}</td>
          <td class="r">${s.vatRate!=null?s.vatRate+"%":""}</td>
          <td class="r">${s.amount}</td>
          <td class="r">${P(s.wkg)}</td>
          <td class="r">${s.hasVal?s.val:"—"}</td></tr>`)});const x=g.join("");o=`<div class="section-title">List of goods (By Type)</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Type</th><th class="r">HS Code</th>
  <th class="r">Tariff Rate</th><th class="r">VAT Rate</th>
  <th class="r">Total Amount</th><th class="r">Total Weight</th>
  <th class="r">Total Value (${nt(e)})</th>
</tr></thead><tbody>${x}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r">${b}</td><td class="r">${P(R)}</td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td>
</tr></tfoot></table>`}else{e.products.filter(Y).forEach(s=>{var m;const a=q(s),c=s.originCountry&&s.originCountry.trim()?s.originCountry.trim().toUpperCase():X(f.countryOfOrigin)||"";if(n==="detailed"&&K(s))s.variants.filter(u=>!u.unlisted).forEach(u=>{const v=W++,t=u.weightG!=null?u.weightG:s.weightG,r=u.price!=null?u.price:s.price,y=u.amount||0,C=Math.round(y*(t||0))/1e3,k=r!=null?Math.round(r*y):null,O=s.priceNote||(r!=null?L(E(r,2),2):"—"),N=k!=null?k:"—";b+=y,R+=C,k!=null&&(z+=k),g.push(`<tr><td class="c">${v+1}</td><td class="mono">${i(u.sku||s.sku||"")}</td><td>${yt(s)} - ${i(u.name||"")}</td>
              <td>${s.forSale?"For Sale":"Not For Sale"}</td><td>${i(s.type||"")}</td>
              <td class="r">${y}</td><td class="r">${t!=null?t+" g":""}</td>
              <td class="r">${P(C)}</td><td class="r">${i(O)}</td>
              <td class="r">${N}</td><td class="r">${i(s.tariffNo||"")}</td>
              <td class="r">${s.tariffRate!=null?s.tariffRate+"%":""}</td>
              <td class="r">${s.vatRate!=null?s.vatRate+"%":""}</td>
              <td class="c">${i(c)}</td></tr>`)});else{const u=W++,v=s.priceNote||(a.effectiveUnitPrice!=null?L(E(a.effectiveUnitPrice,2),2):"—"),t=a.totalValue!=null?a.totalValue:"—";b+=a.amount||0,R+=a.totalWeightKg,a.totalValue!=null&&(z+=a.totalValue);const r=K(s)?`${yt(s)} (${s.variants.filter(y=>!y.unlisted).length} variants)`:yt(s);g.push(`<tr><td class="c">${u+1}</td><td class="mono">${i(s.sku||"")}</td><td>${r}</td>
            <td>${s.forSale?"For Sale":"Not For Sale"}</td><td>${i(s.type||"")}</td>
            <td class="r">${(m=a.amount)!=null?m:""}</td><td class="r">${a.effectiveUnitWeightG!=null?Math.round(a.effectiveUnitWeightG)+" g":""}</td>
            <td class="r">${P(a.totalWeightKg)}</td><td class="r">${i(v)}</td>
            <td class="r">${t}</td><td class="r">${i(s.tariffNo||"")}</td>
            <td class="r">${s.tariffRate!=null?s.tariffRate+"%":""}</td>
            <td class="r">${s.vatRate!=null?s.vatRate+"%":""}</td>
            <td class="c">${i(c)}</td></tr>`)}});const $=g.join("");o=`<div class="section-title">List of goods${n==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Title</th><th>SKU</th><th>For Sale / Not For Sale</th><th>Type</th>
  <th class="r">Amount</th><th class="r">Unit Weight</th><th class="r">Total Weight</th>
  <th class="r">Unit Price (${nt(e)})</th><th class="r">Total Value (${nt(e)})</th>
  <th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th>
</tr></thead><tbody>${$}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r">${b}</td><td></td><td class="r">${P(R)}</td><td></td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td><td colspan="4"></td>
</tr></tfoot></table>`}}else if(p===2){let b=0,R=0,z=0,W=0;const g=[];if(n==="bytype"){const $={};e.products.forEach(a=>{if(!Y(a))return;const c=q(a);if(!(c.soldQty>0))return;const m=`${a.type||"Other"}\0${a.tariffNo||""}`;$[m]||($[m]={type:a.type||"Other",tariffNo:a.tariffNo||"",tariffRate:a.tariffRate,vatRate:a.vatRate,soldQty:0,soldVal:0,soldWkg:0});const u=$[m];u.soldQty+=c.soldQty||0,u.soldVal+=E(c.soldValue||0,2),u.soldWkg+=c.soldWeightKg,b+=c.soldQty||0,R+=E(c.soldValue||0,2),z+=c.soldWeightKg}),Object.values($).forEach((a,c)=>{g.push(`<tr>
          <td class="c">${c+1}</td><td><strong>${i(a.type)}</strong></td>
          <td class="r">${i(a.tariffNo)}</td>
          <td class="r">${a.tariffRate!=null?a.tariffRate+"%":""}</td>
          <td class="r">${a.vatRate!=null?a.vatRate+"%":""}</td>
          <td class="r">${a.soldQty}</td>
          <td class="r">${L(E(a.soldVal,2),2)}</td>
          <td class="r">${P(a.soldWkg)}</td></tr>`)});const x=g.join(""),s=x?"":'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>';o=`<div class="section-title">List of goods sold (By Type)</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Type</th><th class="r">HS Code</th>
  <th class="r">Tariff Rate</th><th class="r">VAT Rate</th>
  <th class="r">Qty Sold</th><th class="r">Value Sold (${nt(e)})</th>
  <th class="r">Sold Weight</th>
</tr></thead><tbody>${x}${s}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r">${b}</td>
  <td class="r">${L(E(R,2),2)}</td>
  <td class="r">${P(z)}</td>
</tr></tfoot></table>`}else{e.products.forEach(a=>{if(!Y(a))return;const c=q(a);if(n==="detailed"&&K(a))a.variants.filter(m=>!m.unlisted).forEach(m=>{if(!(m.soldQty>0))return;W++;const u=m.weightG!=null?m.weightG:a.weightG,v=E(m.soldValue||0,2),t=(m.soldQty||0)*(u||0)/1e3;b+=m.soldQty||0,R+=v,z+=t,g.push(`<tr><td class="c">${W}</td><td>${i(a.title||"")} - ${i(m.name||"")}</td><td>${i(a.type||"")}</td>
              <td class="r">${i(a.tariffNo||"")}</td>
              <td class="r">${m.soldQty||0}</td>
              <td class="r">${L(v,2)}</td>
              <td class="r">${P(t)}</td></tr>`)});else if(c.soldQty>0){W++;const m=E(c.soldValue||0,2);b+=c.soldQty||0,R+=m,z+=c.soldWeightKg;const u=K(a)?`${i(a.title||"")} (${a.variants.filter(v=>!v.unlisted).length} variants)`:i(a.title||"");g.push(`<tr><td class="c">${W}</td><td>${u}</td><td>${i(a.type||"")}</td>
            <td class="r">${i(a.tariffNo||"")}</td>
            <td class="r">${c.soldQty||0}</td>
            <td class="r">${L(m,2)}</td>
            <td class="r">${P(c.soldWeightKg)}</td></tr>`)}else return});const $=g.join(""),x=$?"":'<tr><td colspan="7" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>';o=`<div class="section-title">List of goods sold${n==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Title</th><th>Type</th>
  <th class="r">Tariff no.</th>
  <th class="r">Qty Sold</th><th class="r">Value Sold (${nt(e)})</th>
  <th class="r">Sold Weight</th>
</tr></thead><tbody>${$}${x}</tbody><tfoot><tr>
  <td colspan="4" style="text-align:right">TOTALS</td>
  <td class="r">${b}</td>
  <td class="r">${L(E(R,2),2)}</td>
  <td class="r">${P(z)}</td>
</tr></tfoot></table>`}}else{let b=0,R=0,z=0,W=0;const g=[];if(n==="bytype"){const $={};e.products.forEach(a=>{if(!Y(a))return;const c=ht(a);if(c.retQty<=0)return;const{retQty:m,retWkg:u,retVal:v}=c,t=`${a.type||"Other"}\0${a.tariffNo||""}`;$[t]||($[t]={type:a.type||"Other",tariffNo:a.tariffNo||"",tariffRate:a.tariffRate,vatRate:a.vatRate,retQty:0,retWkg:0,retVal:0,hasVal:!1});const r=$[t];r.retQty+=m,r.retWkg+=u,v!=null&&(r.retVal+=v,r.hasVal=!0),b+=m,R+=u,v!=null&&(z+=v)}),Object.values($).forEach((a,c)=>{g.push(`<tr>
          <td class="c">${c+1}</td><td><strong>${i(a.type)}</strong></td>
          <td class="r">${i(a.tariffNo)}</td>
          <td class="r">${a.tariffRate!=null?a.tariffRate+"%":""}</td>
          <td class="r">${a.vatRate!=null?a.vatRate+"%":""}</td>
          <td class="r"><strong>${a.retQty}</strong></td>
          <td class="r">${P(a.retWkg)}</td>
          <td class="r">${a.hasVal?a.retVal:"—"}</td></tr>`)});const x=g.join(""),s=x?"":'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>';o=`<div class="section-title">Return goods list (re-export) (By Type)</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Type</th><th class="r">HS Code</th>
  <th class="r">Tariff Rate</th><th class="r">VAT Rate</th>
  <th class="r">Return Qty</th><th class="r">Return Weight</th>
  <th class="r">Return Value (${nt(e)})</th>
</tr></thead><tbody>${x}${s}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r"><strong>${b}</strong></td>
  <td class="r">${P(R)}</td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td>
</tr></tfoot></table>`}else{e.products.forEach(a=>{var u;if(!Y(a))return;const c=q(a),m=a.originCountry&&a.originCountry.trim()?a.originCountry.trim().toUpperCase():X(f.countryOfOrigin)||"";if(n==="detailed"&&K(a))a.variants.filter(v=>!v.unlisted).forEach(v=>{const t=(v.amount||0)-(v.soldQty||0);if(t<=0)return;W++;const r=v.weightG!=null?v.weightG:a.weightG,y=v.price!=null?v.price:a.price,C=Math.round(t*(r||0))/1e3,k=y!=null?Math.round(y*t):null;b+=t,R+=C,k!=null&&(z+=k);const O=a.priceNote||(y!=null?L(E(y,2),2):"—"),N=k!=null?k:"—";g.push(`<tr><td class="c">${W}</td><td>${i(a.title||"")} - ${i(v.name||"")}</td><td>${i(a.type||"")}</td>
              <td class="r">${v.amount||0}</td><td class="r">${v.soldQty||0}</td>
              <td class="r"><strong>${t}</strong></td>
              <td class="r">${r!=null?r+" g":""}</td>
              <td class="r">${P(C)}</td>
              <td class="r">${i(O)}</td>
              <td class="r">${N}</td>
              <td class="r">${i(a.tariffNo||"")}</td>
              <td class="r">${a.tariffRate!=null?a.tariffRate+"%":""}</td>
              <td class="r">${a.vatRate!=null?a.vatRate+"%":""}</td>
              <td class="c">${i(m)}</td></tr>`)});else{const v=ht(a);if(v.retQty<=0)return;W++;const{retQty:t,retWkg:r,retVal:y}=v;b+=t,R+=r,y!=null&&(z+=y);const C=a.priceNote||(c.effectiveUnitPrice!=null?L(E(c.effectiveUnitPrice,2),2):"—"),k=y!=null?y:"—",O=K(a)?`${i(a.title||"")} (${a.variants.filter(N=>!N.unlisted).length} variants)`:i(a.title||"");g.push(`<tr><td class="c">${W}</td><td>${O}</td><td>${i(a.type||"")}</td>
            <td class="r">${(u=c.amount)!=null?u:""}</td><td class="r">${c.soldQty||0}</td>
            <td class="r"><strong>${t}</strong></td>
            <td class="r">${c.effectiveUnitWeightG!=null?Math.round(c.effectiveUnitWeightG)+" g":""}</td>
            <td class="r">${P(r)}</td>
            <td class="r">${i(C)}</td>
            <td class="r">${k}</td>
            <td class="r">${i(a.tariffNo||"")}</td>
            <td class="r">${a.tariffRate!=null?a.tariffRate+"%":""}</td>
            <td class="r">${a.vatRate!=null?a.vatRate+"%":""}</td>
            <td class="c">${i(m)}</td></tr>`)}});const $=g.join(""),x=$?"":'<tr><td colspan="14" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>';o=`<div class="section-title">Return goods list (re-export)${n==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Title</th><th>Type</th>
  <th class="r">Original Qty</th><th class="r">Sold Qty</th><th class="r">Return Qty</th>
  <th class="r">Unit Weight</th><th class="r">Return Weight</th>
  <th class="r">Unit Price (${nt(e)})</th><th class="r">Return Value (${nt(e)})</th>
  <th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th>
</tr></thead><tbody>${$}${x}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r"><strong>${b}</strong></td><td></td>
  <td class="r">${P(R)}</td><td></td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td><td colspan="4"></td>
</tr></tfoot></table>`}}return`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>${i(M[p])} -${i(h.event||"ZollTool")}</title>
<style>${D}</style></head><body>
${A}
${o}
<div class="signature-section"><strong>Date and Signature</strong><div class="signature-box"></div></div>
</body></html>`}function ve(e,p=null){const n=e.meta,h=e.artist,f=e.meta&&e.meta.currency?e.meta.currency:"CHF";function w(g,$){let x="";if(g===1){let s=0,a=0,c=0,m=0;const u=[];if($==="bytype"){const v={};e.products.filter(Y).forEach(t=>{const r=q(t),y=`${t.type||"Other"}\0${t.tariffNo||""}`;v[y]||(v[y]={type:t.type||"Other",tariffNo:t.tariffNo||"",tariffRate:t.tariffRate,vatRate:t.vatRate,amount:0,wkg:0,val:0,hasVal:!1});const C=v[y];C.amount+=r.amount||0,C.wkg+=r.totalWeightKg,r.totalValue!=null&&(C.val+=r.totalValue,C.hasVal=!0),s+=r.amount||0,a+=r.totalWeightKg,r.totalValue!=null&&(c+=r.totalValue)}),Object.values(v).forEach((t,r)=>{u.push(`<tr><td class="c">${r+1}</td><td><strong>${i(t.type)}</strong></td><td class="r">${i(t.tariffNo)}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="r">${t.amount}</td><td class="r">${P(t.wkg)}</td><td class="r">${t.hasVal?t.val:"—"}</td></tr>`)}),x=`<div class="section-title">List of goods (By Type)</div>
<table class="goods"><thead><tr><th>#</th><th>Type</th><th class="r">HS Code</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="r">Total Amount</th><th class="r">Total Weight</th><th class="r">Total Value (${f})</th></tr></thead>
<tbody>${u.join("")}</tbody><tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r">${s}</td><td class="r">${P(a)}</td><td class="r" style="color:#c00">${Math.floor(c)}</td></tr></tfoot></table>`}else e.products.filter(Y).forEach(t=>{var C;const r=q(t),y=t.originCountry&&t.originCountry.trim()?t.originCountry.trim().toUpperCase():X(h.countryOfOrigin)||"";if($==="detailed"&&K(t))t.variants.forEach(k=>{const O=m++,N=k.weightG!=null?k.weightG:t.weightG,S=k.price!=null?k.price:t.price,Q=k.amount||0,ot=Math.round(Q*(N||0))/1e3,it=S!=null?Math.round(S*Q):null;s+=Q,a+=ot,it!=null&&(c+=it),u.push(`<tr><td class="c">${O+1}</td><td class="mono">${i(k.sku||t.sku||"")}</td><td>${i(t.title||"")} - ${i(k.name||"")}</td><td>${t.forSale?"For Sale":"Not For Sale"}</td><td>${i(t.type||"")}</td><td class="r">${Q}</td><td class="r">${N!=null?N+" g":""}</td><td class="r">${P(ot)}</td><td class="r">${t.priceNote||(S!=null?L(E(S,2),2):"—")}</td><td class="r">${it!=null?it:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(y)}</td></tr>`)});else{const k=m++;s+=r.amount||0,a+=r.totalWeightKg,r.totalValue!=null&&(c+=r.totalValue);const O=K(t)?`${i(t.title||"")} (${t.variants.length} variants)`:`${i(t.title||"")}`;u.push(`<tr><td class="c">${k+1}</td><td class="mono">${i(t.sku||"")}</td><td>${O}</td><td>${t.forSale?"For Sale":"Not For Sale"}</td><td>${i(t.type||"")}</td><td class="r">${(C=r.amount)!=null?C:""}</td><td class="r">${r.effectiveUnitWeightG!=null?Math.round(r.effectiveUnitWeightG)+" g":""}</td><td class="r">${P(r.totalWeightKg)}</td><td class="r">${t.priceNote||(r.effectiveUnitPrice!=null?L(E(r.effectiveUnitPrice,2),2):"—")}</td><td class="r">${r.totalValue!=null?r.totalValue:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(y)}</td></tr>`)}}),x=`<div class="section-title">List of goods${$==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr><th>#</th><th>Title</th><th>SKU</th><th>For Sale / Not For Sale</th><th>Type</th><th class="r">Amount</th><th class="r">Unit Weight</th><th class="r">Total Weight</th><th class="r">Unit Price (${f})</th><th class="r">Total Value (${f})</th><th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th></tr></thead>
<tbody>${u.join("")}</tbody><tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r">${s}</td><td></td><td class="r">${P(a)}</td><td></td><td class="r" style="color:#c00">${Math.floor(c)}</td><td colspan="4"></td></tr></tfoot></table>`}else if(g===2){let s=0,a=0,c=0,m=0;const u=[];if($==="bytype"){const v={};e.products.forEach(t=>{if(!Y(t))return;const r=q(t);if(!(r.soldQty>0))return;const y=`${t.type||"Other"}\0${t.tariffNo||""}`;v[y]||(v[y]={type:t.type||"Other",tariffNo:t.tariffNo||"",tariffRate:t.tariffRate,vatRate:t.vatRate,soldQty:0,soldVal:0,soldWkg:0});const C=v[y];C.soldQty+=r.soldQty||0,C.soldVal+=E(r.soldValue||0,2),C.soldWkg+=r.soldWeightKg,s+=r.soldQty||0,a+=E(r.soldValue||0,2),c+=r.soldWeightKg}),Object.values(v).forEach((t,r)=>{u.push(`<tr><td class="c">${r+1}</td><td><strong>${i(t.type)}</strong></td><td class="r">${i(t.tariffNo)}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="r">${t.soldQty}</td><td class="r">${L(E(t.soldVal,2),2)}</td><td class="r">${P(t.soldWkg)}</td></tr>`)}),x=`<div class="section-title">List of goods sold (By Type)</div>
<table class="goods"><thead><tr><th>#</th><th>Type</th><th class="r">HS Code</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="r">Qty Sold</th><th class="r">Value Sold (${f})</th><th class="r">Sold Weight</th></tr></thead>
<tbody>${u.join("")||'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>'}</tbody>
<tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r">${s}</td><td class="r">${L(E(a,2),2)}</td><td class="r">${P(c)}</td></tr></tfoot></table>`}else e.products.forEach(t=>{if(!Y(t))return;const r=q(t);if($==="detailed"&&K(t))t.variants.forEach(y=>{if(!(y.soldQty>0))return;m++;const C=y.weightG!=null?y.weightG:t.weightG,k=E(y.soldValue||0,2),O=(y.soldQty||0)*(C||0)/1e3;s+=y.soldQty||0,a+=k,c+=O,u.push(`<tr><td class="c">${m}</td><td>${i(t.title||"")} - ${i(y.name||"")}</td><td>${i(t.type||"")}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${y.soldQty||0}</td><td class="r">${L(k,2)}</td><td class="r">${P(O)}</td></tr>`)});else if(r.soldQty>0){m++;const y=E(r.soldValue||0,2);s+=r.soldQty||0,a+=y,c+=r.soldWeightKg;const C=K(t)?`${i(t.title||"")} (${t.variants.length} variants)`:i(t.title||"");u.push(`<tr><td class="c">${m}</td><td>${C}</td><td>${i(t.type||"")}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${r.soldQty||0}</td><td class="r">${L(y,2)}</td><td class="r">${P(r.soldWeightKg)}</td></tr>`)}}),x=`<div class="section-title">List of goods sold${$==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr><th>#</th><th>Title</th><th>Type</th><th class="r">Tariff no.</th><th class="r">Qty Sold</th><th class="r">Value Sold (${f})</th><th class="r">Sold Weight</th></tr></thead>
<tbody>${u.join("")||'<tr><td colspan="7" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>'}</tbody>
<tfoot><tr><td colspan="4" style="text-align:right">TOTALS</td><td class="r">${s}</td><td class="r">${L(E(a,2),2)}</td><td class="r">${P(c)}</td></tr></tfoot></table>`}else{let s=0,a=0,c=0,m=0;const u=[];if($==="bytype"){const v={};e.products.forEach(t=>{if(!Y(t))return;const r=ht(t);if(r.retQty<=0)return;const{retQty:y,retWkg:C,retVal:k}=r,O=`${t.type||"Other"}\0${t.tariffNo||""}`;v[O]||(v[O]={type:t.type||"Other",tariffNo:t.tariffNo||"",tariffRate:t.tariffRate,vatRate:t.vatRate,retQty:0,retWkg:0,retVal:0,hasVal:!1});const N=v[O];N.retQty+=y,N.retWkg+=C,k!=null&&(N.retVal+=k,N.hasVal=!0),s+=y,a+=C,k!=null&&(c+=k)}),Object.values(v).forEach((t,r)=>{u.push(`<tr><td class="c">${r+1}</td><td><strong>${i(t.type)}</strong></td><td class="r">${i(t.tariffNo)}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="r"><strong>${t.retQty}</strong></td><td class="r">${P(t.retWkg)}</td><td class="r">${t.hasVal?t.retVal:"—"}</td></tr>`)}),x=`<div class="section-title">Return goods list (re-export) (By Type)</div>
<table class="goods"><thead><tr><th>#</th><th>Type</th><th class="r">HS Code</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="r">Return Qty</th><th class="r">Return Weight</th><th class="r">Return Value (${f})</th></tr></thead>
<tbody>${u.join("")||'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>'}</tbody>
<tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r"><strong>${s}</strong></td><td class="r">${P(a)}</td><td class="r" style="color:#c00">${Math.floor(c)}</td></tr></tfoot></table>`}else e.products.forEach(t=>{var y;if(!Y(t))return;const r=t.originCountry&&t.originCountry.trim()?t.originCountry.trim().toUpperCase():X(h.countryOfOrigin)||"";if($==="detailed"&&K(t))t.variants.forEach(C=>{const k=(C.amount||0)-(C.soldQty||0);if(k<=0)return;m++;const O=C.weightG!=null?C.weightG:t.weightG,N=C.price!=null?C.price:t.price,S=Math.round(k*(O||0))/1e3,Q=N!=null?Math.round(N*k):null;s+=k,a+=S,Q!=null&&(c+=Q),u.push(`<tr><td class="c">${m}</td><td>${i(t.title||"")} - ${i(C.name||"")}</td><td>${i(t.type||"")}</td><td class="r">${C.amount||0}</td><td class="r">${C.soldQty||0}</td><td class="r"><strong>${k}</strong></td><td class="r">${O!=null?O+" g":""}</td><td class="r">${P(S)}</td><td class="r">${t.priceNote||(N!=null?L(E(N,2),2):"—")}</td><td class="r">${Q!=null?Q:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(r)}</td></tr>`)});else{const C=ht(t);if(C.retQty<=0)return;m++;const{retQty:k,retWkg:O,retVal:N}=C,S=q(t);s+=k,a+=O,N!=null&&(c+=N);const Q=K(t)?`${i(t.title||"")} (${t.variants.filter(ot=>!ot.unlisted).length} variants)`:i(t.title||"");u.push(`<tr><td class="c">${m}</td><td>${Q}</td><td>${i(t.type||"")}</td><td class="r">${(y=S.amount)!=null?y:""}</td><td class="r">${S.soldQty||0}</td><td class="r"><strong>${k}</strong></td><td class="r">${S.effectiveUnitWeightG!=null?Math.round(S.effectiveUnitWeightG)+" g":""}</td><td class="r">${P(O)}</td><td class="r">${t.priceNote||(S.effectiveUnitPrice!=null?L(E(S.effectiveUnitPrice,2),2):"—")}</td><td class="r">${N!=null?N:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(r)}</td></tr>`)}}),x=`<div class="section-title">Return goods list (re-export)${$==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr><th>#</th><th>Title</th><th>Type</th><th class="r">Original Qty</th><th class="r">Sold Qty</th><th class="r">Return Qty</th><th class="r">Unit Weight</th><th class="r">Return Weight</th><th class="r">Unit Price (${f})</th><th class="r">Return Value (${f})</th><th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th></tr></thead>
<tbody>${u.join("")||'<tr><td colspan="14" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>'}</tbody>
<tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r"><strong>${s}</strong></td><td></td><td class="r">${P(a)}</td><td></td><td class="r" style="color:#c00">${Math.floor(c)}</td><td colspan="4"></td></tr></tfoot></table>`}return x}const M=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 8pt; color: #000; padding: 12mm; }
  .doc-section { page-break-after: always; padding-bottom: 8mm; }
  .doc-section:last-child { page-break-after: auto; }
  .page-label { font-size: 9pt; font-weight: bold; color: #555; text-transform: uppercase;
                letter-spacing: 0.05em; border-bottom: 2px solid #888; padding-bottom: 3px;
                margin-bottom: 5mm; }
  .doc-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6mm; }
  .doc-top-left .doc-title { font-size: 10pt; font-weight: bold; text-transform: uppercase; }
  .doc-top-left .doc-subtitle { font-size: 8pt; color: #444; margin-top: 2px; }
  .doc-top-right { text-align: right; }
  .doc-top-right .event-name { font-size: 11pt; font-weight: bold; }
  .doc-top-right .lrp { font-size: 8pt; margin-top: 3px; }
  .info-table { width: 100%; border-collapse: collapse; margin-bottom: 5mm; }
  .info-table td { padding: 2px 6px; font-size: 8pt; border: 1px solid #ccc; }
  .info-table td.lbl { font-weight: bold; background: #f4f4f4; width: 130px; font-size: 7.5pt; }
  .section-title { font-weight: bold; font-size: 9pt; margin: 4mm 0 2mm 0; border-bottom: 1.5px solid #000; padding-bottom: 1mm; }
  table.goods { width: 100%; border-collapse: collapse; font-size: 7pt; }
  table.goods th { background: #e8e8e8; border: 1px solid #aaa; padding: 3px 4px; text-align: left; font-size: 6.5pt; font-weight: bold; white-space: nowrap; }
  table.goods td { border: 1px solid #ccc; padding: 2px 4px; vertical-align: middle; }
  table.goods tr:nth-child(even) td { background: #fafafa; }
  table.goods tfoot td { background: #e8e8e8; font-weight: bold; border: 1px solid #aaa; padding: 3px 4px; }
  .r { text-align: right; } .c { text-align: center; }
  .signature-section { margin-top: 8mm; }
  .signature-box { border: 1px solid #000; width: 80mm; height: 22mm; margin-top: 2mm; }
  @media print { body { padding: 0; } @page { size: A4 landscape; margin: 12mm; } }`,D=`<table class="info-table">
  <tr><td class="lbl">Artist / Company Name</td><td>${i(h.companyName||"")}</td>
      <td class="lbl">Name &amp; Surname</td><td>${i(h.fullName||"")}</td></tr>
  <tr><td class="lbl">Street &amp; House Number</td><td>${i(h.street||"")}</td>
      <td class="lbl">Postcode &amp; City</td><td>${i(h.postCodeCity||"")}</td></tr>
  <tr><td class="lbl">Country of Origin</td><td>${i(h.countryOfOrigin||"")}</td>
      <td class="lbl">Phone / Mobile</td><td>${i(h.phone||"")}</td></tr>
  <tr><td class="lbl">Email</td><td colspan="3">${i(h.email||"")}</td></tr>
</table>`;function A(g){const $=Tt(e,g);return`<div class="doc-top">
  <div class="doc-top-left">
    <div class="doc-title">${i({1:"Auxiliary Document for the Customs Declaration - Import",2:"Auxiliary Document for the Customs Declaration - Sold Goods",3:"Return Goods List - Re-export Declaration"}[g])}</div>
    <div class="doc-subtitle">${i(Ft(n.eventDateStart,n.eventDateEnd))}${n.eventLocation?", "+i(n.eventLocation):""}</div>
  </div>
  <div class="doc-top-right">
    <div class="event-name">${i(n.event||"")}</div>
    <div class="lrp">LRP: ${i($||"—")}</div>
  </div>
</div>${D}`}const o=["detailed","compressed","bytype"],V={detailed:"Detailed",compressed:"Compressed",bytype:"By Type"},b=p?[p]:[1,2,3],R={1:"Import",2:"Sold",3:"Return"},z=[];return b.forEach(g=>{o.forEach($=>{const x=`${R[g]} - ${V[$]}`;z.push(`<div class="doc-section">
  <div class="page-label">${i(x)}</div>
  ${A(g)}
  ${w(g,$)}
  <div class="signature-section"><strong>Date and Signature</strong><div class="signature-box"></div></div>
</div>`)})}),`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>All Documents - ${i(n.event||"ZollTool")}</title>
<style>${M}</style></head><body>
${z.join(`
`)}
</body></html>`}function be(e,p=new Date){const n=e.meta,h=e.artist,f=e.meta&&e.meta.currency?e.meta.currency:"CHF",w=p.toLocaleDateString("en-GB",{day:"2-digit",month:"long",year:"numeric"}),M=e.products.filter(Y),D=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 9pt; color: #000; padding: 15mm; }
  .watermark { text-align: center; font-size: 8pt; color: #c00; font-weight: bold; letter-spacing: 1px;
               border: 1.5px solid #c00; padding: 4px 10px; display: inline-block; margin-bottom: 6mm; text-transform: uppercase; }
  .doc-title { font-size: 16pt; font-weight: bold; text-transform: uppercase; margin-bottom: 1mm; }
  .doc-subtitle { font-size: 8pt; color: #555; margin-bottom: 6mm; }
  .parties { display: flex; gap: 10mm; margin-bottom: 6mm; }
  .party { flex: 1; border: 1px solid #ccc; padding: 4mm; }
  .party-label { font-size: 7pt; font-weight: bold; text-transform: uppercase; color: #666; margin-bottom: 2mm; border-bottom: 1px solid #ddd; padding-bottom: 1mm; }
  .party-name { font-size: 10pt; font-weight: bold; margin-bottom: 1mm; }
  .party-detail { font-size: 8pt; line-height: 1.5; color: #222; }
  .meta-row { display: flex; gap: 8mm; margin-bottom: 6mm; font-size: 8pt; }
  .meta-item { }
  .meta-item .meta-label { font-weight: bold; font-size: 7pt; text-transform: uppercase; color: #666; }
  .meta-item .meta-value { font-size: 9pt; margin-top: 1px; }
  table.goods { width: 100%; border-collapse: collapse; font-size: 8pt; margin-bottom: 6mm; }
  table.goods th { background: #222; color: #fff; padding: 4px 6px; text-align: left; font-size: 7.5pt; white-space: nowrap; }
  table.goods th.r { text-align: right; }
  table.goods td { border-bottom: 1px solid #ddd; padding: 4px 6px; vertical-align: middle; }
  table.goods tr:nth-child(even) td { background: #f8f8f8; }
  table.goods tfoot td { background: #eee; font-weight: bold; border-top: 2px solid #555; padding: 5px 6px; }
  .r { text-align: right; }
  .total-box { border: 2px solid #000; display: inline-block; padding: 4mm 8mm; margin-bottom: 6mm; }
  .total-box .total-label { font-size: 8pt; text-transform: uppercase; color: #555; }
  .total-box .total-value { font-size: 14pt; font-weight: bold; }
  .declaration { font-size: 7.5pt; color: #333; border-top: 1px solid #ccc; padding-top: 4mm; margin-bottom: 6mm; line-height: 1.6; }
  .sig-block { display: inline-block; width: 100mm; }
  .sig-label { font-size: 7.5pt; color: #555; margin-bottom: 1mm; }
  .sig-line { border-top: 1px solid #000; padding-top: 2mm; font-size: 7.5pt; color: #777; margin-top: 10mm; }
  @media print { body { padding: 0; } @page { size: A4 portrait; margin: 15mm; } }`;let A=0,o=0,V=0;const b=M.map((g,$)=>{const x=q(g),s=x.amount||0,a=x.effectiveUnitPrice!=null?L(E(x.effectiveUnitPrice,2),2):g.priceNote||"—",c=x.totalValue!=null?x.totalValue:0,m=g.originCountry&&g.originCountry.trim()?g.originCountry.trim().toUpperCase():X(h.countryOfOrigin)||"";return A+=s,o+=c,V+=x.totalWeightKg,`<tr>
      <td class="r">${$+1}</td>
      <td>${i(g.title||"")}</td>
      <td>${i(g.tariffNo||"—")}</td>
      <td class="r">${s}</td>
      <td class="r">${x.effectiveUnitWeightG!=null?Math.round(x.effectiveUnitWeightG)+" g":"—"}</td>
      <td class="r">${P(x.totalWeightKg)}</td>
      <td class="r">${i(String(a))}</td>
      <td class="r">${x.totalValue!=null?x.totalValue:"—"}</td>
      <td class="r">${m}</td>
    </tr>`}).join(""),R=[n.venueName||h.fullName||h.companyName||"",n.event?"c/o "+n.event:"",n.venueStreet||"",[n.venuePostcode,n.venueCity].filter(Boolean).join(" "),n.venueCountry||""].filter(Boolean).join("<br>"),z=[h.companyName||"",h.fullName||"",h.street||"",h.postCodeCity||"",h.countryOfOrigin||""].filter(Boolean).join("<br>");return`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>Proforma Invoice -${i(n.event||"ZollTool")}</title>
<style>${D}</style></head><body>
<div class="watermark">For Customs Clearance Purposes Only &mdash; Not for Commercial Use</div>
<div class="doc-title">Proforma Invoice</div>
<div class="doc-subtitle">This document is issued solely for customs clearance and does not constitute a commercial transaction.</div>

<div class="parties">
  <div class="party">
    <div class="party-label">Seller / Exporter</div>
    <div class="party-name">${i(h.companyName||h.fullName||"")}</div>
    <div class="party-detail">${z}</div>
  </div>
  <div class="party">
    <div class="party-label">Consignee / Importer</div>
    <div class="party-name">${i(n.venueName||h.fullName||"")}</div>
    <div class="party-detail">${R}</div>
  </div>
</div>

<div class="meta-row">
  <div class="meta-item"><div class="meta-label">Invoice Date</div><div class="meta-value">${w}</div></div>
  <div class="meta-item"><div class="meta-label">Event</div><div class="meta-value">${i(n.event||"—")}</div></div>
  <div class="meta-item"><div class="meta-label">Event Dates</div><div class="meta-value">${i([n.eventDateStart,n.eventDateEnd].filter(Boolean).join(" – ")||"—")}</div></div>
  <div class="meta-item"><div class="meta-label">Currency</div><div class="meta-value">${i(f)}</div></div>
</div>

<table class="goods">
  <thead><tr>
    <th class="r">#</th>
    <th>Description</th>
    <th>HS / Tariff Code</th>
    <th class="r">Qty</th>
    <th class="r">Unit Weight</th>
    <th class="r">Total Weight</th>
    <th class="r">Unit Value (${i(f)})</th>
    <th class="r">Total Value (${i(f)})</th>
    <th class="r">Origin</th>
  </tr></thead>
  <tbody>${b||'<tr><td colspan="9" style="text-align:center;padding:8px;color:#888">No products with customs information</td></tr>'}</tbody>
  <tfoot><tr>
    <td></td><td style="text-align:right">TOTALS</td><td></td>
    <td class="r">${A}</td><td></td>
    <td class="r">${P(V)}</td><td></td>
    <td class="r">${Math.floor(o)}</td><td></td>
  </tr></tfoot>
</table>

<div class="total-box">
  <div class="total-label">Total Declared Value</div>
  <div class="total-value">${i(f)} ${Math.floor(o).toLocaleString("de-CH")}</div>
  <div class="total-label" style="margin-top:3mm">Total Gross Weight</div>
  <div class="total-value">${P(V)}</div>
</div>

<div class="declaration">
  <strong>Declaration:</strong> I, the undersigned, hereby certify that the information on this proforma invoice is true and correct
  and that the contents of this consignment are as stated above. This invoice is issued for customs clearance purposes only
  and does not represent a commercial sale. The goods are temporarily imported into ${i(n.venueCountry||"the destination country")} for exhibition/sale at
  ${i(n.event||"the event")} and will be re-exported or accounted for after the event.
</div>

<div class="sig-block">
  <div class="sig-label">Signature &amp; Date</div>
  <div class="sig-line">${i(h.fullName||h.companyName||"")} &nbsp;&nbsp;·&nbsp;&nbsp; Date: _______________</div>
</div>
</body></html>`}function ye(e,p=new Date){const n=e.meta,h=e.artist,f=e.edec,w=X(h.countryOfOrigin)||"",M=Lt[w]||w,D=[h.companyName,h.fullName,h.street,h.postCodeCity,M].filter(Boolean).join(`
`),A=[n.event,n.venueStreet,[n.venuePostcode,n.venueCity].filter(Boolean).join(" "),n.venueCountry||""].filter(Boolean).join(`
`),o=(f.transportationCountry||"").trim().toUpperCase(),V=f.transportMode||"3",b=V==="4",R=(f.flightNumber||"").trim(),W={1:"80",2:"20",3:"30",4:"40",5:"50",9:"90"}[V]||"30",g=V==="3"&&o||w,$=(n.venuePostcode||"").trim()||"______",{g1:x,g2:s,hasG2:a}=Vt(e),c=e.products.map(N=>N.title).filter(Boolean).join(", "),m=p.toLocaleDateString("de-CH",{day:"2-digit",month:"2-digit",year:"numeric"}),u=(N,S=!1)=>N?`<span class="fv${S?" warn":""}">${i(N)}</span>`:'<span class="ev">——</span>',v=N=>N?`<span class="fv pre">${i(N)}</span>`:'<span class="ev">——</span>';function t(N,S){return`<div class="ch"><span class="cn">${i(N)}</span><span class="cl">${i(S)}</span></div>`}function r(N,S=""){const Q=S?` style="text-align:${S}"`:"";return N?`<td${Q}><span class="gfv">${i(N)}</span></td>`:`<td${Q}></td>`}function y(N,S,Q){return`<tr>
      <td class="rn">${N}</td>
      ${r(S)}
      ${r(Q)}
    </tr>`}function C(N,S,Q,ot,it,gt){return`<tr>
      <td class="rn">${N}</td>
      <td></td><td></td>
      ${r(S,"center")}
      <td></td>
      ${r(Q,"right")}
      ${r(ot,"center")}
      ${r(it,"right")}
      ${r(gt,"right")}
      <td></td><td></td>
    </tr>`}return`<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<title>Formular 11.74 -${i(n.event||"ZollTool")}</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, Helvetica, sans-serif; font-size: 6.5pt; color: #000; background: #b0b0b0; }

.print-bar {
  background: #222; color: #fff; padding: 7px 14px; font-size: 10pt;
  display: flex; align-items: center; gap: 12px; position: sticky; top: 0; z-index: 9;
}
.print-bar button {
  background: #1a6ecc; color: #fff; border: none; padding: 5px 16px;
  font-size: 10pt; cursor: pointer; border-radius: 3px; font-weight: bold;
}
.print-bar .hint { font-size: 7.5pt; color: #aaa; }

.page {
  width: 210mm; min-height: 297mm; margin: 8mm auto;
  background: #fff; display: flex; border: 1px solid #444;
}

/* ── Side strips ── */
.strip {
  width: 13mm; background: #f3accc; flex-shrink: 0;
  display: flex; flex-direction: column; align-items: center;
  padding: 3mm 1mm; position: relative; overflow: hidden;
}
.strip-a { font-size: 18pt; font-weight: bold; color: #000; line-height: 1; flex-shrink: 0; }
.strip-title {
  font-size: 4.5pt; color: #000; writing-mode: vertical-rl;
  transform: rotate(180deg); margin-top: 4mm; line-height: 1.5;
  white-space: nowrap; flex-shrink: 0;
}
.strip-r .strip-a { margin-top: auto; }

/* ── Form body ── */
.fb { flex: 1; display: flex; flex-direction: column; border-left: 0.5px solid #666; border-right: 0.5px solid #666; }

/* ── Cell base ── */
.cell { border: 0.5px solid #666; padding: 1.2mm 1.5mm; position: relative; min-height: 10mm; }
.ch { display: flex; align-items: baseline; gap: 1.5mm; margin-bottom: 1mm; }
.cn { font-size: 5.5pt; font-weight: bold; color: #444; white-space: nowrap; flex-shrink: 0; }
.cl { font-size: 4.8pt; color: #555; line-height: 1.3; }
.cv { font-size: 7pt; line-height: 1.5; }

/* Pre-filled values */
.fv     { font-weight: bold; color: #003ab5; }
.fv.pre { white-space: pre-wrap; }
.fv.warn { font-weight: bold; color: #cc0000; }
.ev     { color: #bbb; font-style: italic; }
.warn-note { font-size: 5pt; color: #cc0000; font-style: italic; margin-top: 1mm; }

/* ── Header row ── */
.hdr { display: flex; border-bottom: 0.5px solid #666; align-items: stretch; }
.hdr-admin { flex: 0 0 auto; padding: 1.5mm 2mm; font-size: 4.8pt; line-height: 1.5; border-right: 0.5px solid #666; }
.hdr-copy  { flex: 1; padding: 1.5mm 2mm; font-size: 5pt; display: flex; align-items: flex-end; }
.hdr-num   { flex: 0 0 auto; padding: 1.5mm 3mm; border-left: 0.5px solid #666; text-align: right; }
.form-number { font-size: 22pt; font-weight: bold; line-height: 1; }
.form-ref    { font-size: 4.5pt; color: #666; }

/* ── Top section (fields 1-13) ── */
.top { display: flex; border-bottom: 0.5px solid #666; }
.lc  { flex: 0 0 56%; border-right: 0.5px solid #666; display: flex; flex-direction: column; }
.lc .cell { border: none; border-bottom: 0.5px solid #666; flex: 1; }
.lc .cell:last-child { border-bottom: none; }

.rc { flex: 1; display: flex; flex-direction: column; }
.rc .cell { border: none; border-bottom: 0.5px solid #666; }
.rc .cell:last-child { border-bottom: none; flex: 1; }
.rc-top { display: flex; border-bottom: 0.5px solid #666; }
.rc-top .cell { border: none; flex: 1; }
.rc-top .cell:first-child { border-right: 0.5px solid #666; }

/* ── Field 4/5 / 14/15 section ── */
.mid { display: flex; border-bottom: 0.5px solid #666; }
.ml { flex: 0 0 56%; border-right: 0.5px solid #666; display: flex; flex-direction: column; }
.ml .cell { border: none; border-bottom: 0.5px solid #666; }
.ml .cell:last-child { border-bottom: none; flex: 1; }
.mr { flex: 1; display: flex; flex-direction: column; }
.mr .cell { border: none; border-bottom: 0.5px solid #666; }
.mr .cell:last-child { border-bottom: none; flex: 1; }

.cb-row { display: flex; gap: 3mm; flex-wrap: wrap; margin: 1mm 0; }
.cb { display: inline-flex; align-items: center; gap: 1mm; font-size: 5pt; color: #333; }
.cb-box { width: 3mm; height: 3mm; border: 0.5px solid #555; display: inline-block; flex-shrink: 0; background: #fff; }
.cb-box.chk { background: #000; }
.f4sub { font-size: 5pt; color: #555; margin-top: 1mm; line-height: 1.7; }

/* ── Goods table ── */
.gt-wrap { border-bottom: 0.5px solid #666; }
table.gt {
  width: 100%; border-collapse: collapse; font-size: 5pt; table-layout: fixed;
}
table.gt th, table.gt td {
  border: 0.5px solid #666; padding: 0.8mm 1mm; vertical-align: top;
}
table.gt th { font-weight: bold; font-size: 4.8pt; line-height: 1.3; background: #fff; }
table.gt td { height: 16mm; vertical-align: top; }
td.rn    { text-align: center; font-size: 8pt; font-weight: bold; vertical-align: top; padding-top: 1.5mm; }
.gfv     { font-weight: bold; color: #003ab5; font-size: 5.5pt; white-space: pre-wrap; }
.th-hint { display: block; font-size: 4pt; color: #c00; font-weight: normal; margin-top: 1mm; line-height: 1.3; }

/* Description table (16 + 17) column widths */
col.d-rn { width: 3%; }
col.d-16 { width: 14%; }
/* col.d-17 fills remaining */

/* Numeric table (18–27) column widths -must total 100% */
col.n-rn { width: 3%; }
col.n-18 { width: 5%; }
col.n-19 { width: 5%; }
col.n-20 { width: 15%; }
col.n-21 { width: 6%; }
col.n-22 { width: 12%; }
col.n-23 { width: 11%; }
col.n-24 { width: 13%; }
col.n-25 { width: 15%; }
col.n-26 { width: 7.5%; }
col.n-27 { width: 7.5%; }

/* ── Bottom section ── */
.bot { display: flex; flex: 1; }
.bl  { flex: 0 0 56%; border-right: 0.5px solid #666; display: flex; flex-direction: column; }
.bl .cell { border: none; border-bottom: 0.5px solid #666; }
.bl .cell:last-child { border-bottom: none; flex: 1; }
.br  { flex: 1; display: flex; flex-direction: column; }
.br .cell { border: none; border-bottom: 0.5px solid #666; }
.br .cell:last-child { border-bottom: none; flex: 1; }

/* Horizontal field: label left, value right */
.hfield { display: flex; align-items: center; gap: 2mm; }
.hfield-label { flex: 1; }
.hfield-value { flex: 0 0 auto; font-size: 8pt; font-weight: bold; color: #003ab5;
                border-left: 0.5px solid #ccc; padding-left: 2mm; min-width: 10mm; text-align: center; }

.sig-line { border-bottom: 0.5px solid #888; min-height: 10mm; margin-top: 1.5mm; }
.sig-note { font-size: 4.8pt; color: #cc0000; font-style: italic; margin-top: 0.8mm; }
.subtotal-label { font-size: 4.8pt; color: #555; margin: 1.5mm 0 0.5mm 0; }

@media print {
  .print-bar { display: none; }
  body { background: #fff; }
  .page { margin: 0; border: none; box-shadow: none; }
  @page { size: A4 portrait; margin: 0mm; }
}</style></head><body>

<div class="print-bar">
  <button onclick="window.print()">🖨&nbsp; Print / Save as PDF</button>
  <span class="hint">Pre-filled values shown in <strong style="color:#6699ee">bold blue</strong> &nbsp;·&nbsp; Verify all fields before signing &nbsp;·&nbsp; ${i(n.event||"")} &nbsp;·&nbsp; Generated ${m}</span>
</div>

<div class="page">

  <!-- Left pink strip -->
  <div class="strip">
    <div class="strip-a">A</div>
    <div class="strip-title">Vorübergehende Verwendung mit hinterlegtem Betrag · Admission temporaire à montant déposé · Ammissione temporanea con importo depositato</div>
  </div>

  <!-- Form body -->
  <div class="fb">

    <!-- Header -->
    <div class="hdr">
      <div class="hdr-admin">
        Eidgenössische Zollverwaltung EZV<br>
        Administration fédérale des douanes AFD<br>
        Amministrazione federale delle dogane AFD
      </div>
      <div class="hdr-copy">Kopie für / Copie pour / Copia per &nbsp;→</div>
      <div class="hdr-num">
        <div class="form-number">11.74</div>
        <div class="form-ref">606.000.11.74</div>
      </div>
    </div>

    <!-- Fields 1–13 -->
    <div class="top">
      <div class="lc">
        <div class="cell">
          ${t("1","Versender / Expéditeur / Speditore")}
          <div class="cv">${v(D)}</div>
        </div>
        <div class="cell">
          ${t("2","Eigentümer der Ware / Propriétaire de la marchandise / Proprietario della merce")}
          <div class="cv">${v(D)}</div>
        </div>
        <div class="cell">
          ${t("3","Empfänger/Importeur / Destinataire/Importateur / Destinatario/Importatore")}
          <div class="cv">${v(A)}</div>
        </div>
      </div>
      <div class="rc">
        <div class="rc-top">
          <div class="cell">
            ${t("6","Vordokument / Document précédent / Documento precedente")}
            <div class="cv">${b&&R?u(R):'<span style="font-size:5pt;color:#888">Nr. / No / N. ___________</span>'}</div>
          </div>
          <div class="cell">
            ${t("7","Konto-Nr. / Compte No / Conto N.")}
            <div class="cv"><span class="ev">——</span></div>
          </div>
        </div>
        <div class="cell" style="min-height:7mm">
          ${t("8","Einfuhr / Import. / Import")}
          <div class="cv">
            <span class="cb"><span class="cb-box chk"></span> Einfuhr / Import. / Import</span>
            &nbsp;&nbsp;
            <span class="cb"><span class="cb-box"></span> Ausfuhr / Export. / Esport.</span>
          </div>
        </div>
        <div class="cell" style="min-height:7mm">
          ${t("9","Verfalldatum / Echéance / Scadenza")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell hfield" style="min-height:7mm">
          <div class="hfield-label">${t("10","Ursprungsland / Pays d'origine / Paese d'origine")}</div>
          <div class="hfield-value">${u(w)}</div>
        </div>
        <div class="cell hfield" style="min-height:7mm">
          <div class="hfield-label">${t("11","Land der vorübergehenden Bestimmung / Pays de destination temporaire / Paese di destinazione temporanea")}</div>
          <div class="hfield-value">${u(X(n.venueCountry)||"CH")}</div>
        </div>
        <div class="cell hfield" style="min-height:7mm">
          <div class="hfield-label">${t("12","Land der endgültigen Bestimmung / Pays de destination définitive / Paese di destinazione definitiva")}</div>
          <div class="hfield-value">${u(w)}</div>
        </div>
        <div class="cell">
          ${t("13","Verwendungszweck der Ware / Emploi de la marchandise / Scopo d'impiego della merce")}
          <div class="cv">${u("Verkauf an Ausstellungen / Messen · Vente aux expositions / foires")}</div>
        </div>
      </div>
    </div>

    <!-- Field 4 / 5 + 14 / 15 -->
    <div class="mid">
      <div class="ml">
        <div class="cell">
          ${t("4","Präferenzbehandlung / Régime préférentiel / Trattamento preferenziale")}
          <div class="cb-row">
            <span class="cb"><span class="cb-box"></span> Europäische Freihandelszone / Zone européenne de libre-échange / Zona europea di libero scambio</span>
          </div>
          <div class="cb-row">
            <span class="cb"><span class="cb-box"></span> Allgemeines Präferenzsystem / Système généralisé de préférences / Sistema generale di preferenze</span>
          </div>
          <div class="f4sub">
            WVB/UZ Nr. _________ vom / CCM/CO No _________ du / CCM/CO N. _________ del
          </div>
        </div>
        <div class="cell">
          ${t("5","VTS/SMT · Immat. Land / Pays d'immatr. / Paese d'immatr. · PLZ/NPA/CAP")}
          <div style="display:flex;gap:2mm;align-items:flex-start;margin-top:1mm">
            <div style="flex:0 0 auto;border-right:0.5px solid #ccc;padding-right:2mm">
              <div style="font-size:4pt;color:#666;margin-bottom:0.5mm">VTS/SMT</div>
              <span class="fv">${i(W)}</span>
            </div>
            <div style="flex:0 0 auto;border-right:0.5px solid #ccc;padding-right:2mm">
              <div style="font-size:4pt;color:#666;margin-bottom:0.5mm">Immat. Land / Pays / Paese</div>
              <span class="fv">${i(g||"______")}</span>
            </div>
            <div style="flex:0 0 auto">
              <div style="font-size:4pt;color:#666;margin-bottom:0.5mm">PLZ/NPA/CAP</div>
              <span class="fv">${i($)}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="mr">
        <div class="cell" style="min-height:8mm">
          ${t("14","Mietgeschäft / Location / Locazione")}
          <div class="cv">
            <span class="cb"><span class="cb-box"></span> ja / oui / sì</span>
            &nbsp;&nbsp;
            <span class="cb"><span class="cb-box"></span> nein / non / no</span>
          </div>
        </div>
        <div class="cell">
          ${t("15","Abschlusszollstelle / Bureau de douane d'apurement / Ufficio doganale della conclusione")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
      </div>
    </div>

    <!-- Goods table: 16 + 17 (description) -->
    <div class="gt-wrap" style="border-bottom:none">
      <table class="gt">
        <colgroup>
          <col class="d-rn"><col class="d-16"><!-- d-17 fills rest -->
        </colgroup>
        <thead><tr>
          <th></th>
          <th>16 Zeichen, Nr., Anzahl, Verpackung<br>Marque, no, nombre, emballage<br>Marca, n., quantità, imballaggio</th>
          <th>17 Genaue Warenbezeichnung (Material, Typ, Nummern, etc.), die eine Identifikation der Ware sicherstellt<br>Désignation exacte de la marchandise (matière, type, numéros, etc.) garantissant son identification<br>Designazione esatta della merce (materiale, tipo, numeri, ecc.), che garantisce l'identificazione della merce</th>
        </tr></thead>
        <tbody>
          ${y(1,"see attached list",c||"—")}
          ${a?y(2,"",""):""}
        </tbody>
      </table>
    </div>

    <!-- Goods table: 18–27 (numeric columns) -->
    <div class="gt-wrap">
      <table class="gt">
        <colgroup>
          <col class="n-rn"><col class="n-18"><col class="n-19"><col class="n-20">
          <col class="n-21"><col class="n-22"><col class="n-23">
          <col class="n-24"><col class="n-25"><col class="n-26"><col class="n-27">
        </colgroup>
        <thead><tr>
          <th></th>
          <th>18<br>NHW<br>MNC<br><span class="th-hint">Statistical goods code - leave blank if unknown</span></th>
          <th>19<br>VC<br>CT<br><span class="th-hint">Mode of transport carrier code - leave blank</span></th>
          <th>20 Tarif-Nr.<br>No de tarif<br>Voce di tariffa<br><span class="th-hint">HS tariff number of the goods</span></th>
          <th>21<br>Schlüssel<br>Clé<br>N.conv.<br><span class="th-hint">Quantity unit/conversion key - leave blank</span></th>
          <th>22 Eigenmasse<br>Masse nette<br>Massa netta<br><span class="th-hint">Net weight in kg (without packaging)</span></th>
          <th>23 Zusatzmenge<br>Unités suppl.<br>Unità suppl.<br><span class="th-hint">Total number of individual items</span></th>
          <th>24 Rohmasse<br>Masse brute<br>Massa lorda<br><span class="th-hint">Gross weight in kg (incl. packaging)</span></th>
          <th>25 Stat. Wert in CHF<br>Valeur stat. CHF<br>Valore stat. CHF<br><span class="th-hint">Total value in CHF (numbers only, no currency symbol)</span></th>
          <th>26 Ansatz<br>Taux<br>Aliquota<br><span class="th-hint">Duty rate in % - customs fills this in</span></th>
          <th>27 Betrag<br>Montant<br>Importo<br><span class="th-hint">Duty amount in CHF - customs fills this in</span></th>
        </tr></thead>
        <tbody>
          ${C(1,x.tariffNo!=="—"?x.tariffNo:"",String(Math.round(x.weightKg)),String(x.qty),String(Math.round(x.weightKg)),String(Math.floor(x.value)))}
          ${a?C(2,s.tariffNo!=="—"?s.tariffNo:"",String(Math.round(s.weightKg)),String(s.qty),String(Math.round(s.weightKg)),String(Math.floor(s.value))):""}
        </tbody>
      </table>
    </div>

    <!-- Bottom: 28–31 + 32 -->
    <div class="bot">
      <div class="bl">
        <div class="cell" style="min-height:8mm">
          ${t("28","Verwender der Ware / Utilisateur de la marchandise / Utilizzatore della merce")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell" style="min-height:8mm">
          ${t("29","MWST-Nr. / No TVA / N. IVA &nbsp;&nbsp; MWST-Code / Code-TVA / Codice-IVA")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell" style="min-height:8mm">
          ${t("30","Bewilligung usw. / Permis, etc. / Permesso, ecc.")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell">
          ${t("31","Ort/Datum · Lieu/date · Luogo/data &nbsp;&nbsp; Der Anmelder / Le déclarant / Il dichiarante &nbsp;&nbsp; Ref. / Réf. / Rif.")}
          <div style="display:flex;gap:4mm;margin-top:1mm">
            <div style="flex:0 0 auto">
              <div style="font-size:4.8pt;color:#555">Ort/Datum</div>
              <div class="fv" style="font-size:7pt">${i(m)}</div>
            </div>
            <div style="flex:1">
              <div style="font-size:4.8pt;color:#555">Der Anmelder / Le déclarant / Il dichiarante</div>
              <div class="fv" style="font-size:7pt">${i(h.fullName||"—")}</div>
              <div class="sig-note">→ Recommended: person paying the customs deposit</div>
            </div>
            <div style="flex:1">
              <div style="font-size:4.8pt;color:#555">Unterschrift / Signature / Firma</div>
              <div class="sig-line"></div>
              <div class="sig-note">→ Recommended: person paying the customs deposit</div>
            </div>
          </div>
        </div>
      </div>
      <div class="br">
        <div class="cell" style="min-height:14mm">
          ${t("32","Zollabgaben / Droits de douane / Tributi doganali")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell">
          <div class="subtotal-label">Subtotal / Total int. / Subtotale</div>
          <div class="cv"><span class="ev">——</span></div>
          <div class="subtotal-label">Einfuhrabgaben / Redevances d'entrée / Diritti d'entrata</div>
          <div class="cv"><span class="ev">——</span></div>
          <div class="subtotal-label">Annahme / Acceptation / Accettazione</div>
          <div class="cv"><span class="ev">——</span></div>
        </div>
      </div>
    </div>

  </div>

  <!-- Right pink strip -->
  <div class="strip strip-r">
    <div class="strip-a">A</div>
  </div>

</div>
</body></html>`}function xe(e,p=new Date){const n=e.meta,h=e.artist,f=e.edec,w=X(h.countryOfOrigin)||"",M=Lt[w]||w,D=[h.companyName,h.fullName,h.street,h.postCodeCity,M].filter(Boolean).join(`
`),A=f.transportMode||"3",o=(f.transportationCountry||"").trim().toUpperCase(),b={1:"80",2:"20",3:"30",4:"40",5:"50",9:"90"}[A]||"30",R=A==="3"&&o||w,z=(n.venuePostcode||"").trim()||"______",W=[n.event,n.venueStreet,[n.venuePostcode,n.venueCity].filter(Boolean).join(" "),n.venueCountry||""].filter(Boolean).join(`
`),g=p.toLocaleDateString("de-CH",{day:"2-digit",month:"2-digit",year:"numeric"}),$=n.venueCity||"",{g1:x,g2:s,hasG2:a,g1prods:c,g2prods:m}=Vt(e),u=S=>String(S==null?"":S).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),v=S=>S?`<span class="fv">${u(S)}</span>`:'<span class="ev">——</span>',t=S=>S?`<span class="fv pre">${u(S)}</span>`:'<span class="ev">——</span>';function r(S,Q){return`<div class="ch"><span class="cn">${S}</span><span class="cl">${Q}</span></div>`}function y(S,Q){return S?`<td style="text-align:${Q||"right"}"><span class="gfv">${u(String(S))}</span></td>`:"<td></td>"}const C=`
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, Helvetica, sans-serif; font-size: 6pt; color: #000; background: #b0b0b0; }
.print-bar { background:#222; color:#fff; padding:7px 14px; font-size:10pt; display:flex; align-items:center; gap:12px; position:sticky; top:0; z-index:9; }
.print-bar button { background:#1a6ecc; color:#fff; border:none; padding:5px 16px; font-size:10pt; cursor:pointer; border-radius:3px; font-weight:bold; }
.print-bar .hint { font-size:7.5pt; color:#aaa; }
.page { width:210mm; min-height:297mm; margin:8mm auto; background:#fff; display:flex; flex-direction:column; border:1px solid #444; }

/* Header */
.hdr { display:flex; border-bottom:0.5px solid #000; flex-shrink:0; }
.hdr-logo { width:68mm; padding:2mm; border-right:0.5px solid #000; font-size:4.5pt; line-height:1.4; }
.hdr-logo strong { font-size:5pt; }
.hdr-copy { flex:1; padding:2mm 3mm; border-right:0.5px solid #000; font-size:5pt; }
.hdr-num { padding:2mm 4mm; display:flex; align-items:center; }
.form-number { font-size:30pt; font-weight:bold; letter-spacing:1pt; }

/* Body wrapper */
.body-wrap { display:flex; flex:1; }
.strip { width:13mm; background:#009f68; flex-shrink:0; display:flex; flex-direction:column; align-items:center; padding:3mm 1mm; }
.strip-a { font-size:18pt; font-weight:bold; color:#000; line-height:1; flex-shrink:0; }
.strip-title { font-size:4.5pt; color:#000; writing-mode:vertical-rl; transform:rotate(180deg); margin-top:4mm; line-height:1.5; white-space:nowrap; flex-shrink:0; }
.strip-instr { font-size:3.8pt; color:#000; writing-mode:vertical-rl; transform:rotate(180deg); margin-top:auto; line-height:1.4; white-space:nowrap; flex-shrink:0; }
.fb { flex:1; display:flex; flex-direction:column; }

/* Top grid */
.top-grid { display:flex; border-bottom:0.5px solid #666; }
.lc { flex:0 0 46%; border-right:0.5px solid #666; display:flex; flex-direction:column; }
.rc { flex:1; display:flex; flex-direction:column; }
.hfield { display:flex; gap:2mm; align-items:flex-start; }
.hfield-label { flex:1; }
.hfield-value { flex:0 0 12mm; text-align:right; }
.sig-note { font-size:4pt; color:#cc0000; margin-top:0.5mm; font-style:italic; }

.cell { border-bottom:0.5px solid #666; padding:1mm 1.5mm; }
.cell:last-child { border-bottom:none; }
.ch { display:flex; align-items:baseline; gap:1mm; margin-bottom:0.5mm; }
.cn { font-size:6pt; font-weight:bold; flex-shrink:0; }
.cl { font-size:4pt; color:#555; line-height:1.3; }
.fv { font-weight:bold; color:#003ab5; font-size:7pt; }
.fv.pre { white-space:pre-wrap; font-size:6.5pt; }
.ev { font-size:5.5pt; color:#aaa; font-style:italic; }
.cb { font-size:5pt; display:inline-flex; align-items:center; gap:1mm; margin-right:2.5mm; }
.cb-box { display:inline-block; width:3mm; height:3mm; border:0.5px solid #000; flex-shrink:0; background:#fff; }
.cb-box.chk { background:#000; }

/* Row splitting in rc */
.rc-row { display:flex; border-bottom:0.5px solid #666; }
.rc-row:last-child { border-bottom:none; }
.rc-row .cell { border-bottom:none; }
.rc-row .cell + .cell { border-left:0.5px solid #666; }

/* Field 12 horizontal */
.f12-seg { flex:0 0 auto; border-right:0.5px solid #ccc; padding-right:2mm; margin-right:2mm; }
.f12-seg:last-child { border-right:none; }
.f12-lbl { font-size:3.8pt; color:#666; margin-bottom:0.5mm; }

/* Goods table */
.gt-wrap { border-top:0.5px solid #666; }
.gt { width:100%; border-collapse:collapse; table-layout:fixed; }
.gt th, .gt td { border:0.5px solid #777; padding:0.5mm 0.8mm; vertical-align:top; font-size:4.5pt; }
.gt th { font-weight:600; background:#f4f4f4; line-height:1.3; }
.gt .rn { width:4mm; text-align:center; font-weight:bold; font-size:6pt; }
.gt .data-row td { height:14mm; }
.gfv { font-size:7pt; font-weight:bold; color:#003ab5; }

/* Footer */
.footer { display:flex; border-top:0.5px solid #666; }
.f24 { flex:0 0 52%; border-right:0.5px solid #666; padding:1.5mm; }
.f25 { flex:1; padding:1.5mm; }
.sig-line { border-top:0.5px solid #888; margin-top:5mm; padding-top:0.5mm; font-size:4pt; color:#888; }
.customs-bar { border-top:0.5px solid #666; padding:1mm 1.5mm; font-size:4.5pt; color:#555; }
.customs-boxes { display:flex; gap:3mm; margin-top:1mm; }
.customs-box { flex:1; border:0.5px solid #aaa; min-height:12mm; padding:0.5mm 1mm; font-size:4pt; color:#888; }
.form-footer { text-align:center; font-size:4.5pt; color:#777; padding:1mm; border-top:0.5px solid #eee; }
@media print {
  .print-bar { display:none; }
  body { background:#fff; }
  .page { margin:0; border:none; }
}`,O=[...c||[],...a?m||[]:[]].filter(S=>Math.max(0,(S.amount||0)-(S.soldQty||0))>0).map(S=>S.title).filter(Boolean).join(", ");return`<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<title>Formular 11.87 -${u(n.event||"ZollTool")}</title>
<style>${C}</style></head><body>
<div class="print-bar">
  <button onclick="window.print()">Print / Save PDF</button>
  <span class="hint">Formular 11.87 - Vorübergehende Verwendung / Abschluss · pre-filled preview</span>
</div>
<div class="page">

  <!-- Header -->
  <div class="hdr">
    <div class="hdr-logo">
      &#x2295; Schweizerische Eidgenossenschaft · Confédération suisse · Confederazione Svizzera · Confederaziun svizra<br><br>
      <strong>Bundesamt für Zoll und Grenzsicherheit BAZG</strong><br>
      Office fédéral de la douane et de la sécurité des frontières OFDF<br>
      Ufficio federale della dogana e della sicurezza dei confini UDSC<br>
      Uffizi federal da la duana e da la segirezza dals cunfins UDSC
    </div>
    <div class="hdr-copy">Kopie für<br>Copie pour<br>Copia per &nbsp; ________________________</div>
    <div class="hdr-num"><div class="form-number">11.87</div></div>
  </div>

  <!-- Body -->
  <div class="body-wrap">
    <div class="strip">
      <div class="strip-a">A</div>
      <div class="strip-title">Vorübergehende Verwendung / Abschluss · Admission temporaire / Apurement · Ammissione temporanea / Conclusione</div>
      <div class="strip-instr">Anleitung für das Ausfüllen siehe Rückseite von Abschnitt C · Directives pour l'établissement, voir au verso du feuillet C · Istruzioni per l'allestimento, vedi a tergo della cedola C</div>
    </div>
    <div class="fb">

      <!-- Top grid -->
      <div class="top-grid">
        <!-- Left column: 1, 2, 3, 4 -->
        <div class="lc">
          <div class="cell" style="min-height:22mm">
            ${r("1","Versender / Expéditeur / Speditore")}
            ${t(W)}
          </div>
          <div class="cell" style="min-height:12mm">
            ${r("2","Eigentümer der Ware / Propriétaire de la marchandise / Proprietario della merce")}
            ${t(D)}
          </div>
          <div class="cell" style="min-height:12mm">
            ${r("3","Empfänger/Importeur/Verwender / Destinataire/Importateur/Utilisateur / Destinatario/Importatore/Utilizzatore")}
            ${t(D)}
          </div>
          <div class="cell" style="min-height:16mm; border-bottom:none; flex:1">
            ${r("4","ab 11.73/11.74")}
            <div style="font-size:5pt; line-height:2.4; color:#333; margin-top:1mm">
              Nr. / No / N. &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:28mm">&nbsp;</span><br>
              vom / du / del &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:24mm">&nbsp;</span><br>
              Zollstelle &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:18mm">&nbsp;</span>
            </div>
          </div>
        </div>

        <!-- Right column: 5–12 -->
        <div class="rc">
          <div class="rc-row" style="min-height:14mm">
            <div class="cell" style="flex:1">
              ${r("5","Vordokument / Document précédent / Documento precedente")}
              <div style="margin-top:1mm; font-size:5pt; color:#333">
                Nr. / No / N. &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:22mm">&nbsp;</span>
              </div>
            </div>
            <div class="cell" style="flex:0 0 36mm">
              ${r("6","Einfuhr / Import. &nbsp;&nbsp; Ausfuhr / Export.")}
              <div style="margin-top:1.5mm">
                <span class="cb"><span class="cb-box"></span> Einfuhr</span>
                <span class="cb"><span class="cb-box chk"></span> Ausfuhr</span>
              </div>
            </div>
          </div>
          <div class="cell hfield" style="min-height:7mm">
            <div class="hfield-label">${r("7","Ursprungsland / Pays d'origine / Paese d'origine")}</div>
            <div class="hfield-value">${v(w||"——")}</div>
          </div>
          <div class="cell hfield" style="min-height:7mm">
            <div class="hfield-label">${r("8","Land der vorübergehenden Bestimmung / Pays de destination temporaire / Paese di destinazione temporanea")}</div>
            <div class="hfield-value">${v(X(n.venueCountry)||"CH")}</div>
          </div>
          <div class="cell hfield" style="min-height:7mm">
            <div class="hfield-label">${r("9","Land der endgültigen Bestimmung / Pays de destination définitive / Paese di destinazione definitiva")}</div>
            <div class="hfield-value">${v(w||"——")}</div>
          </div>
          <div class="cell" style="min-height:8mm">
            ${r("10","Zweck der vorübergehenden Verwendung / But de l'admission temporaire / Scopo dell'ammissione temporanea")}
            ${v("Verkauf an Ausstellungen / Messen · Vente aux expositions / foires")}
          </div>
          <div class="cell" style="min-height:8mm; border-bottom:none; flex:1">
            <div style="display:flex; gap:4mm; align-items:flex-start">
              <div>
                ${r("11","Mietgeschäft / Location / Locazione")}
                <div style="margin-top:1mm">
                  <span class="cb"><span class="cb-box"></span> ja / oui / sì</span>
                  <span class="cb"><span class="cb-box"></span> nein / non / no</span>
                </div>
              </div>
              <div style="border-left:0.5px solid #ccc; padding-left:3mm; flex:1">
                ${r("12","VKZ/MTS · Immat. Land · PLZ/NPA/CAP")}
                <div style="display:flex; gap:2mm; margin-top:1mm; align-items:flex-start">
                  <div class="f12-seg">
                    <div class="f12-lbl">VKZ/MTS</div>
                    <span class="fv">${u(b)}</span>
                  </div>
                  <div class="f12-seg">
                    <div class="f12-lbl">Immat. Land</div>
                    <span class="fv">${u(R||"______")}</span>
                  </div>
                  <div class="f12-seg" style="border-right:none">
                    <div class="f12-lbl">PLZ/NPA/CAP</div>
                    <span class="fv">${u(z)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Goods table: fields 13–14 (description row) -->
      <div class="gt-wrap" style="border-bottom:none">
        <table class="gt">
          <colgroup>
            <col style="width:4mm">
            <col style="width:22mm">
            <col>
          </colgroup>
          <thead><tr>
            <th class="rn"></th>
            <th>13 Zeichen, Nr., Anzahl, Verpackung<br>Marque, no, nombre, emballage<br>Marca, n., quantità imballaggio</th>
            <th>14 Genaue Warenbezeichnung (Material, Typ, Nummern, etc.), die eine Identifikation der Ware erlaubt<br>Désignation exacte de la marchandise permettant son identification<br>Designazione esatta della merce che ne permette l'identificazione</th>
          </tr></thead>
          <tbody>
            <tr class="data-row">
              <td class="rn">1</td>
              <td><span class="gfv">See attached list</span></td>
              <td><span class="gfv">${u(O||"—")}</span></td>
            </tr>
            <tr class="data-row">
              <td class="rn">2</td>
              <td></td><td></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Goods table: fields 15–23 (numeric row) -->
      <div class="gt-wrap">
        <table class="gt">
          <colgroup>
            <col style="width:4mm">
            <col style="width:7mm"><col style="width:6mm">
            <col style="width:20mm">
            <col style="width:8mm">
            <col style="width:13mm"><col style="width:13mm">
            <col style="width:13mm"><col style="width:19mm"><col style="width:14mm">
          </colgroup>
          <thead><tr>
            <th class="rn"></th>
            <th>15<br>NHW<br>MNC</th>
            <th>16<br>VC<br>CT</th>
            <th>17 Tarif-Nr.<br>No de tarif<br>Voce di tariffa</th>
            <th>18<br>Schlüssel<br>Clé<br>N.conv.</th>
            <th>19 Eigenmasse<br>Masse nette<br>Massa netta</th>
            <th>20 Zusatz-menge<br>Unités suppl.<br>Unità suppl.</th>
            <th>21 Rohmasse<br>Masse brute<br>Massa lorda</th>
            <th>22 Stat. Wert in CHF<br>Valeur stat. CHF<br>Valore stat. CHF</th>
            <th>23 MWST-Wert<br>Valeur-TVA<br>Valore-IVA</th>
          </tr></thead>
          <tbody>
            <tr class="data-row">
              <td class="rn">1</td>
              <td></td><td></td>
              ${y(x.retQty>0&&x.tariffNo!=="—"?x.tariffNo:"")}
              <td></td>
              ${y(x.retQty>0?Math.round(x.retWeightKg):"")}
              ${y(x.retQty>0?x.retQty:"","center")}
              ${y(x.retQty>0?Math.round(x.retWeightKg):"")}
              ${y(x.retQty>0?x.retValue:"")}
              <td></td>
            </tr>
            ${a?`<tr class="data-row">
              <td class="rn">2</td>
              <td></td><td></td>
              ${y(s.retQty>0&&s.tariffNo!=="—"?s.tariffNo:"")}
              <td></td>
              ${y(s.retQty>0?Math.round(s.retWeightKg):"")}
              ${y(s.retQty>0?s.retQty:"","center")}
              ${y(s.retQty>0?Math.round(s.retWeightKg):"")}
              ${y(s.retQty>0?s.retValue:"")}
              <td></td>
            </tr>`:""}
          </tbody>
        </table>
      </div>

      <!-- Footer: 24 + 25 -->
      <div class="footer">
        <div class="f24">
          ${r("24","Ort / Datum · Lieu / Date · Luogo / Data")}
          <div style="margin-top:1mm"><span class="fv">${u($?$+", ":"")}${u(g)}</span></div>
          <div style="margin-top:2mm; font-size:4.8pt; color:#444">Der Anmelder / Le déclarant / Il dichiarante</div>
          <div style="margin-top:0.5mm"><span class="fv">${u(h.fullName||"——")}</span></div>
          <div class="sig-note">→ Recommended: same person who signed the 11.74</div>
          <div class="sig-line">Unterschrift / Signature / Firma</div>
          <div style="margin-top:1mm; font-size:4.5pt; color:#444">Ref. / Réf. / Rif. &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:30mm">&nbsp;</span></div>
        </div>
        <div class="f25">
          ${r("25","Mehrwertsteuer / Taxe sur la valeur ajoutée / Imposta sul valore aggiunto")}
          <div style="font-size:4.8pt; line-height:2.2; margin-top:1mm; color:#333">
            MWST-Code / Code-TVA / Codice-IVA &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:14mm">&nbsp;</span><br>
            MWST-Register-Nr. / No d'enregistrement-TVA / N. di registrazione IVA<br>
            <span style="border-bottom:0.5px solid #999;display:inline-block;min-width:38mm">&nbsp;</span>
          </div>
        </div>
      </div>

      <!-- Customs verification area -->
      <div class="customs-bar">
        Zollbefund · Résultat de la vérification · Risultato della visita
        <div class="customs-boxes">
          <div class="customs-box">Annahme / Acceptation / Accettazione</div>
          <div class="customs-box">Kontrolle / Contrôle / Controllo</div>
        </div>
      </div>

    </div><!-- fb -->
    <div class="strip strip-r">
      <div class="strip-a">A</div>
    </div>
  </div><!-- body-wrap -->

  <div class="form-footer">Form. 11.87 · 1.2022 · Nachdruck verboten / Reproduction interdite / Riproduzione vietata</div>
</div><!-- page -->
</body></html>`}const $e={class:"mx-auto max-w-4xl space-y-4 p-4 md:p-6"},we={class:"flex flex-wrap items-center gap-3"},Ce={key:0,class:"text-sm text-slate-400"},ke={key:0,class:"rounded-xl bg-slate-900 p-6 text-center text-sm text-slate-400"},Ne={class:"zui-card"},Te={class:"mb-3 text-xs text-slate-500"},Ve={class:"font-mono text-slate-300"},Se={key:0},Re={class:"mb-3 flex flex-wrap items-center gap-2 text-sm"},ze={class:"flex rounded-lg bg-slate-800 p-1"},Me=["onClick"],Ae={class:"grid grid-cols-2 gap-2 sm:grid-cols-3"},_e={class:"zui-card"},De={class:"grid gap-3 sm:grid-cols-2"},We={class:"block text-sm"},Pe={class:"block text-sm"},Oe={class:"block text-sm"},Ue={class:"block text-sm"},Qe={class:"block text-sm"},Ee={class:"block text-sm"},Le={class:"block text-sm sm:col-span-2"},Fe={class:"zui-card"},Ge={class:"grid gap-3 sm:grid-cols-2"},Ie={class:"block text-sm"},He={class:"text-xs text-slate-400"},je={key:0,class:"text-emerald-500"},Be=["placeholder"],Ke={class:"block text-sm"},qe={class:"block text-sm"},Ze={class:"block text-sm"},Ye={class:"block text-sm sm:col-span-2"},Xe={class:"zui-card"},Je={class:"grid gap-3 sm:grid-cols-2"},ts={class:"block text-sm"},es=["value"],ss={class:"block text-sm"},as={class:"block text-sm"},ls={key:0,class:"block text-sm"},os={class:"zui-card"},is={class:"mb-3 flex rounded-lg bg-slate-800 p-1 text-sm",style:{"max-width":"280px"}},rs={key:0,class:"mb-3 grid gap-2 sm:grid-cols-2"},ns={class:"rounded-lg bg-slate-800/60 p-3 text-xs"},ds={class:"mb-1 font-semibold text-slate-300"},cs={class:"text-slate-400"},us={class:"mb-1 font-semibold text-slate-300"},ms={class:"text-slate-400"},ps={key:1,class:"space-y-1"},fs={class:"min-w-0 flex-1 truncate"},hs={class:"text-xs text-slate-500"},gs={class:"flex rounded-md bg-slate-800 p-0.5"},vs=["onClick"],bs=["onClick"],ys={key:2,class:"text-xs text-slate-500"},ks=Ht({__name:"CustomsView",setup(e){const p=jt(),n=Zt(),h=rt(()=>{var _;return(_=p.events.find(l=>l.id===n.params.eventId))!=null?_:p.activeEvent}),f=lt(xt()),w=lt($t()),M=lt(wt()),D=lt(""),A=lt(1),o=lt(""),V=lt(""),b=lt("");let R=null,z=null,W=!1;function g(_){return _?Object.fromEntries(Object.entries(_).filter(([,l])=>l!==""&&l!=null)):{}}vt(()=>h.value,async _=>{var J,T,tt,ct,pt,St,Rt,zt,Mt,At,_t,Dt,Wt;if(!_||_.id===R)return;R=_.id,W=!0;const l=Ct(_),j=await Yt("customs.artistDefaults");f.value={...xt(),...g(j),...g(l.artist)},w.value={...$t(),...(J=l.edec)!=null?J:{}};const G={...wt(),...(T=l.form1174)!=null?T:{}};Array.isArray(G.assignments)||(G.assignments=[]),M.value=G,D.value=(ct=(tt=l.meta)==null?void 0:tt.companyCode)!=null?ct:"",A.value=(St=(pt=l.meta)==null?void 0:pt.documentNumber)!=null?St:1,o.value=(zt=(Rt=l.meta)==null?void 0:Rt.venueName)!=null?zt:"",V.value=(At=(Mt=l.meta)==null?void 0:Mt.eventLocation)!=null?At:"",b.value=(Wt=(Dt=(_t=l.meta)==null?void 0:_t.venueTIN)!=null?Dt:_.venue.tin)!=null?Wt:"",setTimeout(()=>W=!1)},{immediate:!0});function $(){W||!h.value||(z&&clearTimeout(z),z=setTimeout(x,600))}async function x(){const _=h.value;if(!_)return;const l=Ct(_);await Xt({..._,customs:{..._.customs,artist:{...f.value},edec:{...w.value},form1174:JSON.parse(JSON.stringify(M.value)),meta:{...l.meta,companyCode:D.value,documentNumber:A.value,venueName:o.value,eventLocation:V.value,venueTIN:b.value}},updatedAt:Date.now()})}vt([f,w,M,D,A,o,V,b],$,{deep:!0});const s=rt(()=>{const _=(f.value.companyName||f.value.fullName||"").trim();if(!_)return"";const l=_.split(/\s+/).filter(Boolean);return(l.length>1?l.map(G=>G[0]).join(""):_.slice(0,3)).toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6)}),a=rt(()=>D.value.trim()||s.value),c=rt(()=>{if(!h.value)return null;const _={...h.value,customs:{artist:f.value,edec:w.value,form1174:M.value,meta:{companyCode:a.value,documentNumber:A.value,venueName:o.value,eventLocation:V.value,venueTIN:b.value}}};return de(_,p.products,p.allStock,p.allTransactions)}),m=rt(()=>c.value?Tt(c.value,A.value):""),u=rt(()=>c.value?Vt(JSON.parse(JSON.stringify(c.value))):null);function v(_,l){var G,J;const j=[...M.value.assignments];for(;j.length<((J=(G=c.value)==null?void 0:G.products.length)!=null?J:0);)j.push(0);j[_]=l,M.value={...M.value,assignments:j}}const t=lt("detailed"),r=rt(()=>{var _,l;return(l=(_=c.value)==null?void 0:_.products.some(j=>{var G,J;return!j.unlisted&&((J=(G=j.variants)==null?void 0:G.length)!=null?J:0)>0}))!=null?l:!1}),y=rt(()=>r.value?[{value:"detailed",label:"Detailed"},{value:"compressed",label:"Compressed"},{value:"bytype",label:"By type"}]:[{value:"detailed",label:"Per product"},{value:"bytype",label:"By type"}]);vt(r,_=>{!_&&t.value==="compressed"&&(t.value="detailed")});function C(_){var l;return`${(((l=h.value)==null?void 0:l.name)||"event").replace(/[^\w-]+/g,"_")}_${_}`}async function k(_,l){if(Pt){await te(_,l,"text/html");return}const j=URL.createObjectURL(new Blob([l],{type:"text/html"}));window.open(j,"_blank")||Ut("Pop-up blocked - allow pop-ups and try again.","error")}async function O(){if(!c.value)return;const _=fe(c.value);if(!_){Ut("No products have sold quantities > 0 yet.","error");return}await Jt(_.filename,_.xml,"application/xml")}const N=_=>k(C(`goods_${_}.html`),ge(c.value,_,t.value)),S=()=>k(C("goods_all.html"),ve(c.value)),Q=()=>k(C("proforma.html"),be(c.value)),ot=()=>k(C("form_1174.html"),ye(c.value)),it=()=>k(C("form_1187.html"),xe(c.value)),gt=[["1","1 - Sea"],["2","2 - Rail"],["3","3 - Road"],["4","4 - Air"],["5","5 - Postal / Mail"],["9","9 - Own propulsion"]];return(_,l)=>{var G,J;const j=qt("RouterLink");return H(),I("div",$e,[d("div",we,[et(j,{to:"/events",class:"rounded-lg px-2 py-1 text-slate-400 hover:bg-slate-800"},{default:Bt(()=>[...l[21]||(l[21]=[st("←",-1)])]),_:1}),l[22]||(l[22]=d("h1",{class:"text-xl font-bold"},"Customs",-1)),h.value?(H(),I("span",Ce,F(h.value.name),1)):ut("",!0)]),h.value?(H(),I(ft,{key:1},[d("section",Ne,[l[33]||(l[33]=d("h2",{class:"mb-1 zui-card-title"},"Documents",-1)),d("p",Te,[l[23]||(l[23]=st(" LRP: ",-1)),d("span",Ve,F(m.value),1),at(Pt)?(H(),I("span",Se," · Documents open via the share sheet — open in a browser to print.")):ut("",!0)]),d("div",Re,[l[24]||(l[24]=d("span",{class:"text-xs text-slate-400"},"Goods list format:",-1)),d("div",ze,[(H(!0),I(ft,null,bt(y.value,T=>(H(),I("button",{key:T.value,class:dt(["rounded-md px-3 py-1 text-xs",t.value===T.value?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:tt=>t.value=T.value},F(T.label),11,Me))),128))])]),d("div",Ae,[d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:l[0]||(l[0]=T=>N(1))},[et(at(ie),{class:"h-4 w-4 shrink-0"}),l[25]||(l[25]=st(" Import list ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:l[1]||(l[1]=T=>N(2))},[et(at(oe),{class:"h-4 w-4 shrink-0"}),l[26]||(l[26]=st(" Sold goods list ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:l[2]||(l[2]=T=>N(3))},[et(at(re),{class:"h-4 w-4 shrink-0"}),l[27]||(l[27]=st(" Return goods list ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:S},[et(at(ne),{class:"h-4 w-4 shrink-0"}),l[28]||(l[28]=st(" All formats bundle ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:Q},[et(at(ae),{class:"h-4 w-4 shrink-0"}),l[29]||(l[29]=st(" Proforma invoice ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:ot},[et(at(Qt),{class:"h-4 w-4 shrink-0"}),l[30]||(l[30]=st(" Form 11.74 ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:it},[et(at(Qt),{class:"h-4 w-4 shrink-0"}),l[31]||(l[31]=st(" Form 11.87 ",-1))]),d("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600",onClick:O},[et(at(le),{class:"h-4 w-4 shrink-0"}),l[32]||(l[32]=st(" e-dec XML ",-1))])])]),d("section",_e,[l[41]||(l[41]=d("h2",{class:"mb-3 zui-card-title"},"Artist / sender",-1)),d("div",De,[d("label",We,[l[34]||(l[34]=d("span",{class:"text-xs text-slate-400"},"Company name",-1)),B(d("input",{"onUpdate:modelValue":l[3]||(l[3]=T=>f.value.companyName=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,f.value.companyName]])]),d("label",Pe,[l[35]||(l[35]=d("span",{class:"text-xs text-slate-400"},"Full name",-1)),B(d("input",{"onUpdate:modelValue":l[4]||(l[4]=T=>f.value.fullName=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,f.value.fullName]])]),d("label",Oe,[l[36]||(l[36]=d("span",{class:"text-xs text-slate-400"},"Street & house number",-1)),B(d("input",{"onUpdate:modelValue":l[5]||(l[5]=T=>f.value.street=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,f.value.street]])]),d("label",Ue,[l[37]||(l[37]=d("span",{class:"text-xs text-slate-400"},"Postcode & city",-1)),B(d("input",{"onUpdate:modelValue":l[6]||(l[6]=T=>f.value.postCodeCity=T),placeholder:"9000 Gent",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,f.value.postCodeCity]])]),d("label",Qe,[l[38]||(l[38]=d("span",{class:"text-xs text-slate-400"},"Country of origin",-1)),et(Ot,{modelValue:f.value.countryOfOrigin,"onUpdate:modelValue":l[7]||(l[7]=T=>f.value.countryOfOrigin=T),mode:"name",placeholder:"Belgium",class:"mt-1"},null,8,["modelValue"])]),d("label",Ee,[l[39]||(l[39]=d("span",{class:"text-xs text-slate-400"},"Phone",-1)),B(d("input",{"onUpdate:modelValue":l[8]||(l[8]=T=>f.value.phone=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,f.value.phone]])]),d("label",Le,[l[40]||(l[40]=d("span",{class:"text-xs text-slate-400"},"Email",-1)),B(d("input",{"onUpdate:modelValue":l[9]||(l[9]=T=>f.value.email=T),type:"email",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,f.value.email]])])])]),d("section",Fe,[l[47]||(l[47]=d("h2",{class:"mb-3 zui-card-title"},"Declaration details",-1)),d("div",Ge,[d("label",Ie,[d("span",He,[l[42]||(l[42]=st(" Company code (for LRP) ",-1)),!D.value.trim()&&s.value?(H(),I("span",je," — auto: "+F(s.value),1)):ut("",!0)]),B(d("input",{"onUpdate:modelValue":l[10]||(l[10]=T=>D.value=T),placeholder:s.value||"e.g. GUG",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,8,Be),[[Z,D.value]])]),d("label",Ke,[l[43]||(l[43]=d("span",{class:"text-xs text-slate-400"},"Document number",-1)),B(d("input",{"onUpdate:modelValue":l[11]||(l[11]=T=>A.value=T),type:"number",min:"1",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,A.value,void 0,{number:!0}]])]),d("label",qe,[l[44]||(l[44]=d("span",{class:"text-xs text-slate-400"},"Venue / organiser name",-1)),B(d("input",{"onUpdate:modelValue":l[12]||(l[12]=T=>o.value=T),placeholder:"e.g. Messe Basel",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,o.value]])]),d("label",Ze,[l[45]||(l[45]=d("span",{class:"text-xs text-slate-400"},"Venue TIN",-1)),B(d("input",{"onUpdate:modelValue":l[13]||(l[13]=T=>b.value=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2 font-mono text-xs"},null,512),[[Z,b.value]])]),d("label",Ye,[l[46]||(l[46]=d("span",{class:"text-xs text-slate-400"},"Event location (shown on documents)",-1)),B(d("input",{"onUpdate:modelValue":l[14]||(l[14]=T=>V.value=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,V.value]])])]),l[48]||(l[48]=d("p",{class:"mt-2 text-xs text-slate-500"}," Venue address and event dates come from the event itself — edit them under Events. ",-1))]),d("section",Xe,[l[53]||(l[53]=d("h2",{class:"mb-3 zui-card-title"},"Transport (e-dec / forms)",-1)),d("div",Je,[d("label",ts,[l[49]||(l[49]=d("span",{class:"text-xs text-slate-400"},"Transport mode",-1)),B(d("select",{"onUpdate:modelValue":l[15]||(l[15]=T=>w.value.transportMode=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},[(H(),I(ft,null,bt(gt,([T,tt])=>d("option",{key:T,value:T},F(tt),9,es)),64))],512),[[Kt,w.value.transportMode]])]),d("label",ss,[l[50]||(l[50]=d("span",{class:"text-xs text-slate-400"},"Vehicle country",-1)),et(Ot,{modelValue:w.value.transportationCountry,"onUpdate:modelValue":l[16]||(l[16]=T=>w.value.transportationCountry=T),mode:"code",placeholder:"BE",class:"mt-1"},null,8,["modelValue"])]),d("label",as,[l[51]||(l[51]=d("span",{class:"text-xs text-slate-400"},"Vehicle / plate number",-1)),B(d("input",{"onUpdate:modelValue":l[17]||(l[17]=T=>w.value.transportationNumber=T),placeholder:"1-KDE-308",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,w.value.transportationNumber]])]),w.value.transportMode==="4"?(H(),I("label",ls,[l[52]||(l[52]=d("span",{class:"text-xs text-slate-400"},"Flight number (form 11.74 field 6)",-1)),B(d("input",{"onUpdate:modelValue":l[18]||(l[18]=T=>w.value.flightNumber=T),placeholder:"LX1234",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[Z,w.value.flightNumber]])])):ut("",!0)])]),d("section",os,[l[54]||(l[54]=d("h2",{class:"mb-3 zui-card-title"},"Form 11.74 / 11.87 goods grouping",-1)),d("div",is,[d("button",{class:dt(["flex-1 rounded-md px-3 py-1.5",M.value.groupMode==="auto"?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:l[19]||(l[19]=T=>M.value={...M.value,groupMode:"auto"})}," Automatic ",2),d("button",{class:dt(["flex-1 rounded-md px-3 py-1.5",M.value.groupMode==="manual"?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:l[20]||(l[20]=T=>M.value={...M.value,groupMode:"manual"})}," Manual ",2)]),u.value?(H(),I("div",rs,[d("div",ns,[d("p",ds,"Group 1 · "+F(u.value.g1.tariffNo),1),d("p",cs,F(u.value.g1.qty)+" items · "+F(at(P)(u.value.g1.weightKg))+" · "+F(Math.floor(u.value.g1.value))+" "+F((G=h.value)==null?void 0:G.currency),1)]),d("div",{class:dt(["rounded-lg bg-slate-800/60 p-3 text-xs",{"opacity-40":!u.value.hasG2}])},[d("p",us,"Group 2 · "+F(u.value.g2.tariffNo),1),d("p",ms,F(u.value.g2.qty)+" items · "+F(at(P)(u.value.g2.weightKg))+" · "+F(Math.floor(u.value.g2.value))+" "+F((J=h.value)==null?void 0:J.currency),1)],2)])):ut("",!0),M.value.groupMode==="manual"&&c.value?(H(),I("div",ps,[(H(!0),I(ft,null,bt(c.value.products,(T,tt)=>{var ct;return H(),I("div",{key:(ct=T.id)!=null?ct:tt,class:"flex items-center gap-2 rounded-lg bg-slate-800/40 px-3 py-1.5 text-sm"},[d("span",fs,F(T.title),1),d("span",hs,F(T.tariffNo||"—"),1),d("div",gs,[d("button",{class:dt(["rounded px-2.5 py-0.5 text-xs",M.value.assignments[tt]===1?"bg-emerald-700 font-semibold text-white":"text-slate-400"]),onClick:pt=>v(tt,1)}," G1 ",10,vs),d("button",{class:dt(["rounded px-2.5 py-0.5 text-xs",M.value.assignments[tt]!==1?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:pt=>v(tt,2)}," G2 ",10,bs)])])}),128))])):(H(),I("p",ys," Automatic: the tariff group with the highest value becomes group 1, everything else group 2. "))])],64)):(H(),I("p",ke," Event not found — open Customs from an event card under Events. Customs data is stored per event. "))])}}});export{ks as default};
