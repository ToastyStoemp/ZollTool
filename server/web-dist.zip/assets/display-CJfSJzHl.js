const s={btAddress:"display.btAddress",btName:"display.btName"};export{s as D};
