import{c as vt,a7 as Ft,a8 as jt,a9 as Gt,d as Bt,u as Kt,T as yt,b as I,e as m,s as et,w as qt,t as F,f as mt,F as ft,p as st,m as at,aa as Zt,r as xt,x as B,z as q,A as Qt,y as Yt,n as dt,i as rt,h as lt,Z as Xt,l as Jt,o as H,ab as te,Q as ee,E as se}from"./index-D8x3QH8C.js";import{s as ae,o as le}from"./download-F-nruFQX.js";import{i as It,a as oe,C as ie}from"./artwork-C6DpPPbb.js";import{R as re,D as ne}from"./receipt-DMTxX3oV.js";const Ut=vt("clipboard-list",[["rect",{width:"8",height:"4",x:"8",y:"2",rx:"1",ry:"1",key:"tgr4d6"}],["path",{d:"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",key:"116196"}],["path",{d:"M12 11h4",key:"1jrz19"}],["path",{d:"M12 16h4",key:"n85exb"}],["path",{d:"M8 11h.01",key:"1dfujw"}],["path",{d:"M8 16h.01",key:"18s6g9"}]]);const de=vt("file-input",[["path",{d:"M4 11V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1",key:"1q9hii"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M2 15h10",key:"jfw4w8"}],["path",{d:"m9 18 3-3-3-3",key:"112psh"}]]);const ce=vt("file-output",[["path",{d:"M4.226 20.925A2 2 0 0 0 6 22h12a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.127",key:"wfxp4w"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"m5 11-3 3",key:"1dgrs4"}],["path",{d:"m5 17-3-3h10",key:"1mvvaf"}]]);const ue=vt("folder-archive",[["circle",{cx:"15",cy:"19",r:"2",key:"u2pros"}],["path",{d:"M20.9 19.8A2 2 0 0 0 22 18V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h5.1",key:"1jj40k"}],["path",{d:"M15 11v-1",key:"cntcp"}],["path",{d:"M15 17v-2",key:"1279jj"}]]);function Et(){return{event:"",eventDateStart:"",eventDateEnd:"",eventLocation:"",companyCode:"",lrp:"",documentNumber:1,venueName:"",venueStreet:"",venuePostcode:"",venueCity:"",venueCountry:"Switzerland",venueTIN:"CHE222251936",currency:"CHF"}}function wt(){return{companyName:"",fullName:"",street:"",postCodeCity:"",countryOfOrigin:"",phone:"",email:""}}function Ct(){return{transportMode:"3",transportationType:"1",transportationCountry:"",transportationNumber:"",flightNumber:"",registrationPostcode:"",importerCountry:"CH"}}function kt(){return{groupMode:"auto",assignments:[]}}const Lt=e=>e!=null&&e!=="";function Nt(e){var p;return(p=e.customs)!=null?p:{}}function me(e,p,n,h){var y,R,z,W,b,$,x;const u=Nt(e),w=new Map;for(const s of n)s.eventId===e.id&&w.set(`${s.productId}:${s.variantId}`,s.broughtQty);const M=new Map;for(const s of h)if(!(s.eventId!==e.id||s.revertedBy))for(const o of s.items){const r=`${o.pid}:${(y=o.vid)!=null?y:""}`,c=(R=M.get(r))!=null?R:{qty:0,value:0};c.qty+=o.qty,c.value+=(z=o.baseLineTotal)!=null?z:o.lineTotal,M.set(r,c)}const D=p.filter(s=>!s.deletedAt).map(s=>{var c,f,v;const o=(c=M.get(`${s.id}:`))!=null?c:{qty:0,value:0},r=(f=s.tariffNo)!=null&&f.trim()?Ft.find(t=>t.code===s.tariffNo.trim()):void 0;return{id:s.id,title:s.title,sku:s.sku,type:s.type,forSale:s.forSale,unlisted:s.unlisted,price:s.price,priceNote:s.priceNote,weightG:s.weightG,tariffNo:s.tariffNo,tariffRate:Lt(s.tariffRate)?s.tariffRate:r==null?void 0:r.rate,vatRate:Lt(s.vatRate)?s.vatRate:r==null?void 0:r.vatRate,packagingType:s.packagingType,originCountry:s.originCountry,permitOverride:s.permitOverride,year:s.year,material:s.material,amount:(v=w.get(`${s.id}:`))!=null?v:0,soldQty:o.qty,soldValue:o.value,variants:s.variants.map(t=>{var g,C,k,O;const d=(g=M.get(`${s.id}:${t.id}`))!=null?g:{qty:0,value:0};return{name:t.name,sku:t.sku,price:(C=t.price)!=null?C:null,weightG:(k=t.weightG)!=null?k:null,unlisted:t.unlisted,amount:(O=w.get(`${s.id}:${t.id}`))!=null?O:0,soldQty:d.qty,soldValue:d.value}})}}),A=(W=u.meta)!=null?W:{},l={...Et(),...A,event:e.name,eventDateStart:e.dateStart||A.eventDateStart||"",eventDateEnd:e.dateEnd||A.eventDateEnd||"",eventLocation:A.eventLocation||e.venue.city||"",venueStreet:e.venue.street||A.venueStreet||"",venuePostcode:e.venue.postcode||A.venuePostcode||"",venueCity:e.venue.city||A.venueCity||"",venueCountry:e.venue.country||A.venueCountry||"Switzerland",venueTIN:e.venue.tin||A.venueTIN||Et().venueTIN,currency:e.currency},V={...kt(),...(b=u.form1174)!=null?b:{}};return Array.isArray(V.assignments)||(V.assignments=[]),{meta:l,artist:{...wt(),...($=u.artist)!=null?$:{}},edec:{...Ct(),...(x=u.edec)!=null?x:{}},form1174:V,products:D}}function Ht(e,p){if(!e)return"";const n=new Date(e+"T00:00:00"),h=n.getDate(),u=String(n.getMonth()+1).padStart(2,"0"),w=n.getFullYear();if(!p)return`${h}.${u}.${w}`;const D=new Date(p+"T00:00:00").getDate();return`${h}. – ${D}.${u}.${w}`}function L(e,p){return parseFloat(e).toFixed(p)}function E(e,p){if(e==null||isNaN(e))return 0;const n=Math.pow(10,p);return Math.floor(parseFloat(e)*n)/n}function P(e){return e==null||isNaN(e)||e===0?"0 kg":L(e,2).replace(".",",")+" kg"}function i(e){return String(e==null?"":e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Q(e){return String(e==null?"":e).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;")}function X(e){if(!e)return"";const p=e.trim();if(/^[A-Z]{2}$/.test(p))return p;const n=jt[p.toLowerCase()];return n||p.toUpperCase().slice(0,2)}function pe(e){if(!e)return{postCode:"",city:""};const p=e.match(/^(\S+)\s+(.+)$/);return p?{postCode:p[1],city:p[2]}:{postCode:"",city:e}}function fe(e){return e?e.replace(/^(\d{4})\.(\d{2})\.(\d{2})$/,"$1.$2$3"):""}function he(e){if(!e)return 0;const p=Ft.find(n=>n.code===e);return p?p.permit||0:e.startsWith("7117")?2:0}function ge(e){return e!=null&&parseFloat(e)<=2.7?2:1}function St(e,p){const n=X(e.artist.countryOfOrigin)||"XX",h=(e.meta.companyCode||"").toUpperCase()||"XX",u=new Date;let w=u.getFullYear(),M=u.getMonth()+1;if(e.meta.eventDateStart){const l=new Date(e.meta.eventDateStart+"T00:00:00");w=l.getFullYear(),M=l.getMonth()+1}const D=String(M).padStart(2,"0"),A=String(p).padStart(3,"0");return`${n}CH_${h}_${w}_${D}_${A}`}function K(e){return Array.isArray(e.variants)&&e.variants.length>0}function Tt(e,p){const n=p.price!=null&&p.price!==""?p.price:e.price;return n!=null&&!isNaN(parseFloat(n))?parseFloat(n):null}function Vt(e,p){const n=p.weightG!=null&&p.weightG!==""?p.weightG:e.weightG;return parseFloat(n)||0}function G(e,p=!1){if(K(e)){let A=0,l=0,V=0,y=0,R=0,z=0;for(const c of e.variants){if(p&&c.unlisted)continue;const f=c.amount||0,v=Vt(e,c),t=Tt(e,c);A+=f,l+=Math.round(f*v)/1e3,t!=null&&(V+=t*f),y+=c.soldQty||0,R+=c.soldValue||0,z+=(c.soldQty||0)*v/1e3}l=Math.round(l*1e3)/1e3;const W=p?e.variants.filter(c=>!c.unlisted):e.variants,b=W.map(c=>Tt(e,c)).filter(c=>c!=null),$=W.map(c=>Vt(e,c)),x=b.length>0&&b.every(c=>c===b[0]),s=$.length>0&&$.every(c=>c===$[0]),o=x?b[0]:A>0&&V>0?V/A:null,r=s?$[0]:A>0?Math.round(l*1e3/A):e.weightG||0;return{totalWeightKg:l,totalValue:V>0?Math.round(V):null,effectiveUnitPrice:o,effectiveUnitWeightG:r,soldWeightKg:z,amount:A,soldQty:y,soldValue:R}}const n=e.amount||0,h=Math.round(n*(e.weightG||0))/1e3;let u=e.totalValueCHF!=null?Math.round(parseFloat(e.totalValueCHF)):null;u==null&&e.price!=null&&e.price!==""&&(u=Math.round(parseFloat(e.price)*n));const w=u!=null&&n>0?u/n:null,M=n>0?h*1e3/n:e.weightG||0,D=(e.soldQty||0)*(e.weightG||0)/1e3;return{totalWeightKg:h,totalValue:u,effectiveUnitPrice:w,effectiveUnitWeightG:M,soldWeightKg:D,amount:n,soldQty:e.soldQty||0,soldValue:e.soldValue||0}}function gt(e){if(K(e)){let w=0,M=0,D=0,A=!1;for(const l of e.variants){if(l.unlisted)continue;const V=(l.amount||0)-(l.soldQty||0);if(V<=0)continue;const y=Vt(e,l),R=Tt(e,l);w+=V,M+=Math.round(V*y)/1e3,R!=null&&(D+=Math.round(R*V),A=!0)}return{retQty:w,retWkg:Math.round(M*1e3)/1e3,retVal:A?D:null}}const p=G(e),n=(p.amount||0)-(p.soldQty||0);if(n<=0)return{retQty:0,retWkg:0,retVal:null};const h=Math.round(n*(e.weightG||0))/1e3,u=p.effectiveUnitPrice!=null?Math.round(p.effectiveUnitPrice*n):null;return{retQty:n,retWkg:h,retVal:u}}function Z(e){return!e.unlisted&&(!!(e.tariffNo&&e.tariffNo.trim())||e.vatRate!=null&&e.vatRate!=="")}function Rt(e){var l;const p=e.form1174.assignments;for(;p.length<e.products.length;)p.push(0);p.length>e.products.length&&(p.length=e.products.length);function n(V){let y="—",R=-1;const z={tariffNo:"—",qty:0,weightKg:0,value:0,retQty:0,retWeightKg:0,retValue:0};return V.forEach(W=>{const b=G(W);z.qty+=b.amount||0,z.weightKg+=b.totalWeightKg,b.totalValue!=null&&(z.value+=b.totalValue);const $=Math.max(0,(b.amount||0)-(b.soldQty||0));z.retQty+=$,z.retWeightKg+=Math.round($*(W.weightG||0))/1e3,b.effectiveUnitPrice!=null&&(z.retValue+=Math.round(b.effectiveUnitPrice*$)),b.totalValue!=null&&b.totalValue>R&&W.tariffNo&&(R=b.totalValue,y=W.tariffNo)}),z.tariffNo=y,z}if(e.form1174.groupMode==="manual"){const V=e.products.filter((W,b)=>p[b]===1),y=e.products.filter((W,b)=>p[b]!==1),R=n(V),z=n(y);return{g1:R,g2:z,hasG2:z.qty>0,g1prods:V,g2prods:y}}const h={};e.products.forEach(V=>{const y=(V.tariffNo||"").trim()||"—",R=G(V);h[y]||(h[y]=0),R.totalValue!=null&&(h[y]+=R.totalValue)});const u=(l=Object.entries(h).sort((V,y)=>y[1]-V[1])[0])==null?void 0:l[0],w=e.products.filter(V=>((V.tariffNo||"").trim()||"—")===u),M=e.products.filter(V=>((V.tariffNo||"").trim()||"—")!==u),D=n(w),A=n(M);return{g1:D,g2:A,hasG2:A.qty>0,g1prods:w,g2prods:M}}function ve(e,p=new Date){const n=e.products.filter(s=>s.unlisted?!1:s.variants&&s.variants.length>0?s.variants.some(o=>!o.unlisted&&(o.soldQty||0)>0):(s.soldQty||0)>0);if(n.length===0)return null;const h=e.edec,u=e.artist,w=X(u.countryOfOrigin),M=pe(u.postCodeCity),D=s=>String(s).padStart(2,"0"),A=`${p.getUTCFullYear()}-${D(p.getUTCMonth()+1)}-${D(p.getUTCDate())} ${D(p.getUTCHours())}:${D(p.getUTCMinutes())}:${D(p.getUTCSeconds())}.000 UTC`,l=[];l.push('<?xml version="1.0" encoding="UTF-8"?>'),l.push(`<EdecWeb version="4.0" createdDate="${Q(A)}">`),l.push("  <goodsDeclarationType>"),l.push("    <serviceType>1</serviceType>"),l.push("    <declarationType>1</declarationType>"),l.push("    <language>de</language>"),l.push(`    <dispatchCountry>${Q(w)}</dispatchCountry>`);const V=h.transportMode||"3";l.push("    <transportMeans>"),l.push(`      <transportMode>${Q(V)}</transportMode>`),V==="3"&&l.push(`      <transportationType>${Q(h.transportationType||"1")}</transportationType>`),l.push(`      <transportationCountry>${Q((h.transportationCountry||"").toUpperCase())}</transportationCountry>`),l.push(`      <transportationNumber>${Q(h.transportationNumber||"")}</transportationNumber>`),l.push("    </transportMeans>"),l.push("    <transportInContainer>0</transportInContainer>"),l.push("    <previousDocument/>");const y=e.meta,R=X(y.venueCountry)||"CH";l.push("    <importer>"),l.push(`      <name>${Q(y.venueName||"")}</name>`),l.push(`      <addressSupplement1>${Q("c/o "+(y.event||""))}</addressSupplement1>`),l.push(`      <addressSupplement2>${Q(y.venueStreet||"")}</addressSupplement2>`),l.push(`      <postalCode>${Q(y.venuePostcode||"")}</postalCode>`),l.push(`      <city>${Q(y.venueCity||"")}</city>`),l.push(`      <country>${Q(R)}</country>`),l.push(`      <traderIdentificationNumber>${Q(y.venueTIN||"")}</traderIdentificationNumber>`),l.push("    </importer>"),l.push("    <consignee>"),l.push(`      <name>${Q(y.venueName||"")}</name>`),l.push(`      <addressSupplement1>${Q("c/o "+(y.event||""))}</addressSupplement1>`),l.push(`      <addressSupplement2>${Q(y.venueStreet||"")}</addressSupplement2>`),l.push(`      <postalCode>${Q(y.venuePostcode||"")}</postalCode>`),l.push(`      <city>${Q(y.venueCity||"")}</city>`),l.push(`      <country>${Q(R)}</country>`),l.push(`      <traderIdentificationNumber>${Q(y.venueTIN||"")}</traderIdentificationNumber>`),l.push("    </consignee>"),l.push("    <declarant>"),l.push("      <traderIdentificationNumber></traderIdentificationNumber>"),l.push(`      <name>${Q(u.fullName||u.companyName||"")}</name>`),l.push(`      <street>${Q(u.street||"")}</street>`),l.push(`      <postalCode>${Q(M.postCode)}</postalCode>`),l.push(`      <city>${Q(M.city)}</city>`),l.push(`      <country>${Q(w)}</country>`),l.push("    </declarant>"),l.push("    <business>"),l.push("      <customsAccount>0</customsAccount>"),l.push("      <vatAccount>0</vatAccount>"),l.push("      <vatSuffix>0</vatSuffix>"),l.push("      <invoiceCurrencyType>1</invoiceCurrencyType>"),l.push("    </business>"),l.push("    <goodsItem>"),n.forEach((s,o)=>{const r=s.variants&&s.variants.length>0?s.variants.filter(N=>!N.unlisted):null,c=r?r.reduce((N,S)=>N+(S.soldQty||0),0):s.soldQty||0,f=r?r.reduce((N,S)=>N+(S.soldValue||0),0):s.soldValue||0,v=Math.max(.1,Math.round(c*(s.weightG||0)/100)/10),t=s.permitOverride!=null?s.permitOverride:he(s.tariffNo),d=ge(s.vatRate),g=fe(s.tariffNo),C=s.originCountry&&s.originCountry.trim()?s.originCountry.trim().toUpperCase():w;let k=0;f>0?k=Math.floor(f):s.price!=null&&s.price!==""?k=Math.floor(c*parseFloat(s.price)):s.totalValueCHF!=null&&s.amount&&(k=Math.floor(c/s.amount*parseFloat(s.totalValueCHF))),l.push("      <GoodsItemType>"),l.push(`        <traderItemID>${o}</traderItemID>`),l.push(`        <description>${Q(c+" "+(s.title||""))}</description>`),l.push(`        <commodityCode>${Q(g)}</commodityCode>`),l.push(`        <grossMass>${v}</grossMass>`),l.push(`        <netMass>${v}</netMass>`),l.push(`        <permitObligation>${t}</permitObligation>`),l.push(`        <nonCustomsLawObligation>${t}</nonCustomsLawObligation>`),l.push("        <statistic>"),l.push("          <customsClearanceType>1</customsClearanceType>"),l.push("          <commercialGood>1</commercialGood>"),l.push(`          <statisticalValue>${k}</statisticalValue>`),l.push("          <repair>0</repair>"),l.push("        </statistic>"),l.push("        <origin>"),l.push(`          <originCountry>${Q(C)}</originCountry>`),l.push("          <preference>0</preference>"),l.push("        </origin>");const O=s.packagingType||"CT";O==="NE"?(l.push("        <packaging>"),l.push("          <PackagingType>"),l.push("            <packagingType>NE</packagingType>"),l.push("            <quantity>0</quantity>"),l.push("          </PackagingType>"),l.push("        </packaging>")):(l.push("        <packaging>"),l.push("          <PackagingType>"),l.push(`            <packagingType>${Q(O)}</packagingType>`),l.push("            <quantity>1</quantity>"),l.push("            <packagingReferenceNumber>1</packagingReferenceNumber>"),l.push("          </PackagingType>"),l.push("        </packaging>")),l.push("        <valuation>"),l.push("          <netDuty>0</netDuty>"),l.push(`          <vatValue>${k}</vatValue>`),l.push(`          <vatCode>${d}</vatCode>`),l.push("        </valuation>"),l.push("      </GoodsItemType>")}),l.push("    </goodsItem>"),l.push("  </goodsDeclarationType>"),l.push("</EdecWeb>");const z=l.join(`
`),W=e.meta.event||"ZollTool",b=e.artist.companyName||e.artist.fullName||"",$=p.toISOString().slice(0,10),x=[W,b,"edec",$].filter(Boolean).join("_").replace(/[^a-zA-Z0-9_\-\.]/g,"_")+".xml";return{xml:z,filename:x}}function ht(e,p){const n=i(e.title||"");if(It(e.type)){const h=e.year?`${n} (${e.year})`:n,u=(p!=null?p:"").trim();return u?`${h} - ${i(u)}`:h}return oe(e.type)&&e.material?`${n} - ${i(e.material)}`:n}function ct(e,p){return It(e.type)?ht(e,p):i(e.title||"")}function $t(e,p){return e.filter(h=>h.type===p.type).length>1?`${i(p.type)} (${i(p.tariffNo||"no HS code")})`:i(p.type)}const be={1:"Auxiliary Document for the Customs Declaration - Import",2:"Auxiliary Document for the Customs Declaration - Sold Goods",3:"Return Goods List - Re-export Declaration"};function nt(e){return e.meta&&e.meta.currency?e.meta.currency:"CHF"}function ye(e,p,n="detailed"){const h=e.meta,u=e.artist,w=St(e,p),M=be,D=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 8pt; color: #000; padding: 12mm; }
  .doc-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6mm; }
  .doc-top-left .doc-title { font-size: 10pt; font-weight: bold; text-transform: uppercase; }
  .doc-top-left .doc-subtitle { font-size: 8pt; color: #444; margin-top: 2px; }
  .doc-top-right { text-align: right; }
  .doc-top-right .event-name { font-size: 11pt; font-weight: bold; }
  .doc-top-right .lrp { font-size: 8pt; margin-top: 3px; }
  .info-table { width: 100%; border-collapse: collapse; margin-bottom: 5mm; }
  .info-table td { padding: 2px 6px; font-size: 8pt; border: 1px solid #ccc; }
  .info-table td.lbl { font-weight: bold; background: #f4f4f4; width: 130px; font-size: 7.5pt; }
  .section-title { font-weight: bold; font-size: 9pt; margin: 4mm 0 2mm 0; border-bottom: 1.5px solid #000; padding-bottom: 1mm; }
  table.goods { width: 100%; border-collapse: collapse; font-size: 7pt; }
  table.goods th { background: #e8e8e8; border: 1px solid #aaa; padding: 3px 4px; text-align: left; font-size: 6.5pt; font-weight: bold; white-space: nowrap; }
  table.goods td { border: 1px solid #ccc; padding: 2px 4px; vertical-align: middle; }
  table.goods tr:nth-child(even) td { background: #fafafa; }
  table.goods tfoot td { background: #e8e8e8; font-weight: bold; border: 1px solid #aaa; padding: 3px 4px; }
  .r { text-align: right; } .c { text-align: center; }
  .mono { font-family: 'Courier New', monospace; font-size: 6.5pt; }
  .sold-head { border-left: 2px solid #666 !important; }
  td.sold-first { border-left: 2px solid #888; }
  .signature-section { margin-top: 8mm; }
  .signature-box { border: 1px solid #000; width: 80mm; height: 22mm; margin-top: 2mm; }
  @media print { body { padding: 0; } @page { size: A4 landscape; margin: 12mm; } }`,A=`<div class="doc-top">
  <div class="doc-top-left">
    <div class="doc-title">${i(M[p]||M[1])}</div>
    <div class="doc-subtitle">${i(Ht(h.eventDateStart,h.eventDateEnd))}${h.eventLocation?", "+i(h.eventLocation):""}</div>
  </div>
  <div class="doc-top-right">
    <div class="event-name">${i(h.event||"")}</div>
    <div class="lrp">LRP: ${i(w||"—")}</div>
  </div>
</div>
<table class="info-table">
  <tr><td class="lbl">Artist / Company Name</td><td>${i(u.companyName||"")}</td>
      <td class="lbl">Name &amp; Surname</td><td>${i(u.fullName||"")}</td></tr>
  <tr><td class="lbl">Street &amp; House Number</td><td>${i(u.street||"")}</td>
      <td class="lbl">Postcode &amp; City</td><td>${i(u.postCodeCity||"")}</td></tr>
  <tr><td class="lbl">Country of Origin</td><td>${i(u.countryOfOrigin||"")}</td>
      <td class="lbl">Phone / Mobile</td><td>${i(u.phone||"")}</td></tr>
  <tr><td class="lbl">Email</td><td colspan="3">${i(u.email||"")}</td></tr>
</table>`;let l="";if(p===1){let y=0,R=0,z=0,W=0;const b=[];if(n==="bytype"){const $={};e.products.filter(o=>Z(o)&&G(o).amount>0).forEach(o=>{const r=G(o),c=`${o.type||"Other"}\0${o.tariffNo||""}`;$[c]||($[c]={type:o.type||"Other",tariffNo:o.tariffNo||"",tariffRate:o.tariffRate,vatRate:o.vatRate,amount:0,wkg:0,val:0,hasVal:!1});const f=$[c];f.amount+=r.amount||0,f.wkg+=r.totalWeightKg,r.totalValue!=null&&(f.val+=r.totalValue,f.hasVal=!0),y+=r.amount||0,R+=r.totalWeightKg,r.totalValue!=null&&(z+=r.totalValue)});const x=Object.values($);x.forEach((o,r)=>{b.push(`<tr>
          <td class="c">${r+1}</td><td><strong>${$t(x,o)}</strong></td>
          <td class="r">${i(o.tariffNo)}</td>
          <td class="r">${o.tariffRate!=null?o.tariffRate+"%":""}</td>
          <td class="r">${o.vatRate!=null?o.vatRate+"%":""}</td>
          <td class="r">${o.amount}</td>
          <td class="r">${P(o.wkg)}</td>
          <td class="r">${o.hasVal?o.val:"—"}</td></tr>`)});const s=b.join("");l=`<div class="section-title">List of goods (By Type)</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Type</th><th class="r">HS Code</th>
  <th class="r">Tariff Rate</th><th class="r">VAT Rate</th>
  <th class="r">Total Amount</th><th class="r">Total Weight</th>
  <th class="r">Total Value (${nt(e)})</th>
</tr></thead><tbody>${s}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r">${y}</td><td class="r">${P(R)}</td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td>
</tr></tfoot></table>`}else{e.products.filter(s=>Z(s)&&G(s).amount>0).forEach(s=>{var c;const o=G(s),r=s.originCountry&&s.originCountry.trim()?s.originCountry.trim().toUpperCase():X(u.countryOfOrigin)||"";if(n==="detailed"&&K(s))s.variants.filter(f=>!f.unlisted&&(f.amount||0)>0).forEach(f=>{const v=W++,t=f.weightG!=null?f.weightG:s.weightG,d=f.price!=null?f.price:s.price,g=f.amount||0,C=Math.round(g*(t||0))/1e3,k=d!=null?Math.round(d*g):null,O=s.priceNote||(d!=null?L(E(d,2),2):"—"),N=k!=null?k:"—";y+=g,R+=C,k!=null&&(z+=k),b.push(`<tr><td class="c">${v+1}</td><td>${i(f.sku||s.sku||"")}</td><td>${ht(s,u.fullName)} - ${i(f.name||"")}</td>
              <td>${s.forSale?"For Sale":"Not For Sale"}</td><td>${i(s.type||"")}</td>
              <td class="r">${g}</td><td class="r">${t!=null?t+" g":""}</td>
              <td class="r">${P(C)}</td><td class="r">${i(O)}</td>
              <td class="r">${N}</td><td class="r">${i(s.tariffNo||"")}</td>
              <td class="r">${s.tariffRate!=null?s.tariffRate+"%":""}</td>
              <td class="r">${s.vatRate!=null?s.vatRate+"%":""}</td>
              <td class="c">${i(r)}</td></tr>`)});else{const f=W++,v=s.priceNote||(o.effectiveUnitPrice!=null?L(E(o.effectiveUnitPrice,2),2):"—"),t=o.totalValue!=null?o.totalValue:"—";y+=o.amount||0,R+=o.totalWeightKg,o.totalValue!=null&&(z+=o.totalValue);const d=K(s)?`${ht(s,u.fullName)} (${s.variants.filter(g=>!g.unlisted).length} variants)`:ht(s,u.fullName);b.push(`<tr><td class="c">${f+1}</td><td>${i(s.sku||"")}</td><td>${d}</td>
            <td>${s.forSale?"For Sale":"Not For Sale"}</td><td>${i(s.type||"")}</td>
            <td class="r">${(c=o.amount)!=null?c:""}</td><td class="r">${o.effectiveUnitWeightG!=null?Math.round(o.effectiveUnitWeightG)+" g":""}</td>
            <td class="r">${P(o.totalWeightKg)}</td><td class="r">${i(v)}</td>
            <td class="r">${t}</td><td class="r">${i(s.tariffNo||"")}</td>
            <td class="r">${s.tariffRate!=null?s.tariffRate+"%":""}</td>
            <td class="r">${s.vatRate!=null?s.vatRate+"%":""}</td>
            <td class="c">${i(r)}</td></tr>`)}});const $=b.join("");l=`<div class="section-title">List of goods${n==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr>
  <th>#</th><th>SKU</th><th>Title</th><th>For Sale / Not For Sale</th><th>Type</th>
  <th class="r">Amount</th><th class="r">Unit Weight</th><th class="r">Total Weight</th>
  <th class="r">Unit Price (${nt(e)})</th><th class="r">Total Value (${nt(e)})</th>
  <th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th>
</tr></thead><tbody>${$}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r">${y}</td><td></td><td class="r">${P(R)}</td><td></td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td><td colspan="4"></td>
</tr></tfoot></table>`}}else if(p===2){let y=0,R=0,z=0,W=0;const b=[];if(n==="bytype"){const $={};e.products.forEach(r=>{if(!Z(r))return;const c=G(r);if(!(c.soldQty>0))return;const f=`${r.type||"Other"}\0${r.tariffNo||""}`;$[f]||($[f]={type:r.type||"Other",tariffNo:r.tariffNo||"",tariffRate:r.tariffRate,vatRate:r.vatRate,soldQty:0,soldVal:0,soldWkg:0});const v=$[f];v.soldQty+=c.soldQty||0,v.soldVal+=E(c.soldValue||0,2),v.soldWkg+=c.soldWeightKg,y+=c.soldQty||0,R+=E(c.soldValue||0,2),z+=c.soldWeightKg});const x=Object.values($);x.forEach((r,c)=>{b.push(`<tr>
          <td class="c">${c+1}</td><td><strong>${$t(x,r)}</strong></td>
          <td class="r">${i(r.tariffNo)}</td>
          <td class="r">${r.tariffRate!=null?r.tariffRate+"%":""}</td>
          <td class="r">${r.vatRate!=null?r.vatRate+"%":""}</td>
          <td class="r">${r.soldQty}</td>
          <td class="r">${L(E(r.soldVal,2),2)}</td>
          <td class="r">${P(r.soldWkg)}</td></tr>`)});const s=b.join(""),o=s?"":'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>';l=`<div class="section-title">List of goods sold (By Type)</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Type</th><th class="r">HS Code</th>
  <th class="r">Tariff Rate</th><th class="r">VAT Rate</th>
  <th class="r">Qty Sold</th><th class="r">Value Sold (${nt(e)})</th>
  <th class="r">Sold Weight</th>
</tr></thead><tbody>${s}${o}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r">${y}</td>
  <td class="r">${L(E(R,2),2)}</td>
  <td class="r">${P(z)}</td>
</tr></tfoot></table>`}else{e.products.forEach(o=>{if(!Z(o))return;const r=G(o);if(n==="detailed"&&K(o))o.variants.filter(c=>!c.unlisted).forEach(c=>{if(!(c.soldQty>0))return;W++;const f=c.weightG!=null?c.weightG:o.weightG,v=E(c.soldValue||0,2),t=(c.soldQty||0)*(f||0)/1e3;y+=c.soldQty||0,R+=v,z+=t,b.push(`<tr><td class="c">${W}</td><td>${ct(o,u.fullName)} - ${i(c.name||"")}</td><td>${i(o.type||"")}</td>
              <td class="r">${i(o.tariffNo||"")}</td>
              <td class="r">${c.soldQty||0}</td>
              <td class="r">${L(v,2)}</td>
              <td class="r">${P(t)}</td></tr>`)});else if(r.soldQty>0){W++;const c=E(r.soldValue||0,2);y+=r.soldQty||0,R+=c,z+=r.soldWeightKg;const f=K(o)?`${ct(o,u.fullName)} (${o.variants.filter(v=>!v.unlisted).length} variants)`:ct(o,u.fullName);b.push(`<tr><td class="c">${W}</td><td>${f}</td><td>${i(o.type||"")}</td>
            <td class="r">${i(o.tariffNo||"")}</td>
            <td class="r">${r.soldQty||0}</td>
            <td class="r">${L(c,2)}</td>
            <td class="r">${P(r.soldWeightKg)}</td></tr>`)}else return});const $=b.join(""),x=$?"":'<tr><td colspan="7" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>';l=`<div class="section-title">List of goods sold${n==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Title</th><th>Type</th>
  <th class="r">Tariff no.</th>
  <th class="r">Qty Sold</th><th class="r">Value Sold (${nt(e)})</th>
  <th class="r">Sold Weight</th>
</tr></thead><tbody>${$}${x}</tbody><tfoot><tr>
  <td colspan="4" style="text-align:right">TOTALS</td>
  <td class="r">${y}</td>
  <td class="r">${L(E(R,2),2)}</td>
  <td class="r">${P(z)}</td>
</tr></tfoot></table>`}}else{let y=0,R=0,z=0,W=0;const b=[];if(n==="bytype"){const $={};e.products.forEach(r=>{if(!Z(r))return;const c=gt(r);if(c.retQty<=0)return;const{retQty:f,retWkg:v,retVal:t}=c,d=`${r.type||"Other"}\0${r.tariffNo||""}`;$[d]||($[d]={type:r.type||"Other",tariffNo:r.tariffNo||"",tariffRate:r.tariffRate,vatRate:r.vatRate,retQty:0,retWkg:0,retVal:0,hasVal:!1});const g=$[d];g.retQty+=f,g.retWkg+=v,t!=null&&(g.retVal+=t,g.hasVal=!0),y+=f,R+=v,t!=null&&(z+=t)});const x=Object.values($);x.forEach((r,c)=>{b.push(`<tr>
          <td class="c">${c+1}</td><td><strong>${$t(x,r)}</strong></td>
          <td class="r">${i(r.tariffNo)}</td>
          <td class="r">${r.tariffRate!=null?r.tariffRate+"%":""}</td>
          <td class="r">${r.vatRate!=null?r.vatRate+"%":""}</td>
          <td class="r"><strong>${r.retQty}</strong></td>
          <td class="r">${P(r.retWkg)}</td>
          <td class="r">${r.hasVal?r.retVal:"—"}</td></tr>`)});const s=b.join(""),o=s?"":'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>';l=`<div class="section-title">Return goods list (re-export) (By Type)</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Type</th><th class="r">HS Code</th>
  <th class="r">Tariff Rate</th><th class="r">VAT Rate</th>
  <th class="r">Return Qty</th><th class="r">Return Weight</th>
  <th class="r">Return Value (${nt(e)})</th>
</tr></thead><tbody>${s}${o}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r"><strong>${y}</strong></td>
  <td class="r">${P(R)}</td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td>
</tr></tfoot></table>`}else{e.products.forEach(o=>{var f;if(!Z(o))return;const r=G(o),c=o.originCountry&&o.originCountry.trim()?o.originCountry.trim().toUpperCase():X(u.countryOfOrigin)||"";if(n==="detailed"&&K(o))o.variants.filter(v=>!v.unlisted).forEach(v=>{const t=(v.amount||0)-(v.soldQty||0);if(t<=0)return;W++;const d=v.weightG!=null?v.weightG:o.weightG,g=v.price!=null?v.price:o.price,C=Math.round(t*(d||0))/1e3,k=g!=null?Math.round(g*t):null;y+=t,R+=C,k!=null&&(z+=k);const O=o.priceNote||(g!=null?L(E(g,2),2):"—"),N=k!=null?k:"—";b.push(`<tr><td class="c">${W}</td><td>${ct(o,u.fullName)} - ${i(v.name||"")}</td><td>${i(o.type||"")}</td>
              <td class="r">${v.amount||0}</td><td class="r">${v.soldQty||0}</td>
              <td class="r"><strong>${t}</strong></td>
              <td class="r">${d!=null?d+" g":""}</td>
              <td class="r">${P(C)}</td>
              <td class="r">${i(O)}</td>
              <td class="r">${N}</td>
              <td class="r">${i(o.tariffNo||"")}</td>
              <td class="r">${o.tariffRate!=null?o.tariffRate+"%":""}</td>
              <td class="r">${o.vatRate!=null?o.vatRate+"%":""}</td>
              <td class="c">${i(c)}</td></tr>`)});else{const v=gt(o);if(v.retQty<=0)return;W++;const{retQty:t,retWkg:d,retVal:g}=v;y+=t,R+=d,g!=null&&(z+=g);const C=o.priceNote||(r.effectiveUnitPrice!=null?L(E(r.effectiveUnitPrice,2),2):"—"),k=g!=null?g:"—",O=K(o)?`${ct(o,u.fullName)} (${o.variants.filter(N=>!N.unlisted).length} variants)`:ct(o,u.fullName);b.push(`<tr><td class="c">${W}</td><td>${O}</td><td>${i(o.type||"")}</td>
            <td class="r">${(f=r.amount)!=null?f:""}</td><td class="r">${r.soldQty||0}</td>
            <td class="r"><strong>${t}</strong></td>
            <td class="r">${r.effectiveUnitWeightG!=null?Math.round(r.effectiveUnitWeightG)+" g":""}</td>
            <td class="r">${P(d)}</td>
            <td class="r">${i(C)}</td>
            <td class="r">${k}</td>
            <td class="r">${i(o.tariffNo||"")}</td>
            <td class="r">${o.tariffRate!=null?o.tariffRate+"%":""}</td>
            <td class="r">${o.vatRate!=null?o.vatRate+"%":""}</td>
            <td class="c">${i(c)}</td></tr>`)}});const $=b.join(""),x=$?"":'<tr><td colspan="14" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>';l=`<div class="section-title">Return goods list (re-export)${n==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr>
  <th>#</th><th>Title</th><th>Type</th>
  <th class="r">Original Qty</th><th class="r">Sold Qty</th><th class="r">Return Qty</th>
  <th class="r">Unit Weight</th><th class="r">Return Weight</th>
  <th class="r">Unit Price (${nt(e)})</th><th class="r">Return Value (${nt(e)})</th>
  <th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th>
</tr></thead><tbody>${$}${x}</tbody><tfoot><tr>
  <td colspan="5" style="text-align:right">TOTALS</td>
  <td class="r"><strong>${y}</strong></td><td></td>
  <td class="r">${P(R)}</td><td></td>
  <td class="r" style="color:#c00">${Math.floor(z)}</td><td colspan="4"></td>
</tr></tfoot></table>`}}return`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>${i(M[p])} -${i(h.event||"ZollTool")}</title>
<style>${D}</style></head><body>
${A}
${l}
<div class="signature-section"><strong>Date and Signature</strong><div class="signature-box"></div></div>
</body></html>`}function xe(e,p=null){const n=e.meta,h=e.artist,u=e.meta&&e.meta.currency?e.meta.currency:"CHF";function w(b,$){let x="";if(b===1){let s=0,o=0,r=0,c=0;const f=[];if($==="bytype"){const v={};e.products.filter(Z).forEach(t=>{const d=G(t),g=`${t.type||"Other"}\0${t.tariffNo||""}`;v[g]||(v[g]={type:t.type||"Other",tariffNo:t.tariffNo||"",tariffRate:t.tariffRate,vatRate:t.vatRate,amount:0,wkg:0,val:0,hasVal:!1});const C=v[g];C.amount+=d.amount||0,C.wkg+=d.totalWeightKg,d.totalValue!=null&&(C.val+=d.totalValue,C.hasVal=!0),s+=d.amount||0,o+=d.totalWeightKg,d.totalValue!=null&&(r+=d.totalValue)}),Object.values(v).forEach((t,d)=>{f.push(`<tr><td class="c">${d+1}</td><td><strong>${i(t.type)}</strong></td><td class="r">${i(t.tariffNo)}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="r">${t.amount}</td><td class="r">${P(t.wkg)}</td><td class="r">${t.hasVal?t.val:"—"}</td></tr>`)}),x=`<div class="section-title">List of goods (By Type)</div>
<table class="goods"><thead><tr><th>#</th><th>Type</th><th class="r">HS Code</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="r">Total Amount</th><th class="r">Total Weight</th><th class="r">Total Value (${u})</th></tr></thead>
<tbody>${f.join("")}</tbody><tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r">${s}</td><td class="r">${P(o)}</td><td class="r" style="color:#c00">${Math.floor(r)}</td></tr></tfoot></table>`}else e.products.filter(Z).forEach(t=>{var C;const d=G(t),g=t.originCountry&&t.originCountry.trim()?t.originCountry.trim().toUpperCase():X(h.countryOfOrigin)||"";if($==="detailed"&&K(t))t.variants.forEach(k=>{const O=c++,N=k.weightG!=null?k.weightG:t.weightG,S=k.price!=null?k.price:t.price,U=k.amount||0,ot=Math.round(U*(N||0))/1e3,it=S!=null?Math.round(S*U):null;s+=U,o+=ot,it!=null&&(r+=it),f.push(`<tr><td class="c">${O+1}</td><td>${i(k.sku||t.sku||"")}</td><td>${i(t.title||"")} - ${i(k.name||"")}</td><td>${t.forSale?"For Sale":"Not For Sale"}</td><td>${i(t.type||"")}</td><td class="r">${U}</td><td class="r">${N!=null?N+" g":""}</td><td class="r">${P(ot)}</td><td class="r">${t.priceNote||(S!=null?L(E(S,2),2):"—")}</td><td class="r">${it!=null?it:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(g)}</td></tr>`)});else{const k=c++;s+=d.amount||0,o+=d.totalWeightKg,d.totalValue!=null&&(r+=d.totalValue);const O=K(t)?`${i(t.title||"")} (${t.variants.length} variants)`:`${i(t.title||"")}`;f.push(`<tr><td class="c">${k+1}</td><td>${i(t.sku||"")}</td><td>${O}</td><td>${t.forSale?"For Sale":"Not For Sale"}</td><td>${i(t.type||"")}</td><td class="r">${(C=d.amount)!=null?C:""}</td><td class="r">${d.effectiveUnitWeightG!=null?Math.round(d.effectiveUnitWeightG)+" g":""}</td><td class="r">${P(d.totalWeightKg)}</td><td class="r">${t.priceNote||(d.effectiveUnitPrice!=null?L(E(d.effectiveUnitPrice,2),2):"—")}</td><td class="r">${d.totalValue!=null?d.totalValue:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(g)}</td></tr>`)}}),x=`<div class="section-title">List of goods${$==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr><th>#</th><th>SKU</th><th>Title</th><th>For Sale / Not For Sale</th><th>Type</th><th class="r">Amount</th><th class="r">Unit Weight</th><th class="r">Total Weight</th><th class="r">Unit Price (${u})</th><th class="r">Total Value (${u})</th><th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th></tr></thead>
<tbody>${f.join("")}</tbody><tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r">${s}</td><td></td><td class="r">${P(o)}</td><td></td><td class="r" style="color:#c00">${Math.floor(r)}</td><td colspan="4"></td></tr></tfoot></table>`}else if(b===2){let s=0,o=0,r=0,c=0;const f=[];if($==="bytype"){const v={};e.products.forEach(t=>{if(!Z(t))return;const d=G(t);if(!(d.soldQty>0))return;const g=`${t.type||"Other"}\0${t.tariffNo||""}`;v[g]||(v[g]={type:t.type||"Other",tariffNo:t.tariffNo||"",tariffRate:t.tariffRate,vatRate:t.vatRate,soldQty:0,soldVal:0,soldWkg:0});const C=v[g];C.soldQty+=d.soldQty||0,C.soldVal+=E(d.soldValue||0,2),C.soldWkg+=d.soldWeightKg,s+=d.soldQty||0,o+=E(d.soldValue||0,2),r+=d.soldWeightKg}),Object.values(v).forEach((t,d)=>{f.push(`<tr><td class="c">${d+1}</td><td><strong>${i(t.type)}</strong></td><td class="r">${i(t.tariffNo)}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="r">${t.soldQty}</td><td class="r">${L(E(t.soldVal,2),2)}</td><td class="r">${P(t.soldWkg)}</td></tr>`)}),x=`<div class="section-title">List of goods sold (By Type)</div>
<table class="goods"><thead><tr><th>#</th><th>Type</th><th class="r">HS Code</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="r">Qty Sold</th><th class="r">Value Sold (${u})</th><th class="r">Sold Weight</th></tr></thead>
<tbody>${f.join("")||'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>'}</tbody>
<tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r">${s}</td><td class="r">${L(E(o,2),2)}</td><td class="r">${P(r)}</td></tr></tfoot></table>`}else e.products.forEach(t=>{if(!Z(t))return;const d=G(t);if($==="detailed"&&K(t))t.variants.forEach(g=>{if(!(g.soldQty>0))return;c++;const C=g.weightG!=null?g.weightG:t.weightG,k=E(g.soldValue||0,2),O=(g.soldQty||0)*(C||0)/1e3;s+=g.soldQty||0,o+=k,r+=O,f.push(`<tr><td class="c">${c}</td><td>${i(t.title||"")} - ${i(g.name||"")}</td><td>${i(t.type||"")}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${g.soldQty||0}</td><td class="r">${L(k,2)}</td><td class="r">${P(O)}</td></tr>`)});else if(d.soldQty>0){c++;const g=E(d.soldValue||0,2);s+=d.soldQty||0,o+=g,r+=d.soldWeightKg;const C=K(t)?`${i(t.title||"")} (${t.variants.length} variants)`:i(t.title||"");f.push(`<tr><td class="c">${c}</td><td>${C}</td><td>${i(t.type||"")}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${d.soldQty||0}</td><td class="r">${L(g,2)}</td><td class="r">${P(d.soldWeightKg)}</td></tr>`)}}),x=`<div class="section-title">List of goods sold${$==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr><th>#</th><th>Title</th><th>Type</th><th class="r">Tariff no.</th><th class="r">Qty Sold</th><th class="r">Value Sold (${u})</th><th class="r">Sold Weight</th></tr></thead>
<tbody>${f.join("")||'<tr><td colspan="7" style="text-align:center;color:#888;padding:8px">No sold quantities entered</td></tr>'}</tbody>
<tfoot><tr><td colspan="4" style="text-align:right">TOTALS</td><td class="r">${s}</td><td class="r">${L(E(o,2),2)}</td><td class="r">${P(r)}</td></tr></tfoot></table>`}else{let s=0,o=0,r=0,c=0;const f=[];if($==="bytype"){const v={};e.products.forEach(t=>{if(!Z(t))return;const d=gt(t);if(d.retQty<=0)return;const{retQty:g,retWkg:C,retVal:k}=d,O=`${t.type||"Other"}\0${t.tariffNo||""}`;v[O]||(v[O]={type:t.type||"Other",tariffNo:t.tariffNo||"",tariffRate:t.tariffRate,vatRate:t.vatRate,retQty:0,retWkg:0,retVal:0,hasVal:!1});const N=v[O];N.retQty+=g,N.retWkg+=C,k!=null&&(N.retVal+=k,N.hasVal=!0),s+=g,o+=C,k!=null&&(r+=k)}),Object.values(v).forEach((t,d)=>{f.push(`<tr><td class="c">${d+1}</td><td><strong>${i(t.type)}</strong></td><td class="r">${i(t.tariffNo)}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="r"><strong>${t.retQty}</strong></td><td class="r">${P(t.retWkg)}</td><td class="r">${t.hasVal?t.retVal:"—"}</td></tr>`)}),x=`<div class="section-title">Return goods list (re-export) (By Type)</div>
<table class="goods"><thead><tr><th>#</th><th>Type</th><th class="r">HS Code</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="r">Return Qty</th><th class="r">Return Weight</th><th class="r">Return Value (${u})</th></tr></thead>
<tbody>${f.join("")||'<tr><td colspan="8" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>'}</tbody>
<tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r"><strong>${s}</strong></td><td class="r">${P(o)}</td><td class="r" style="color:#c00">${Math.floor(r)}</td></tr></tfoot></table>`}else e.products.forEach(t=>{var g;if(!Z(t))return;const d=t.originCountry&&t.originCountry.trim()?t.originCountry.trim().toUpperCase():X(h.countryOfOrigin)||"";if($==="detailed"&&K(t))t.variants.forEach(C=>{const k=(C.amount||0)-(C.soldQty||0);if(k<=0)return;c++;const O=C.weightG!=null?C.weightG:t.weightG,N=C.price!=null?C.price:t.price,S=Math.round(k*(O||0))/1e3,U=N!=null?Math.round(N*k):null;s+=k,o+=S,U!=null&&(r+=U),f.push(`<tr><td class="c">${c}</td><td>${i(t.title||"")} - ${i(C.name||"")}</td><td>${i(t.type||"")}</td><td class="r">${C.amount||0}</td><td class="r">${C.soldQty||0}</td><td class="r"><strong>${k}</strong></td><td class="r">${O!=null?O+" g":""}</td><td class="r">${P(S)}</td><td class="r">${t.priceNote||(N!=null?L(E(N,2),2):"—")}</td><td class="r">${U!=null?U:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(d)}</td></tr>`)});else{const C=gt(t);if(C.retQty<=0)return;c++;const{retQty:k,retWkg:O,retVal:N}=C,S=G(t);s+=k,o+=O,N!=null&&(r+=N);const U=K(t)?`${i(t.title||"")} (${t.variants.filter(ot=>!ot.unlisted).length} variants)`:i(t.title||"");f.push(`<tr><td class="c">${c}</td><td>${U}</td><td>${i(t.type||"")}</td><td class="r">${(g=S.amount)!=null?g:""}</td><td class="r">${S.soldQty||0}</td><td class="r"><strong>${k}</strong></td><td class="r">${S.effectiveUnitWeightG!=null?Math.round(S.effectiveUnitWeightG)+" g":""}</td><td class="r">${P(O)}</td><td class="r">${t.priceNote||(S.effectiveUnitPrice!=null?L(E(S.effectiveUnitPrice,2),2):"—")}</td><td class="r">${N!=null?N:"—"}</td><td class="r">${i(t.tariffNo||"")}</td><td class="r">${t.tariffRate!=null?t.tariffRate+"%":""}</td><td class="r">${t.vatRate!=null?t.vatRate+"%":""}</td><td class="c">${i(d)}</td></tr>`)}}),x=`<div class="section-title">Return goods list (re-export)${$==="detailed"?" (Detailed)":" (Compressed)"}</div>
<table class="goods"><thead><tr><th>#</th><th>Title</th><th>Type</th><th class="r">Original Qty</th><th class="r">Sold Qty</th><th class="r">Return Qty</th><th class="r">Unit Weight</th><th class="r">Return Weight</th><th class="r">Unit Price (${u})</th><th class="r">Return Value (${u})</th><th class="r">Tariff no.</th><th class="r">Tariff Rate</th><th class="r">VAT Rate</th><th class="c">Origin</th></tr></thead>
<tbody>${f.join("")||'<tr><td colspan="14" style="text-align:center;color:#888;padding:8px">All items sold - no return goods</td></tr>'}</tbody>
<tfoot><tr><td colspan="5" style="text-align:right">TOTALS</td><td class="r"><strong>${s}</strong></td><td></td><td class="r">${P(o)}</td><td></td><td class="r" style="color:#c00">${Math.floor(r)}</td><td colspan="4"></td></tr></tfoot></table>`}return x}const M=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 8pt; color: #000; padding: 12mm; }
  .doc-section { page-break-after: always; padding-bottom: 8mm; }
  .doc-section:last-child { page-break-after: auto; }
  .page-label { font-size: 9pt; font-weight: bold; color: #555; text-transform: uppercase;
                letter-spacing: 0.05em; border-bottom: 2px solid #888; padding-bottom: 3px;
                margin-bottom: 5mm; }
  .doc-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6mm; }
  .doc-top-left .doc-title { font-size: 10pt; font-weight: bold; text-transform: uppercase; }
  .doc-top-left .doc-subtitle { font-size: 8pt; color: #444; margin-top: 2px; }
  .doc-top-right { text-align: right; }
  .doc-top-right .event-name { font-size: 11pt; font-weight: bold; }
  .doc-top-right .lrp { font-size: 8pt; margin-top: 3px; }
  .info-table { width: 100%; border-collapse: collapse; margin-bottom: 5mm; }
  .info-table td { padding: 2px 6px; font-size: 8pt; border: 1px solid #ccc; }
  .info-table td.lbl { font-weight: bold; background: #f4f4f4; width: 130px; font-size: 7.5pt; }
  .section-title { font-weight: bold; font-size: 9pt; margin: 4mm 0 2mm 0; border-bottom: 1.5px solid #000; padding-bottom: 1mm; }
  table.goods { width: 100%; border-collapse: collapse; font-size: 7pt; }
  table.goods th { background: #e8e8e8; border: 1px solid #aaa; padding: 3px 4px; text-align: left; font-size: 6.5pt; font-weight: bold; white-space: nowrap; }
  table.goods td { border: 1px solid #ccc; padding: 2px 4px; vertical-align: middle; }
  table.goods tr:nth-child(even) td { background: #fafafa; }
  table.goods tfoot td { background: #e8e8e8; font-weight: bold; border: 1px solid #aaa; padding: 3px 4px; }
  .r { text-align: right; } .c { text-align: center; }
  .signature-section { margin-top: 8mm; }
  .signature-box { border: 1px solid #000; width: 80mm; height: 22mm; margin-top: 2mm; }
  @media print { body { padding: 0; } @page { size: A4 landscape; margin: 12mm; } }`,D=`<table class="info-table">
  <tr><td class="lbl">Artist / Company Name</td><td>${i(h.companyName||"")}</td>
      <td class="lbl">Name &amp; Surname</td><td>${i(h.fullName||"")}</td></tr>
  <tr><td class="lbl">Street &amp; House Number</td><td>${i(h.street||"")}</td>
      <td class="lbl">Postcode &amp; City</td><td>${i(h.postCodeCity||"")}</td></tr>
  <tr><td class="lbl">Country of Origin</td><td>${i(h.countryOfOrigin||"")}</td>
      <td class="lbl">Phone / Mobile</td><td>${i(h.phone||"")}</td></tr>
  <tr><td class="lbl">Email</td><td colspan="3">${i(h.email||"")}</td></tr>
</table>`;function A(b){const $=St(e,b);return`<div class="doc-top">
  <div class="doc-top-left">
    <div class="doc-title">${i({1:"Auxiliary Document for the Customs Declaration - Import",2:"Auxiliary Document for the Customs Declaration - Sold Goods",3:"Return Goods List - Re-export Declaration"}[b])}</div>
    <div class="doc-subtitle">${i(Ht(n.eventDateStart,n.eventDateEnd))}${n.eventLocation?", "+i(n.eventLocation):""}</div>
  </div>
  <div class="doc-top-right">
    <div class="event-name">${i(n.event||"")}</div>
    <div class="lrp">LRP: ${i($||"—")}</div>
  </div>
</div>${D}`}const l=["detailed","compressed","bytype"],V={detailed:"Detailed",compressed:"Compressed",bytype:"By Type"},y=p?[p]:[1,2,3],R={1:"Import",2:"Sold",3:"Return"},z=[];return y.forEach(b=>{l.forEach($=>{const x=`${R[b]} - ${V[$]}`;z.push(`<div class="doc-section">
  <div class="page-label">${i(x)}</div>
  ${A(b)}
  ${w(b,$)}
  <div class="signature-section"><strong>Date and Signature</strong><div class="signature-box"></div></div>
</div>`)})}),`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>All Documents - ${i(n.event||"ZollTool")}</title>
<style>${M}</style></head><body>
${z.join(`
`)}
</body></html>`}function $e(e,p=new Date){const n=e.meta,h=e.artist,u=e.meta&&e.meta.currency?e.meta.currency:"CHF",w=p.toLocaleDateString("en-GB",{day:"2-digit",month:"long",year:"numeric"}),M=e.products.filter(Z),D=`
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 9pt; color: #000; padding: 15mm; }
  .watermark { text-align: center; font-size: 8pt; color: #c00; font-weight: bold; letter-spacing: 1px;
               border: 1.5px solid #c00; padding: 4px 10px; display: inline-block; margin-bottom: 6mm; text-transform: uppercase; }
  .doc-title { font-size: 16pt; font-weight: bold; text-transform: uppercase; margin-bottom: 1mm; }
  .doc-subtitle { font-size: 8pt; color: #555; margin-bottom: 6mm; }
  .parties { display: flex; gap: 10mm; margin-bottom: 6mm; }
  .party { flex: 1; border: 1px solid #ccc; padding: 4mm; }
  .party-label { font-size: 7pt; font-weight: bold; text-transform: uppercase; color: #666; margin-bottom: 2mm; border-bottom: 1px solid #ddd; padding-bottom: 1mm; }
  .party-name { font-size: 10pt; font-weight: bold; margin-bottom: 1mm; }
  .party-detail { font-size: 8pt; line-height: 1.5; color: #222; }
  .meta-row { display: flex; gap: 8mm; margin-bottom: 6mm; font-size: 8pt; }
  .meta-item { }
  .meta-item .meta-label { font-weight: bold; font-size: 7pt; text-transform: uppercase; color: #666; }
  .meta-item .meta-value { font-size: 9pt; margin-top: 1px; }
  table.goods { width: 100%; border-collapse: collapse; font-size: 8pt; margin-bottom: 6mm; }
  table.goods th { background: #222; color: #fff; padding: 4px 6px; text-align: left; font-size: 7.5pt; white-space: nowrap; }
  table.goods th.r { text-align: right; }
  table.goods td { border-bottom: 1px solid #ddd; padding: 4px 6px; vertical-align: middle; }
  table.goods tr:nth-child(even) td { background: #f8f8f8; }
  table.goods tfoot td { background: #eee; font-weight: bold; border-top: 2px solid #555; padding: 5px 6px; }
  .r { text-align: right; }
  .total-box { border: 2px solid #000; display: inline-block; padding: 4mm 8mm; margin-bottom: 6mm; }
  .total-box .total-label { font-size: 8pt; text-transform: uppercase; color: #555; }
  .total-box .total-value { font-size: 14pt; font-weight: bold; }
  .declaration { font-size: 7.5pt; color: #333; border-top: 1px solid #ccc; padding-top: 4mm; margin-bottom: 6mm; line-height: 1.6; }
  .sig-block { display: inline-block; width: 100mm; }
  .sig-label { font-size: 7.5pt; color: #555; margin-bottom: 1mm; }
  .sig-line { border-top: 1px solid #000; padding-top: 2mm; font-size: 7.5pt; color: #777; margin-top: 10mm; }
  @media print { body { padding: 0; } @page { size: A4 portrait; margin: 15mm; } }`;let A=0,l=0,V=0;const y=M.map((b,$)=>{const x=G(b),s=x.amount||0,o=x.effectiveUnitPrice!=null?L(E(x.effectiveUnitPrice,2),2):b.priceNote||"—",r=x.totalValue!=null?x.totalValue:0,c=b.originCountry&&b.originCountry.trim()?b.originCountry.trim().toUpperCase():X(h.countryOfOrigin)||"";return A+=s,l+=r,V+=x.totalWeightKg,`<tr>
      <td class="r">${$+1}</td>
      <td>${i(b.title||"")}</td>
      <td>${i(b.tariffNo||"—")}</td>
      <td class="r">${s}</td>
      <td class="r">${x.effectiveUnitWeightG!=null?Math.round(x.effectiveUnitWeightG)+" g":"—"}</td>
      <td class="r">${P(x.totalWeightKg)}</td>
      <td class="r">${i(String(o))}</td>
      <td class="r">${x.totalValue!=null?x.totalValue:"—"}</td>
      <td class="r">${c}</td>
    </tr>`}).join(""),R=[n.venueName||h.fullName||h.companyName||"",n.event?"c/o "+n.event:"",n.venueStreet||"",[n.venuePostcode,n.venueCity].filter(Boolean).join(" "),n.venueCountry||""].filter(Boolean).join("<br>"),z=[h.companyName||"",h.fullName||"",h.street||"",h.postCodeCity||"",h.countryOfOrigin||""].filter(Boolean).join("<br>");return`<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>Proforma Invoice -${i(n.event||"ZollTool")}</title>
<style>${D}</style></head><body>
<div class="watermark">For Customs Clearance Purposes Only &mdash; Not for Commercial Use</div>
<div class="doc-title">Proforma Invoice</div>
<div class="doc-subtitle">This document is issued solely for customs clearance and does not constitute a commercial transaction.</div>

<div class="parties">
  <div class="party">
    <div class="party-label">Seller / Exporter</div>
    <div class="party-name">${i(h.companyName||h.fullName||"")}</div>
    <div class="party-detail">${z}</div>
  </div>
  <div class="party">
    <div class="party-label">Consignee / Importer</div>
    <div class="party-name">${i(n.venueName||h.fullName||"")}</div>
    <div class="party-detail">${R}</div>
  </div>
</div>

<div class="meta-row">
  <div class="meta-item"><div class="meta-label">Invoice Date</div><div class="meta-value">${w}</div></div>
  <div class="meta-item"><div class="meta-label">Event</div><div class="meta-value">${i(n.event||"—")}</div></div>
  <div class="meta-item"><div class="meta-label">Event Dates</div><div class="meta-value">${i([n.eventDateStart,n.eventDateEnd].filter(Boolean).join(" – ")||"—")}</div></div>
  <div class="meta-item"><div class="meta-label">Currency</div><div class="meta-value">${i(u)}</div></div>
</div>

<table class="goods">
  <thead><tr>
    <th class="r">#</th>
    <th>Description</th>
    <th>HS / Tariff Code</th>
    <th class="r">Qty</th>
    <th class="r">Unit Weight</th>
    <th class="r">Total Weight</th>
    <th class="r">Unit Value (${i(u)})</th>
    <th class="r">Total Value (${i(u)})</th>
    <th class="r">Origin</th>
  </tr></thead>
  <tbody>${y||'<tr><td colspan="9" style="text-align:center;padding:8px;color:#888">No products with customs information</td></tr>'}</tbody>
  <tfoot><tr>
    <td></td><td style="text-align:right">TOTALS</td><td></td>
    <td class="r">${A}</td><td></td>
    <td class="r">${P(V)}</td><td></td>
    <td class="r">${Math.floor(l)}</td><td></td>
  </tr></tfoot>
</table>

<div class="total-box">
  <div class="total-label">Total Declared Value</div>
  <div class="total-value">${i(u)} ${Math.floor(l).toLocaleString("de-CH")}</div>
  <div class="total-label" style="margin-top:3mm">Total Gross Weight</div>
  <div class="total-value">${P(V)}</div>
</div>

<div class="declaration">
  <strong>Declaration:</strong> I, the undersigned, hereby certify that the information on this proforma invoice is true and correct
  and that the contents of this consignment are as stated above. This invoice is issued for customs clearance purposes only
  and does not represent a commercial sale. The goods are temporarily imported into ${i(n.venueCountry||"the destination country")} for exhibition/sale at
  ${i(n.event||"the event")} and will be re-exported or accounted for after the event.
</div>

<div class="sig-block">
  <div class="sig-label">Signature &amp; Date</div>
  <div class="sig-line">${i(h.fullName||h.companyName||"")} &nbsp;&nbsp;·&nbsp;&nbsp; Date: _______________</div>
</div>
</body></html>`}function we(e,p=new Date){const n=e.meta,h=e.artist,u=e.edec,w=X(h.countryOfOrigin)||"",M=Gt[w]||w,D=[h.companyName,h.fullName,h.street,h.postCodeCity,M].filter(Boolean).join(`
`),A=[n.event,n.venueStreet,[n.venuePostcode,n.venueCity].filter(Boolean).join(" "),n.venueCountry||""].filter(Boolean).join(`
`),l=(u.transportationCountry||"").trim().toUpperCase(),V=u.transportMode||"3",y=V==="4",R=(u.flightNumber||"").trim(),W={1:"80",2:"20",3:"30",4:"40",5:"50",9:"90"}[V]||"30",b=V==="3"&&l||w,$=(n.venuePostcode||"").trim()||"______",{g1:x,g2:s,hasG2:o}=Rt(e),r=e.products.map(N=>N.title).filter(Boolean).join(", "),c=p.toLocaleDateString("de-CH",{day:"2-digit",month:"2-digit",year:"numeric"}),f=(N,S=!1)=>N?`<span class="fv${S?" warn":""}">${i(N)}</span>`:'<span class="ev">——</span>',v=N=>N?`<span class="fv pre">${i(N)}</span>`:'<span class="ev">——</span>';function t(N,S){return`<div class="ch"><span class="cn">${i(N)}</span><span class="cl">${i(S)}</span></div>`}function d(N,S=""){const U=S?` style="text-align:${S}"`:"";return N?`<td${U}><span class="gfv">${i(N)}</span></td>`:`<td${U}></td>`}function g(N,S,U){return`<tr>
      <td class="rn">${N}</td>
      ${d(S)}
      ${d(U)}
    </tr>`}function C(N,S,U,ot,it,bt){return`<tr>
      <td class="rn">${N}</td>
      <td></td><td></td>
      ${d(S,"center")}
      <td></td>
      ${d(U,"right")}
      ${d(ot,"center")}
      ${d(it,"right")}
      ${d(bt,"right")}
      <td></td><td></td>
    </tr>`}return`<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<title>Formular 11.74 -${i(n.event||"ZollTool")}</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, Helvetica, sans-serif; font-size: 6.5pt; color: #000; background: #b0b0b0; }

.print-bar {
  background: #222; color: #fff; padding: 7px 14px; font-size: 10pt;
  display: flex; align-items: center; gap: 12px; position: sticky; top: 0; z-index: 9;
}
.print-bar button {
  background: #1a6ecc; color: #fff; border: none; padding: 5px 16px;
  font-size: 10pt; cursor: pointer; border-radius: 3px; font-weight: bold;
}
.print-bar .hint { font-size: 7.5pt; color: #aaa; }

.page {
  width: 210mm; min-height: 297mm; margin: 8mm auto;
  background: #fff; display: flex; border: 1px solid #444;
}

/* ── Side strips ── */
.strip {
  width: 13mm; background: #f3accc; flex-shrink: 0;
  display: flex; flex-direction: column; align-items: center;
  padding: 3mm 1mm; position: relative; overflow: hidden;
}
.strip-a { font-size: 18pt; font-weight: bold; color: #000; line-height: 1; flex-shrink: 0; }
.strip-title {
  font-size: 4.5pt; color: #000; writing-mode: vertical-rl;
  transform: rotate(180deg); margin-top: 4mm; line-height: 1.5;
  white-space: nowrap; flex-shrink: 0;
}
.strip-r .strip-a { margin-top: auto; }

/* ── Form body ── */
.fb { flex: 1; display: flex; flex-direction: column; border-left: 0.5px solid #666; border-right: 0.5px solid #666; }

/* ── Cell base ── */
.cell { border: 0.5px solid #666; padding: 1.2mm 1.5mm; position: relative; min-height: 10mm; }
.ch { display: flex; align-items: baseline; gap: 1.5mm; margin-bottom: 1mm; }
.cn { font-size: 5.5pt; font-weight: bold; color: #444; white-space: nowrap; flex-shrink: 0; }
.cl { font-size: 4.8pt; color: #555; line-height: 1.3; }
.cv { font-size: 7pt; line-height: 1.5; }

/* Pre-filled values */
.fv     { font-weight: bold; color: #003ab5; }
.fv.pre { white-space: pre-wrap; }
.fv.warn { font-weight: bold; color: #cc0000; }
.ev     { color: #bbb; font-style: italic; }
.warn-note { font-size: 5pt; color: #cc0000; font-style: italic; margin-top: 1mm; }

/* ── Header row ── */
.hdr { display: flex; border-bottom: 0.5px solid #666; align-items: stretch; }
.hdr-admin { flex: 0 0 auto; padding: 1.5mm 2mm; font-size: 4.8pt; line-height: 1.5; border-right: 0.5px solid #666; }
.hdr-copy  { flex: 1; padding: 1.5mm 2mm; font-size: 5pt; display: flex; align-items: flex-end; }
.hdr-num   { flex: 0 0 auto; padding: 1.5mm 3mm; border-left: 0.5px solid #666; text-align: right; }
.form-number { font-size: 22pt; font-weight: bold; line-height: 1; }
.form-ref    { font-size: 4.5pt; color: #666; }

/* ── Top section (fields 1-13) ── */
.top { display: flex; border-bottom: 0.5px solid #666; }
.lc  { flex: 0 0 56%; border-right: 0.5px solid #666; display: flex; flex-direction: column; }
.lc .cell { border: none; border-bottom: 0.5px solid #666; flex: 1; }
.lc .cell:last-child { border-bottom: none; }

.rc { flex: 1; display: flex; flex-direction: column; }
.rc .cell { border: none; border-bottom: 0.5px solid #666; }
.rc .cell:last-child { border-bottom: none; flex: 1; }
.rc-top { display: flex; border-bottom: 0.5px solid #666; }
.rc-top .cell { border: none; flex: 1; }
.rc-top .cell:first-child { border-right: 0.5px solid #666; }

/* ── Field 4/5 / 14/15 section ── */
.mid { display: flex; border-bottom: 0.5px solid #666; }
.ml { flex: 0 0 56%; border-right: 0.5px solid #666; display: flex; flex-direction: column; }
.ml .cell { border: none; border-bottom: 0.5px solid #666; }
.ml .cell:last-child { border-bottom: none; flex: 1; }
.mr { flex: 1; display: flex; flex-direction: column; }
.mr .cell { border: none; border-bottom: 0.5px solid #666; }
.mr .cell:last-child { border-bottom: none; flex: 1; }

.cb-row { display: flex; gap: 3mm; flex-wrap: wrap; margin: 1mm 0; }
.cb { display: inline-flex; align-items: center; gap: 1mm; font-size: 5pt; color: #333; }
.cb-box { width: 3mm; height: 3mm; border: 0.5px solid #555; display: inline-block; flex-shrink: 0; background: #fff; }
.cb-box.chk { background: #000; }
.f4sub { font-size: 5pt; color: #555; margin-top: 1mm; line-height: 1.7; }

/* ── Goods table ── */
.gt-wrap { border-bottom: 0.5px solid #666; }
table.gt {
  width: 100%; border-collapse: collapse; font-size: 5pt; table-layout: fixed;
}
table.gt th, table.gt td {
  border: 0.5px solid #666; padding: 0.8mm 1mm; vertical-align: top;
}
table.gt th { font-weight: bold; font-size: 4.8pt; line-height: 1.3; background: #fff; }
table.gt td { height: 16mm; vertical-align: top; }
td.rn    { text-align: center; font-size: 8pt; font-weight: bold; vertical-align: top; padding-top: 1.5mm; }
.gfv     { font-weight: bold; color: #003ab5; font-size: 5.5pt; white-space: pre-wrap; }
.th-hint { display: block; font-size: 4pt; color: #c00; font-weight: normal; margin-top: 1mm; line-height: 1.3; }

/* Description table (16 + 17) column widths */
col.d-rn { width: 3%; }
col.d-16 { width: 14%; }
/* col.d-17 fills remaining */

/* Numeric table (18–27) column widths -must total 100% */
col.n-rn { width: 3%; }
col.n-18 { width: 5%; }
col.n-19 { width: 5%; }
col.n-20 { width: 15%; }
col.n-21 { width: 6%; }
col.n-22 { width: 12%; }
col.n-23 { width: 11%; }
col.n-24 { width: 13%; }
col.n-25 { width: 15%; }
col.n-26 { width: 7.5%; }
col.n-27 { width: 7.5%; }

/* ── Bottom section ── */
.bot { display: flex; flex: 1; }
.bl  { flex: 0 0 56%; border-right: 0.5px solid #666; display: flex; flex-direction: column; }
.bl .cell { border: none; border-bottom: 0.5px solid #666; }
.bl .cell:last-child { border-bottom: none; flex: 1; }
.br  { flex: 1; display: flex; flex-direction: column; }
.br .cell { border: none; border-bottom: 0.5px solid #666; }
.br .cell:last-child { border-bottom: none; flex: 1; }

/* Horizontal field: label left, value right */
.hfield { display: flex; align-items: center; gap: 2mm; }
.hfield-label { flex: 1; }
.hfield-value { flex: 0 0 auto; font-size: 8pt; font-weight: bold; color: #003ab5;
                border-left: 0.5px solid #ccc; padding-left: 2mm; min-width: 10mm; text-align: center; }

.sig-line { border-bottom: 0.5px solid #888; min-height: 10mm; margin-top: 1.5mm; }
.sig-note { font-size: 4.8pt; color: #cc0000; font-style: italic; margin-top: 0.8mm; }
.subtotal-label { font-size: 4.8pt; color: #555; margin: 1.5mm 0 0.5mm 0; }

@media print {
  .print-bar { display: none; }
  body { background: #fff; }
  .page { margin: 0; border: none; box-shadow: none; }
  @page { size: A4 portrait; margin: 0mm; }
}</style></head><body>

<div class="print-bar">
  <button onclick="window.print()">🖨&nbsp; Print / Save as PDF</button>
  <span class="hint">Pre-filled values shown in <strong style="color:#6699ee">bold blue</strong> &nbsp;·&nbsp; Verify all fields before signing &nbsp;·&nbsp; ${i(n.event||"")} &nbsp;·&nbsp; Generated ${c}</span>
</div>

<div class="page">

  <!-- Left pink strip -->
  <div class="strip">
    <div class="strip-a">A</div>
    <div class="strip-title">Vorübergehende Verwendung mit hinterlegtem Betrag · Admission temporaire à montant déposé · Ammissione temporanea con importo depositato</div>
  </div>

  <!-- Form body -->
  <div class="fb">

    <!-- Header -->
    <div class="hdr">
      <div class="hdr-admin">
        Eidgenössische Zollverwaltung EZV<br>
        Administration fédérale des douanes AFD<br>
        Amministrazione federale delle dogane AFD
      </div>
      <div class="hdr-copy">Kopie für / Copie pour / Copia per &nbsp;→</div>
      <div class="hdr-num">
        <div class="form-number">11.74</div>
        <div class="form-ref">606.000.11.74</div>
      </div>
    </div>

    <!-- Fields 1–13 -->
    <div class="top">
      <div class="lc">
        <div class="cell">
          ${t("1","Versender / Expéditeur / Speditore")}
          <div class="cv">${v(D)}</div>
        </div>
        <div class="cell">
          ${t("2","Eigentümer der Ware / Propriétaire de la marchandise / Proprietario della merce")}
          <div class="cv">${v(D)}</div>
        </div>
        <div class="cell">
          ${t("3","Empfänger/Importeur / Destinataire/Importateur / Destinatario/Importatore")}
          <div class="cv">${v(A)}</div>
        </div>
      </div>
      <div class="rc">
        <div class="rc-top">
          <div class="cell">
            ${t("6","Vordokument / Document précédent / Documento precedente")}
            <div class="cv">${y&&R?f(R):'<span style="font-size:5pt;color:#888">Nr. / No / N. ___________</span>'}</div>
          </div>
          <div class="cell">
            ${t("7","Konto-Nr. / Compte No / Conto N.")}
            <div class="cv"><span class="ev">——</span></div>
          </div>
        </div>
        <div class="cell" style="min-height:7mm">
          ${t("8","Einfuhr / Import. / Import")}
          <div class="cv">
            <span class="cb"><span class="cb-box chk"></span> Einfuhr / Import. / Import</span>
            &nbsp;&nbsp;
            <span class="cb"><span class="cb-box"></span> Ausfuhr / Export. / Esport.</span>
          </div>
        </div>
        <div class="cell" style="min-height:7mm">
          ${t("9","Verfalldatum / Echéance / Scadenza")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell hfield" style="min-height:7mm">
          <div class="hfield-label">${t("10","Ursprungsland / Pays d'origine / Paese d'origine")}</div>
          <div class="hfield-value">${f(w)}</div>
        </div>
        <div class="cell hfield" style="min-height:7mm">
          <div class="hfield-label">${t("11","Land der vorübergehenden Bestimmung / Pays de destination temporaire / Paese di destinazione temporanea")}</div>
          <div class="hfield-value">${f(X(n.venueCountry)||"CH")}</div>
        </div>
        <div class="cell hfield" style="min-height:7mm">
          <div class="hfield-label">${t("12","Land der endgültigen Bestimmung / Pays de destination définitive / Paese di destinazione definitiva")}</div>
          <div class="hfield-value">${f(w)}</div>
        </div>
        <div class="cell">
          ${t("13","Verwendungszweck der Ware / Emploi de la marchandise / Scopo d'impiego della merce")}
          <div class="cv">${f("Verkauf an Ausstellungen / Messen · Vente aux expositions / foires")}</div>
        </div>
      </div>
    </div>

    <!-- Field 4 / 5 + 14 / 15 -->
    <div class="mid">
      <div class="ml">
        <div class="cell">
          ${t("4","Präferenzbehandlung / Régime préférentiel / Trattamento preferenziale")}
          <div class="cb-row">
            <span class="cb"><span class="cb-box"></span> Europäische Freihandelszone / Zone européenne de libre-échange / Zona europea di libero scambio</span>
          </div>
          <div class="cb-row">
            <span class="cb"><span class="cb-box"></span> Allgemeines Präferenzsystem / Système généralisé de préférences / Sistema generale di preferenze</span>
          </div>
          <div class="f4sub">
            WVB/UZ Nr. _________ vom / CCM/CO No _________ du / CCM/CO N. _________ del
          </div>
        </div>
        <div class="cell">
          ${t("5","VTS/SMT · Immat. Land / Pays d'immatr. / Paese d'immatr. · PLZ/NPA/CAP")}
          <div style="display:flex;gap:2mm;align-items:flex-start;margin-top:1mm">
            <div style="flex:0 0 auto;border-right:0.5px solid #ccc;padding-right:2mm">
              <div style="font-size:4pt;color:#666;margin-bottom:0.5mm">VTS/SMT</div>
              <span class="fv">${i(W)}</span>
            </div>
            <div style="flex:0 0 auto;border-right:0.5px solid #ccc;padding-right:2mm">
              <div style="font-size:4pt;color:#666;margin-bottom:0.5mm">Immat. Land / Pays / Paese</div>
              <span class="fv">${i(b||"______")}</span>
            </div>
            <div style="flex:0 0 auto">
              <div style="font-size:4pt;color:#666;margin-bottom:0.5mm">PLZ/NPA/CAP</div>
              <span class="fv">${i($)}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="mr">
        <div class="cell" style="min-height:8mm">
          ${t("14","Mietgeschäft / Location / Locazione")}
          <div class="cv">
            <span class="cb"><span class="cb-box"></span> ja / oui / sì</span>
            &nbsp;&nbsp;
            <span class="cb"><span class="cb-box"></span> nein / non / no</span>
          </div>
        </div>
        <div class="cell">
          ${t("15","Abschlusszollstelle / Bureau de douane d'apurement / Ufficio doganale della conclusione")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
      </div>
    </div>

    <!-- Goods table: 16 + 17 (description) -->
    <div class="gt-wrap" style="border-bottom:none">
      <table class="gt">
        <colgroup>
          <col class="d-rn"><col class="d-16"><!-- d-17 fills rest -->
        </colgroup>
        <thead><tr>
          <th></th>
          <th>16 Zeichen, Nr., Anzahl, Verpackung<br>Marque, no, nombre, emballage<br>Marca, n., quantità, imballaggio</th>
          <th>17 Genaue Warenbezeichnung (Material, Typ, Nummern, etc.), die eine Identifikation der Ware sicherstellt<br>Désignation exacte de la marchandise (matière, type, numéros, etc.) garantissant son identification<br>Designazione esatta della merce (materiale, tipo, numeri, ecc.), che garantisce l'identificazione della merce</th>
        </tr></thead>
        <tbody>
          ${g(1,"see attached list",r||"—")}
          ${o?g(2,"",""):""}
        </tbody>
      </table>
    </div>

    <!-- Goods table: 18–27 (numeric columns) -->
    <div class="gt-wrap">
      <table class="gt">
        <colgroup>
          <col class="n-rn"><col class="n-18"><col class="n-19"><col class="n-20">
          <col class="n-21"><col class="n-22"><col class="n-23">
          <col class="n-24"><col class="n-25"><col class="n-26"><col class="n-27">
        </colgroup>
        <thead><tr>
          <th></th>
          <th>18<br>NHW<br>MNC<br><span class="th-hint">Statistical goods code - leave blank if unknown</span></th>
          <th>19<br>VC<br>CT<br><span class="th-hint">Mode of transport carrier code - leave blank</span></th>
          <th>20 Tarif-Nr.<br>No de tarif<br>Voce di tariffa<br><span class="th-hint">HS tariff number of the goods</span></th>
          <th>21<br>Schlüssel<br>Clé<br>N.conv.<br><span class="th-hint">Quantity unit/conversion key - leave blank</span></th>
          <th>22 Eigenmasse<br>Masse nette<br>Massa netta<br><span class="th-hint">Net weight in kg (without packaging)</span></th>
          <th>23 Zusatzmenge<br>Unités suppl.<br>Unità suppl.<br><span class="th-hint">Total number of individual items</span></th>
          <th>24 Rohmasse<br>Masse brute<br>Massa lorda<br><span class="th-hint">Gross weight in kg (incl. packaging)</span></th>
          <th>25 Stat. Wert in CHF<br>Valeur stat. CHF<br>Valore stat. CHF<br><span class="th-hint">Total value in CHF (numbers only, no currency symbol)</span></th>
          <th>26 Ansatz<br>Taux<br>Aliquota<br><span class="th-hint">Duty rate in % - customs fills this in</span></th>
          <th>27 Betrag<br>Montant<br>Importo<br><span class="th-hint">Duty amount in CHF - customs fills this in</span></th>
        </tr></thead>
        <tbody>
          ${C(1,x.tariffNo!=="—"?x.tariffNo:"",String(Math.round(x.weightKg)),String(x.qty),String(Math.round(x.weightKg)),String(Math.floor(x.value)))}
          ${o?C(2,s.tariffNo!=="—"?s.tariffNo:"",String(Math.round(s.weightKg)),String(s.qty),String(Math.round(s.weightKg)),String(Math.floor(s.value))):""}
        </tbody>
      </table>
    </div>

    <!-- Bottom: 28–31 + 32 -->
    <div class="bot">
      <div class="bl">
        <div class="cell" style="min-height:8mm">
          ${t("28","Verwender der Ware / Utilisateur de la marchandise / Utilizzatore della merce")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell" style="min-height:8mm">
          ${t("29","MWST-Nr. / No TVA / N. IVA &nbsp;&nbsp; MWST-Code / Code-TVA / Codice-IVA")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell" style="min-height:8mm">
          ${t("30","Bewilligung usw. / Permis, etc. / Permesso, ecc.")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell">
          ${t("31","Ort/Datum · Lieu/date · Luogo/data &nbsp;&nbsp; Der Anmelder / Le déclarant / Il dichiarante &nbsp;&nbsp; Ref. / Réf. / Rif.")}
          <div style="display:flex;gap:4mm;margin-top:1mm">
            <div style="flex:0 0 auto">
              <div style="font-size:4.8pt;color:#555">Ort/Datum</div>
              <div class="fv" style="font-size:7pt">${i(c)}</div>
            </div>
            <div style="flex:1">
              <div style="font-size:4.8pt;color:#555">Der Anmelder / Le déclarant / Il dichiarante</div>
              <div class="fv" style="font-size:7pt">${i(h.fullName||"—")}</div>
              <div class="sig-note">→ Recommended: person paying the customs deposit</div>
            </div>
            <div style="flex:1">
              <div style="font-size:4.8pt;color:#555">Unterschrift / Signature / Firma</div>
              <div class="sig-line"></div>
              <div class="sig-note">→ Recommended: person paying the customs deposit</div>
            </div>
          </div>
        </div>
      </div>
      <div class="br">
        <div class="cell" style="min-height:14mm">
          ${t("32","Zollabgaben / Droits de douane / Tributi doganali")}
          <div class="cv"><span class="ev">——</span></div>
        </div>
        <div class="cell">
          <div class="subtotal-label">Subtotal / Total int. / Subtotale</div>
          <div class="cv"><span class="ev">——</span></div>
          <div class="subtotal-label">Einfuhrabgaben / Redevances d'entrée / Diritti d'entrata</div>
          <div class="cv"><span class="ev">——</span></div>
          <div class="subtotal-label">Annahme / Acceptation / Accettazione</div>
          <div class="cv"><span class="ev">——</span></div>
        </div>
      </div>
    </div>

  </div>

  <!-- Right pink strip -->
  <div class="strip strip-r">
    <div class="strip-a">A</div>
  </div>

</div>
</body></html>`}function Ce(e,p=new Date){const n=e.meta,h=e.artist,u=e.edec,w=X(h.countryOfOrigin)||"",M=Gt[w]||w,D=[h.companyName,h.fullName,h.street,h.postCodeCity,M].filter(Boolean).join(`
`),A=u.transportMode||"3",l=(u.transportationCountry||"").trim().toUpperCase(),y={1:"80",2:"20",3:"30",4:"40",5:"50",9:"90"}[A]||"30",R=A==="3"&&l||w,z=(n.venuePostcode||"").trim()||"______",W=[n.event,n.venueStreet,[n.venuePostcode,n.venueCity].filter(Boolean).join(" "),n.venueCountry||""].filter(Boolean).join(`
`),b=p.toLocaleDateString("de-CH",{day:"2-digit",month:"2-digit",year:"numeric"}),$=n.venueCity||"",{g1:x,g2:s,hasG2:o,g1prods:r,g2prods:c}=Rt(e),f=S=>String(S==null?"":S).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),v=S=>S?`<span class="fv">${f(S)}</span>`:'<span class="ev">——</span>',t=S=>S?`<span class="fv pre">${f(S)}</span>`:'<span class="ev">——</span>';function d(S,U){return`<div class="ch"><span class="cn">${S}</span><span class="cl">${U}</span></div>`}function g(S,U){return S?`<td style="text-align:${U||"right"}"><span class="gfv">${f(String(S))}</span></td>`:"<td></td>"}const C=`
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, Helvetica, sans-serif; font-size: 6pt; color: #000; background: #b0b0b0; }
.print-bar { background:#222; color:#fff; padding:7px 14px; font-size:10pt; display:flex; align-items:center; gap:12px; position:sticky; top:0; z-index:9; }
.print-bar button { background:#1a6ecc; color:#fff; border:none; padding:5px 16px; font-size:10pt; cursor:pointer; border-radius:3px; font-weight:bold; }
.print-bar .hint { font-size:7.5pt; color:#aaa; }
.page { width:210mm; min-height:297mm; margin:8mm auto; background:#fff; display:flex; flex-direction:column; border:1px solid #444; }

/* Header */
.hdr { display:flex; border-bottom:0.5px solid #000; flex-shrink:0; }
.hdr-logo { width:68mm; padding:2mm; border-right:0.5px solid #000; font-size:4.5pt; line-height:1.4; }
.hdr-logo strong { font-size:5pt; }
.hdr-copy { flex:1; padding:2mm 3mm; border-right:0.5px solid #000; font-size:5pt; }
.hdr-num { padding:2mm 4mm; display:flex; align-items:center; }
.form-number { font-size:30pt; font-weight:bold; letter-spacing:1pt; }

/* Body wrapper */
.body-wrap { display:flex; flex:1; }
.strip { width:13mm; background:#009f68; flex-shrink:0; display:flex; flex-direction:column; align-items:center; padding:3mm 1mm; }
.strip-a { font-size:18pt; font-weight:bold; color:#000; line-height:1; flex-shrink:0; }
.strip-title { font-size:4.5pt; color:#000; writing-mode:vertical-rl; transform:rotate(180deg); margin-top:4mm; line-height:1.5; white-space:nowrap; flex-shrink:0; }
.strip-instr { font-size:3.8pt; color:#000; writing-mode:vertical-rl; transform:rotate(180deg); margin-top:auto; line-height:1.4; white-space:nowrap; flex-shrink:0; }
.fb { flex:1; display:flex; flex-direction:column; }

/* Top grid */
.top-grid { display:flex; border-bottom:0.5px solid #666; }
.lc { flex:0 0 46%; border-right:0.5px solid #666; display:flex; flex-direction:column; }
.rc { flex:1; display:flex; flex-direction:column; }
.hfield { display:flex; gap:2mm; align-items:flex-start; }
.hfield-label { flex:1; }
.hfield-value { flex:0 0 12mm; text-align:right; }
.sig-note { font-size:4pt; color:#cc0000; margin-top:0.5mm; font-style:italic; }

.cell { border-bottom:0.5px solid #666; padding:1mm 1.5mm; }
.cell:last-child { border-bottom:none; }
.ch { display:flex; align-items:baseline; gap:1mm; margin-bottom:0.5mm; }
.cn { font-size:6pt; font-weight:bold; flex-shrink:0; }
.cl { font-size:4pt; color:#555; line-height:1.3; }
.fv { font-weight:bold; color:#003ab5; font-size:7pt; }
.fv.pre { white-space:pre-wrap; font-size:6.5pt; }
.ev { font-size:5.5pt; color:#aaa; font-style:italic; }
.cb { font-size:5pt; display:inline-flex; align-items:center; gap:1mm; margin-right:2.5mm; }
.cb-box { display:inline-block; width:3mm; height:3mm; border:0.5px solid #000; flex-shrink:0; background:#fff; }
.cb-box.chk { background:#000; }

/* Row splitting in rc */
.rc-row { display:flex; border-bottom:0.5px solid #666; }
.rc-row:last-child { border-bottom:none; }
.rc-row .cell { border-bottom:none; }
.rc-row .cell + .cell { border-left:0.5px solid #666; }

/* Field 12 horizontal */
.f12-seg { flex:0 0 auto; border-right:0.5px solid #ccc; padding-right:2mm; margin-right:2mm; }
.f12-seg:last-child { border-right:none; }
.f12-lbl { font-size:3.8pt; color:#666; margin-bottom:0.5mm; }

/* Goods table */
.gt-wrap { border-top:0.5px solid #666; }
.gt { width:100%; border-collapse:collapse; table-layout:fixed; }
.gt th, .gt td { border:0.5px solid #777; padding:0.5mm 0.8mm; vertical-align:top; font-size:4.5pt; }
.gt th { font-weight:600; background:#f4f4f4; line-height:1.3; }
.gt .rn { width:4mm; text-align:center; font-weight:bold; font-size:6pt; }
.gt .data-row td { height:14mm; }
.gfv { font-size:7pt; font-weight:bold; color:#003ab5; }

/* Footer */
.footer { display:flex; border-top:0.5px solid #666; }
.f24 { flex:0 0 52%; border-right:0.5px solid #666; padding:1.5mm; }
.f25 { flex:1; padding:1.5mm; }
.sig-line { border-top:0.5px solid #888; margin-top:5mm; padding-top:0.5mm; font-size:4pt; color:#888; }
.customs-bar { border-top:0.5px solid #666; padding:1mm 1.5mm; font-size:4.5pt; color:#555; }
.customs-boxes { display:flex; gap:3mm; margin-top:1mm; }
.customs-box { flex:1; border:0.5px solid #aaa; min-height:12mm; padding:0.5mm 1mm; font-size:4pt; color:#888; }
.form-footer { text-align:center; font-size:4.5pt; color:#777; padding:1mm; border-top:0.5px solid #eee; }
@media print {
  .print-bar { display:none; }
  body { background:#fff; }
  .page { margin:0; border:none; }
  @page { size: A4 portrait; margin: 0mm; }
}`,O=[...r||[],...o?c||[]:[]].filter(S=>Math.max(0,(S.amount||0)-(S.soldQty||0))>0).map(S=>S.title).filter(Boolean).join(", ");return`<!DOCTYPE html><html lang="de"><head><meta charset="UTF-8">
<title>Formular 11.87 -${f(n.event||"ZollTool")}</title>
<style>${C}</style></head><body>
<div class="print-bar">
  <button onclick="window.print()">Print / Save PDF</button>
  <span class="hint">Formular 11.87 - Vorübergehende Verwendung / Abschluss · pre-filled preview</span>
</div>
<div class="page">

  <!-- Header -->
  <div class="hdr">
    <div class="hdr-logo">
      &#x2295; Schweizerische Eidgenossenschaft · Confédération suisse · Confederazione Svizzera · Confederaziun svizra<br><br>
      <strong>Bundesamt für Zoll und Grenzsicherheit BAZG</strong><br>
      Office fédéral de la douane et de la sécurité des frontières OFDF<br>
      Ufficio federale della dogana e della sicurezza dei confini UDSC<br>
      Uffizi federal da la duana e da la segirezza dals cunfins UDSC
    </div>
    <div class="hdr-copy">Kopie für<br>Copie pour<br>Copia per &nbsp; ________________________</div>
    <div class="hdr-num"><div class="form-number">11.87</div></div>
  </div>

  <!-- Body -->
  <div class="body-wrap">
    <div class="strip">
      <div class="strip-a">A</div>
      <div class="strip-title">Vorübergehende Verwendung / Abschluss · Admission temporaire / Apurement · Ammissione temporanea / Conclusione</div>
      <div class="strip-instr">Anleitung für das Ausfüllen siehe Rückseite von Abschnitt C · Directives pour l'établissement, voir au verso du feuillet C · Istruzioni per l'allestimento, vedi a tergo della cedola C</div>
    </div>
    <div class="fb">

      <!-- Top grid -->
      <div class="top-grid">
        <!-- Left column: 1, 2, 3, 4 -->
        <div class="lc">
          <div class="cell" style="min-height:22mm">
            ${d("1","Versender / Expéditeur / Speditore")}
            ${t(W)}
          </div>
          <div class="cell" style="min-height:12mm">
            ${d("2","Eigentümer der Ware / Propriétaire de la marchandise / Proprietario della merce")}
            ${t(D)}
          </div>
          <div class="cell" style="min-height:12mm">
            ${d("3","Empfänger/Importeur/Verwender / Destinataire/Importateur/Utilisateur / Destinatario/Importatore/Utilizzatore")}
            ${t(D)}
          </div>
          <div class="cell" style="min-height:16mm; border-bottom:none; flex:1">
            ${d("4","ab 11.73/11.74")}
            <div style="font-size:5pt; line-height:2.4; color:#333; margin-top:1mm">
              Nr. / No / N. &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:28mm">&nbsp;</span><br>
              vom / du / del &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:24mm">&nbsp;</span><br>
              Zollstelle &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:18mm">&nbsp;</span>
            </div>
          </div>
        </div>

        <!-- Right column: 5–12 -->
        <div class="rc">
          <div class="rc-row" style="min-height:14mm">
            <div class="cell" style="flex:1">
              ${d("5","Vordokument / Document précédent / Documento precedente")}
              <div style="margin-top:1mm; font-size:5pt; color:#333">
                Nr. / No / N. &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:22mm">&nbsp;</span>
              </div>
            </div>
            <div class="cell" style="flex:0 0 36mm">
              ${d("6","Einfuhr / Import. &nbsp;&nbsp; Ausfuhr / Export.")}
              <div style="margin-top:1.5mm">
                <span class="cb"><span class="cb-box"></span> Einfuhr</span>
                <span class="cb"><span class="cb-box chk"></span> Ausfuhr</span>
              </div>
            </div>
          </div>
          <div class="cell hfield" style="min-height:7mm">
            <div class="hfield-label">${d("7","Ursprungsland / Pays d'origine / Paese d'origine")}</div>
            <div class="hfield-value">${v(w||"——")}</div>
          </div>
          <div class="cell hfield" style="min-height:7mm">
            <div class="hfield-label">${d("8","Land der vorübergehenden Bestimmung / Pays de destination temporaire / Paese di destinazione temporanea")}</div>
            <div class="hfield-value">${v(X(n.venueCountry)||"CH")}</div>
          </div>
          <div class="cell hfield" style="min-height:7mm">
            <div class="hfield-label">${d("9","Land der endgültigen Bestimmung / Pays de destination définitive / Paese di destinazione definitiva")}</div>
            <div class="hfield-value">${v(w||"——")}</div>
          </div>
          <div class="cell" style="min-height:8mm">
            ${d("10","Zweck der vorübergehenden Verwendung / But de l'admission temporaire / Scopo dell'ammissione temporanea")}
            ${v("Verkauf an Ausstellungen / Messen · Vente aux expositions / foires")}
          </div>
          <div class="cell" style="min-height:8mm; border-bottom:none; flex:1">
            <div style="display:flex; gap:4mm; align-items:flex-start">
              <div>
                ${d("11","Mietgeschäft / Location / Locazione")}
                <div style="margin-top:1mm">
                  <span class="cb"><span class="cb-box"></span> ja / oui / sì</span>
                  <span class="cb"><span class="cb-box"></span> nein / non / no</span>
                </div>
              </div>
              <div style="border-left:0.5px solid #ccc; padding-left:3mm; flex:1">
                ${d("12","VKZ/MTS · Immat. Land · PLZ/NPA/CAP")}
                <div style="display:flex; gap:2mm; margin-top:1mm; align-items:flex-start">
                  <div class="f12-seg">
                    <div class="f12-lbl">VKZ/MTS</div>
                    <span class="fv">${f(y)}</span>
                  </div>
                  <div class="f12-seg">
                    <div class="f12-lbl">Immat. Land</div>
                    <span class="fv">${f(R||"______")}</span>
                  </div>
                  <div class="f12-seg" style="border-right:none">
                    <div class="f12-lbl">PLZ/NPA/CAP</div>
                    <span class="fv">${f(z)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Goods table: fields 13–14 (description row) -->
      <div class="gt-wrap" style="border-bottom:none">
        <table class="gt">
          <colgroup>
            <col style="width:4mm">
            <col style="width:22mm">
            <col>
          </colgroup>
          <thead><tr>
            <th class="rn"></th>
            <th>13 Zeichen, Nr., Anzahl, Verpackung<br>Marque, no, nombre, emballage<br>Marca, n., quantità imballaggio</th>
            <th>14 Genaue Warenbezeichnung (Material, Typ, Nummern, etc.), die eine Identifikation der Ware erlaubt<br>Désignation exacte de la marchandise permettant son identification<br>Designazione esatta della merce che ne permette l'identificazione</th>
          </tr></thead>
          <tbody>
            <tr class="data-row">
              <td class="rn">1</td>
              <td><span class="gfv">See attached list</span></td>
              <td><span class="gfv">${f(O||"—")}</span></td>
            </tr>
            <tr class="data-row">
              <td class="rn">2</td>
              <td></td><td></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Goods table: fields 15–23 (numeric row) -->
      <div class="gt-wrap">
        <table class="gt">
          <colgroup>
            <col style="width:4mm">
            <col style="width:7mm"><col style="width:6mm">
            <col style="width:20mm">
            <col style="width:8mm">
            <col style="width:13mm"><col style="width:13mm">
            <col style="width:13mm"><col style="width:19mm"><col style="width:14mm">
          </colgroup>
          <thead><tr>
            <th class="rn"></th>
            <th>15<br>NHW<br>MNC</th>
            <th>16<br>VC<br>CT</th>
            <th>17 Tarif-Nr.<br>No de tarif<br>Voce di tariffa</th>
            <th>18<br>Schlüssel<br>Clé<br>N.conv.</th>
            <th>19 Eigenmasse<br>Masse nette<br>Massa netta</th>
            <th>20 Zusatz-menge<br>Unités suppl.<br>Unità suppl.</th>
            <th>21 Rohmasse<br>Masse brute<br>Massa lorda</th>
            <th>22 Stat. Wert in CHF<br>Valeur stat. CHF<br>Valore stat. CHF</th>
            <th>23 MWST-Wert<br>Valeur-TVA<br>Valore-IVA</th>
          </tr></thead>
          <tbody>
            <tr class="data-row">
              <td class="rn">1</td>
              <td></td><td></td>
              ${g(x.retQty>0&&x.tariffNo!=="—"?x.tariffNo:"")}
              <td></td>
              ${g(x.retQty>0?Math.round(x.retWeightKg):"")}
              ${g(x.retQty>0?x.retQty:"","center")}
              ${g(x.retQty>0?Math.round(x.retWeightKg):"")}
              ${g(x.retQty>0?x.retValue:"")}
              <td></td>
            </tr>
            ${o?`<tr class="data-row">
              <td class="rn">2</td>
              <td></td><td></td>
              ${g(s.retQty>0&&s.tariffNo!=="—"?s.tariffNo:"")}
              <td></td>
              ${g(s.retQty>0?Math.round(s.retWeightKg):"")}
              ${g(s.retQty>0?s.retQty:"","center")}
              ${g(s.retQty>0?Math.round(s.retWeightKg):"")}
              ${g(s.retQty>0?s.retValue:"")}
              <td></td>
            </tr>`:""}
          </tbody>
        </table>
      </div>

      <!-- Footer: 24 + 25 -->
      <div class="footer">
        <div class="f24">
          ${d("24","Ort / Datum · Lieu / Date · Luogo / Data")}
          <div style="margin-top:1mm"><span class="fv">${f($?$+", ":"")}${f(b)}</span></div>
          <div style="margin-top:2mm; font-size:4.8pt; color:#444">Der Anmelder / Le déclarant / Il dichiarante</div>
          <div style="margin-top:0.5mm"><span class="fv">${f(h.fullName||"——")}</span></div>
          <div class="sig-note">→ Recommended: same person who signed the 11.74</div>
          <div class="sig-line">Unterschrift / Signature / Firma</div>
          <div style="margin-top:1mm; font-size:4.5pt; color:#444">Ref. / Réf. / Rif. &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:30mm">&nbsp;</span></div>
        </div>
        <div class="f25">
          ${d("25","Mehrwertsteuer / Taxe sur la valeur ajoutée / Imposta sul valore aggiunto")}
          <div style="font-size:4.8pt; line-height:2.2; margin-top:1mm; color:#333">
            MWST-Code / Code-TVA / Codice-IVA &nbsp;<span style="border-bottom:0.5px solid #999;display:inline-block;min-width:14mm">&nbsp;</span><br>
            MWST-Register-Nr. / No d'enregistrement-TVA / N. di registrazione IVA<br>
            <span style="border-bottom:0.5px solid #999;display:inline-block;min-width:38mm">&nbsp;</span>
          </div>
        </div>
      </div>

      <!-- Customs verification area -->
      <div class="customs-bar">
        Zollbefund · Résultat de la vérification · Risultato della visita
        <div class="customs-boxes">
          <div class="customs-box">Annahme / Acceptation / Accettazione</div>
          <div class="customs-box">Kontrolle / Contrôle / Controllo</div>
        </div>
      </div>

    </div><!-- fb -->
    <div class="strip strip-r">
      <div class="strip-a">A</div>
    </div>
  </div><!-- body-wrap -->

  <div class="form-footer">Form. 11.87 · 1.2022 · Nachdruck verboten / Reproduction interdite / Riproduzione vietata</div>
</div><!-- page -->
</body></html>`}const ke={class:"mx-auto max-w-4xl space-y-4 p-4 md:p-6"},Ne={class:"flex flex-wrap items-center gap-3"},Te={key:0,class:"text-sm text-slate-400"},Ve={key:0,class:"rounded-xl bg-slate-900 p-6 text-center text-sm text-slate-400"},Se={class:"zui-card"},Re={class:"mb-3 text-xs text-slate-500"},ze={class:"font-mono text-slate-300"},Me={key:0},Ae={class:"mb-3 flex flex-wrap items-center gap-2 text-sm"},_e={class:"flex rounded-lg bg-slate-800 p-1"},De=["onClick"],We={class:"grid grid-cols-2 gap-2 sm:grid-cols-3"},Pe={class:"zui-card"},Oe={class:"grid gap-3 sm:grid-cols-2"},Qe={class:"block text-sm"},Ue={class:"block text-sm"},Ee={class:"block text-sm"},Le={class:"block text-sm"},Fe={class:"block text-sm"},Ge={class:"block text-sm"},Ie={class:"block text-sm sm:col-span-2"},He={class:"zui-card"},je={class:"grid gap-3 sm:grid-cols-2"},Be={class:"block text-sm"},Ke={class:"text-xs text-slate-400"},qe={key:0,class:"text-emerald-500"},Ze=["placeholder"],Ye={class:"block text-sm"},Xe={class:"block text-sm"},Je={class:"block text-sm"},ts={class:"block text-sm sm:col-span-2"},es={class:"zui-card"},ss={class:"grid gap-3 sm:grid-cols-2"},as={class:"block text-sm"},ls=["value"],os={class:"block text-sm"},is={class:"block text-sm"},rs={key:0,class:"block text-sm"},ns={class:"zui-card"},ds={class:"mb-3 flex rounded-lg bg-slate-800 p-1 text-sm",style:{"max-width":"280px"}},cs={key:0,class:"mb-3 grid gap-2 sm:grid-cols-2"},us={class:"rounded-lg bg-slate-800/60 p-3 text-xs"},ms={class:"mb-1 font-semibold text-slate-300"},ps={class:"text-slate-400"},fs={class:"mb-1 font-semibold text-slate-300"},hs={class:"text-slate-400"},gs={key:1,class:"space-y-1"},vs={class:"min-w-0 flex-1 truncate"},bs={class:"text-xs text-slate-500"},ys={class:"flex rounded-md bg-slate-800 p-0.5"},xs=["onClick"],$s=["onClick"],ws={key:2,class:"text-xs text-slate-500"},Vs=Bt({__name:"CustomsView",setup(e){const p=Kt(),n=te(),h=rt(()=>{var _;return(_=p.events.find(a=>a.id===n.params.eventId))!=null?_:p.activeEvent}),u=lt(wt()),w=lt(Ct()),M=lt(kt()),D=lt(""),A=lt(1),l=lt(""),V=lt(""),y=lt("");let R=null,z=null,W=!1;function b(_){return _?Object.fromEntries(Object.entries(_).filter(([,a])=>a!==""&&a!=null)):{}}yt(()=>h.value,async _=>{var J,T,tt,ut,pt,zt,Mt,At,_t,Dt,Wt,Pt,Ot;if(!_||_.id===R)return;R=_.id,W=!0;const a=Nt(_),Y=await ee("customs.artistDefaults");u.value={...wt(),...b(Y),...b(a.artist)},w.value={...Ct(),...(J=a.edec)!=null?J:{}};const j={...kt(),...(T=a.form1174)!=null?T:{}};Array.isArray(j.assignments)||(j.assignments=[]),M.value=j,D.value=(ut=(tt=a.meta)==null?void 0:tt.companyCode)!=null?ut:"",A.value=(zt=(pt=a.meta)==null?void 0:pt.documentNumber)!=null?zt:1,l.value=(At=(Mt=a.meta)==null?void 0:Mt.venueName)!=null?At:"",V.value=(Dt=(_t=a.meta)==null?void 0:_t.eventLocation)!=null?Dt:"",y.value=(Ot=(Pt=(Wt=a.meta)==null?void 0:Wt.venueTIN)!=null?Pt:_.venue.tin)!=null?Ot:"",setTimeout(()=>W=!1)},{immediate:!0});function $(){W||!h.value||(z&&clearTimeout(z),z=setTimeout(x,600))}async function x(){const _=h.value;if(!_)return;const a=Nt(_);await se({..._,customs:{..._.customs,artist:{...u.value},edec:{...w.value},form1174:JSON.parse(JSON.stringify(M.value)),meta:{...a.meta,companyCode:D.value,documentNumber:A.value,venueName:l.value,eventLocation:V.value,venueTIN:y.value}},updatedAt:Date.now()})}yt([u,w,M,D,A,l,V,y],$,{deep:!0});const s=rt(()=>{const _=(u.value.companyName||u.value.fullName||"").trim();if(!_)return"";const a=_.split(/\s+/).filter(Boolean);return(a.length>1?a.map(j=>j[0]).join(""):_.slice(0,3)).toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,6)}),o=rt(()=>D.value.trim()||s.value),r=rt(()=>{if(!h.value)return null;const _={...h.value,customs:{artist:u.value,edec:w.value,form1174:M.value,meta:{companyCode:o.value,documentNumber:A.value,venueName:l.value,eventLocation:V.value,venueTIN:y.value}}};return me(_,p.products,p.allStock,p.allTransactions)}),c=rt(()=>r.value?St(r.value,A.value):""),f=rt(()=>r.value?Rt(JSON.parse(JSON.stringify(r.value))):null);function v(_,a){var j,J;const Y=[...M.value.assignments];for(;Y.length<((J=(j=r.value)==null?void 0:j.products.length)!=null?J:0);)Y.push(0);Y[_]=a,M.value={...M.value,assignments:Y}}const t=lt("detailed"),d=rt(()=>{var _,a;return(a=(_=r.value)==null?void 0:_.products.some(Y=>{var j,J;return!Y.unlisted&&((J=(j=Y.variants)==null?void 0:j.length)!=null?J:0)>0}))!=null?a:!1}),g=rt(()=>d.value?[{value:"detailed",label:"Detailed"},{value:"compressed",label:"Compressed"},{value:"bytype",label:"By type"}]:[{value:"detailed",label:"Per product"},{value:"bytype",label:"By type"}]);yt(d,_=>{!_&&t.value==="compressed"&&(t.value="detailed")});function C(_){var a;return`${(((a=h.value)==null?void 0:a.name)||"event").replace(/[^\w-]+/g,"_")}_${_}`}async function k(_,a){await le(_,a,"text/html")}async function O(){if(!r.value)return;const _=ve(r.value);if(!_){Xt("No products have sold quantities > 0 yet.","error");return}await ae(_.filename,_.xml,"application/xml")}const N=_=>k(C(`goods_${_}.html`),ye(r.value,_,t.value)),S=()=>k(C("goods_all.html"),xe(r.value)),U=()=>k(C("proforma.html"),$e(r.value)),ot=()=>k(C("form_1174.html"),we(r.value)),it=()=>k(C("form_1187.html"),Ce(r.value)),bt=[["1","1 - Sea"],["2","2 - Rail"],["3","3 - Road"],["4","4 - Air"],["5","5 - Postal / Mail"],["9","9 - Own propulsion"]];return(_,a)=>{var j,J;const Y=Jt("RouterLink");return H(),I("div",ke,[m("div",Ne,[et(Y,{to:"/events",class:"rounded-lg px-2 py-1 text-slate-400 hover:bg-slate-800"},{default:qt(()=>[...a[21]||(a[21]=[st("←",-1)])]),_:1}),a[22]||(a[22]=m("h1",{class:"text-xl font-bold"},"Customs",-1)),h.value?(H(),I("span",Te,F(h.value.name),1)):mt("",!0)]),h.value?(H(),I(ft,{key:1},[m("section",Se,[a[33]||(a[33]=m("h2",{class:"mb-1 zui-card-title"},"Documents",-1)),m("p",Re,[a[23]||(a[23]=st(" LRP: ",-1)),m("span",ze,F(c.value),1),at(Zt)?(H(),I("span",Me," · Documents open in your browser - print or save as PDF from there.")):mt("",!0)]),m("div",Ae,[a[24]||(a[24]=m("span",{class:"text-xs text-slate-400"},"Goods list format:",-1)),m("div",_e,[(H(!0),I(ft,null,xt(g.value,T=>(H(),I("button",{key:T.value,class:dt(["rounded-md px-3 py-1 text-xs",t.value===T.value?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:tt=>t.value=T.value},F(T.label),11,De))),128))])]),m("div",We,[m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:a[0]||(a[0]=T=>N(1))},[et(at(de),{class:"h-4 w-4 shrink-0"}),a[25]||(a[25]=st(" Import list ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:a[1]||(a[1]=T=>N(2))},[et(at(ie),{class:"h-4 w-4 shrink-0"}),a[26]||(a[26]=st(" Sold goods list ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:a[2]||(a[2]=T=>N(3))},[et(at(ce),{class:"h-4 w-4 shrink-0"}),a[27]||(a[27]=st(" Return goods list ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:S},[et(at(ue),{class:"h-4 w-4 shrink-0"}),a[28]||(a[28]=st(" All formats bundle ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:U},[et(at(re),{class:"h-4 w-4 shrink-0"}),a[29]||(a[29]=st(" Proforma invoice ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:ot},[et(at(Ut),{class:"h-4 w-4 shrink-0"}),a[30]||(a[30]=st(" Form 11.74 ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2.5 text-sm font-medium hover:bg-slate-700",onClick:it},[et(at(Ut),{class:"h-4 w-4 shrink-0"}),a[31]||(a[31]=st(" Form 11.87 ",-1))]),m("button",{class:"flex items-center justify-center gap-1.5 rounded-lg bg-emerald-700 px-3 py-2.5 text-sm font-semibold text-white hover:bg-emerald-600",onClick:O},[et(at(ne),{class:"h-4 w-4 shrink-0"}),a[32]||(a[32]=st(" e-dec XML ",-1))])])]),m("section",Pe,[a[41]||(a[41]=m("h2",{class:"mb-3 zui-card-title"},"Artist / sender",-1)),m("div",Oe,[m("label",Qe,[a[34]||(a[34]=m("span",{class:"text-xs text-slate-400"},"Company name",-1)),B(m("input",{"onUpdate:modelValue":a[3]||(a[3]=T=>u.value.companyName=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,u.value.companyName]])]),m("label",Ue,[a[35]||(a[35]=m("span",{class:"text-xs text-slate-400"},"Full name",-1)),B(m("input",{"onUpdate:modelValue":a[4]||(a[4]=T=>u.value.fullName=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,u.value.fullName]])]),m("label",Ee,[a[36]||(a[36]=m("span",{class:"text-xs text-slate-400"},"Street & house number",-1)),B(m("input",{"onUpdate:modelValue":a[5]||(a[5]=T=>u.value.street=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,u.value.street]])]),m("label",Le,[a[37]||(a[37]=m("span",{class:"text-xs text-slate-400"},"Postcode & city",-1)),B(m("input",{"onUpdate:modelValue":a[6]||(a[6]=T=>u.value.postCodeCity=T),placeholder:"9000 Gent",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,u.value.postCodeCity]])]),m("label",Fe,[a[38]||(a[38]=m("span",{class:"text-xs text-slate-400"},"Country of origin",-1)),et(Qt,{modelValue:u.value.countryOfOrigin,"onUpdate:modelValue":a[7]||(a[7]=T=>u.value.countryOfOrigin=T),mode:"name",placeholder:"Belgium",class:"mt-1"},null,8,["modelValue"])]),m("label",Ge,[a[39]||(a[39]=m("span",{class:"text-xs text-slate-400"},"Phone",-1)),B(m("input",{"onUpdate:modelValue":a[8]||(a[8]=T=>u.value.phone=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,u.value.phone]])]),m("label",Ie,[a[40]||(a[40]=m("span",{class:"text-xs text-slate-400"},"Email",-1)),B(m("input",{"onUpdate:modelValue":a[9]||(a[9]=T=>u.value.email=T),type:"email",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,u.value.email]])])])]),m("section",He,[a[47]||(a[47]=m("h2",{class:"mb-3 zui-card-title"},"Declaration details",-1)),m("div",je,[m("label",Be,[m("span",Ke,[a[42]||(a[42]=st(" Company code (for LRP) ",-1)),!D.value.trim()&&s.value?(H(),I("span",qe," — auto: "+F(s.value),1)):mt("",!0)]),B(m("input",{"onUpdate:modelValue":a[10]||(a[10]=T=>D.value=T),placeholder:s.value||"e.g. GUG",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,8,Ze),[[q,D.value]])]),m("label",Ye,[a[43]||(a[43]=m("span",{class:"text-xs text-slate-400"},"Document number",-1)),B(m("input",{"onUpdate:modelValue":a[11]||(a[11]=T=>A.value=T),type:"number",min:"1",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,A.value,void 0,{number:!0}]])]),m("label",Xe,[a[44]||(a[44]=m("span",{class:"text-xs text-slate-400"},"Venue / organiser name",-1)),B(m("input",{"onUpdate:modelValue":a[12]||(a[12]=T=>l.value=T),placeholder:"e.g. Messe Basel",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,l.value]])]),m("label",Je,[a[45]||(a[45]=m("span",{class:"text-xs text-slate-400"},"Venue TIN",-1)),B(m("input",{"onUpdate:modelValue":a[13]||(a[13]=T=>y.value=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2 font-mono text-xs"},null,512),[[q,y.value]])]),m("label",ts,[a[46]||(a[46]=m("span",{class:"text-xs text-slate-400"},"Event location (shown on documents)",-1)),B(m("input",{"onUpdate:modelValue":a[14]||(a[14]=T=>V.value=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,V.value]])])]),a[48]||(a[48]=m("p",{class:"mt-2 text-xs text-slate-500"}," Venue address and event dates come from the event itself — edit them under Events. ",-1))]),m("section",es,[a[53]||(a[53]=m("h2",{class:"mb-3 zui-card-title"},"Transport (e-dec / forms)",-1)),m("div",ss,[m("label",as,[a[49]||(a[49]=m("span",{class:"text-xs text-slate-400"},"Transport mode",-1)),B(m("select",{"onUpdate:modelValue":a[15]||(a[15]=T=>w.value.transportMode=T),class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},[(H(),I(ft,null,xt(bt,([T,tt])=>m("option",{key:T,value:T},F(tt),9,ls)),64))],512),[[Yt,w.value.transportMode]])]),m("label",os,[a[50]||(a[50]=m("span",{class:"text-xs text-slate-400"},"Vehicle country",-1)),et(Qt,{modelValue:w.value.transportationCountry,"onUpdate:modelValue":a[16]||(a[16]=T=>w.value.transportationCountry=T),mode:"code",placeholder:"BE",class:"mt-1"},null,8,["modelValue"])]),m("label",is,[a[51]||(a[51]=m("span",{class:"text-xs text-slate-400"},"Vehicle / plate number",-1)),B(m("input",{"onUpdate:modelValue":a[17]||(a[17]=T=>w.value.transportationNumber=T),placeholder:"1-KDE-308",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,w.value.transportationNumber]])]),w.value.transportMode==="4"?(H(),I("label",rs,[a[52]||(a[52]=m("span",{class:"text-xs text-slate-400"},"Flight number (form 11.74 field 6)",-1)),B(m("input",{"onUpdate:modelValue":a[18]||(a[18]=T=>w.value.flightNumber=T),placeholder:"LX1234",class:"mt-1 w-full rounded-lg bg-slate-800 px-3 py-2"},null,512),[[q,w.value.flightNumber]])])):mt("",!0)])]),m("section",ns,[a[54]||(a[54]=m("h2",{class:"mb-3 zui-card-title"},"Form 11.74 / 11.87 goods grouping",-1)),m("div",ds,[m("button",{class:dt(["flex-1 rounded-md px-3 py-1.5",M.value.groupMode==="auto"?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:a[19]||(a[19]=T=>M.value={...M.value,groupMode:"auto"})}," Automatic ",2),m("button",{class:dt(["flex-1 rounded-md px-3 py-1.5",M.value.groupMode==="manual"?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:a[20]||(a[20]=T=>M.value={...M.value,groupMode:"manual"})}," Manual ",2)]),f.value?(H(),I("div",cs,[m("div",us,[m("p",ms,"Group 1 · "+F(f.value.g1.tariffNo),1),m("p",ps,F(f.value.g1.qty)+" items · "+F(at(P)(f.value.g1.weightKg))+" · "+F(Math.floor(f.value.g1.value))+" "+F((j=h.value)==null?void 0:j.currency),1)]),m("div",{class:dt(["rounded-lg bg-slate-800/60 p-3 text-xs",{"opacity-40":!f.value.hasG2}])},[m("p",fs,"Group 2 · "+F(f.value.g2.tariffNo),1),m("p",hs,F(f.value.g2.qty)+" items · "+F(at(P)(f.value.g2.weightKg))+" · "+F(Math.floor(f.value.g2.value))+" "+F((J=h.value)==null?void 0:J.currency),1)],2)])):mt("",!0),M.value.groupMode==="manual"&&r.value?(H(),I("div",gs,[(H(!0),I(ft,null,xt(r.value.products,(T,tt)=>{var ut;return H(),I("div",{key:(ut=T.id)!=null?ut:tt,class:"flex items-center gap-2 rounded-lg bg-slate-800/40 px-3 py-1.5 text-sm"},[m("span",vs,F(T.title),1),m("span",bs,F(T.tariffNo||"—"),1),m("div",ys,[m("button",{class:dt(["rounded px-2.5 py-0.5 text-xs",M.value.assignments[tt]===1?"bg-emerald-700 font-semibold text-white":"text-slate-400"]),onClick:pt=>v(tt,1)}," G1 ",10,xs),m("button",{class:dt(["rounded px-2.5 py-0.5 text-xs",M.value.assignments[tt]!==1?"bg-slate-600 font-semibold":"text-slate-400"]),onClick:pt=>v(tt,2)}," G2 ",10,$s)])])}),128))])):(H(),I("p",ws," Automatic: the tariff group with the highest value becomes group 1, everything else group 2. "))])],64)):(H(),I("p",Ve," Event not found — open Customs from an event card under Events. Customs data is stored per event. "))])}}});export{Vs as default};
