const r=s=>/^art\s*prints?$/i.test((s!=null?s:"").trim()),i=s=>/^purses?$/i.test((s!=null?s:"").trim());export{i as a,r as i};
