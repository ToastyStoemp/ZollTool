const s=r=>/^art\s*prints?$/i.test((r!=null?r:"").trim());export{s as i};
